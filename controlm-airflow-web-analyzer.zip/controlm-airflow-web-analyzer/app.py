from __future__ import annotations

import csv
from io import StringIO
import uuid
from typing import Any

from flask import Flask, Response, redirect, render_template, request, url_for

from analyzer import parse_and_analyze_json


app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024  # 20 MB

_REPORT_CACHE: dict[str, dict[str, Any]] = {}


def _build_csv(content: list[dict[str, Any]], columns: list[str]) -> str:
    output = StringIO()
    writer = csv.DictWriter(output, fieldnames=columns)
    writer.writeheader()
    for row in content:
        writer.writerow({column: row.get(column, "") for column in columns})
    return output.getvalue()


def _build_summary_rows(report: dict[str, Any]) -> list[dict[str, Any]]:
    summary = report.get("summary", {})
    return [{"metric": key, "value": value} for key, value in summary.items()]


@app.get("/")
def index() -> str:
    return render_template("index.html", report=None, report_id=None, error=None)


@app.post("/analyze")
def analyze() -> str:
    upload = request.files.get("controlm_file")
    if upload is None or not upload.filename:
        return render_template("index.html", report=None, report_id=None, error="Please upload a Control-M JSON file.")

    try:
        raw = upload.read().decode("utf-8")
        report = parse_and_analyze_json(raw, source_name=upload.filename)
    except Exception as exc:  # noqa: BLE001
        return render_template(
            "index.html",
            report=None,
            report_id=None,
            error=f"Failed to analyze file: {exc}",
        )

    report_id = uuid.uuid4().hex

    jobs_columns = [
        "folder",
        "job_name",
        "raw_type",
        "normalized_type",
        "feature_combo",
        "migration_status",
        "airflow_equivalent",
        "migration_notes",
        "dependencies",
        "unresolved_dependencies",
        "dependents",
        "standalone",
        "in_events",
        "out_events",
        "event_to_wait_for",
        "cross_folder_events",
        "schedule_type",
        "schedule_detail",
        "schedule_from_time",
        "schedule_to_time",
        "schedule_time_window",
        "calendar_used",
        "host_groups",
        "variables",
        "dynamic_variables",
        "uses_odate",
        "uses_orderid",
        "action_dependencies",
        "resource_refs",
        "application",
        "sub_application",
        "host",
        "critical",
        "ctm_type",
        "rerun_limit",
        "rerun_every",
        "rerun_units",
        "is_cyclic",
        "cyclic_type",
        "cyclic_schedule",
        "cyclic_max_times",
    ]

    summary_columns = ["metric", "value"]
    standalone_columns = [
        "folder",
        "job_name",
        "normalized_type",
        "schedule_type",
        "schedule_detail",
        "schedule_from_time",
        "schedule_to_time",
        "schedule_time_window",
        "calendar_used",
        "migration_recommendation",
        "airflow_equivalent",
    ]
    no_schedule_columns = [
        "folder",
        "job_name",
        "normalized_type",
        "migration_status",
        "schedule_type",
        "schedule_detail",
        "schedule_from_time",
        "schedule_to_time",
        "schedule_time_window",
        "airflow_equivalent",
    ]
    edge_columns = [
        "from_folder",
        "from_job",
        "to_folder",
        "to_job",
        "relation",
        "cross_folder",
    ]

    jobs_csv = _build_csv(report.get("jobs", []), jobs_columns)
    summary_csv = _build_csv(_build_summary_rows(report), summary_columns)
    standalone_csv = _build_csv(report.get("standalone_jobs", []), standalone_columns)
    no_schedule_csv = _build_csv(report.get("jobs_without_schedule", []), no_schedule_columns)
    edges_csv = _build_csv(report.get("dependency_edges", []), edge_columns)

    _REPORT_CACHE[report_id] = {
        "report": report,
        "jobs_csv": jobs_csv,
        "summary_csv": summary_csv,
        "standalone_csv": standalone_csv,
        "no_schedule_csv": no_schedule_csv,
        "edges_csv": edges_csv,
        "markdown_report": report.get("markdown_report", ""),
    }

    return render_template("index.html", report=report, report_id=report_id, error=None)


@app.get("/download/<report_id>/<kind>.csv")
def download(report_id: str, kind: str) -> Response:
    payload = _REPORT_CACHE.get(report_id)
    if not payload:
        return Response("Report not found. Re-run analysis.", status=404)

    if kind == "jobs":
        data = payload["jobs_csv"]
        filename = "controlm_airflow_job_analysis.csv"
    elif kind == "summary":
        data = payload["summary_csv"]
        filename = "controlm_airflow_summary.csv"
    elif kind == "standalone":
        data = payload["standalone_csv"]
        filename = "controlm_airflow_standalone_jobs.csv"
    elif kind == "noschedule":
        data = payload["no_schedule_csv"]
        filename = "controlm_airflow_jobs_without_schedule.csv"
    elif kind == "edges":
        data = payload["edges_csv"]
        filename = "controlm_airflow_dependency_edges.csv"
    else:
        return Response("Unknown file type.", status=400)

    return Response(
        data,
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


@app.get("/download/<report_id>/report.md")
def download_markdown(report_id: str) -> Response:
    payload = _REPORT_CACHE.get(report_id)
    if not payload:
        return Response("Report not found. Re-run analysis.", status=404)

    data = payload.get("markdown_report") or ""
    return Response(
        data,
        mimetype="text/markdown",
        headers={"Content-Disposition": "attachment; filename=controlm_airflow_migration_report.md"},
    )


@app.get("/health")
def health() -> Response:
    return Response("ok", status=200)


@app.get("/clear-cache")
def clear_cache() -> Response:
    _REPORT_CACHE.clear()
    return redirect(url_for("index"))


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)
