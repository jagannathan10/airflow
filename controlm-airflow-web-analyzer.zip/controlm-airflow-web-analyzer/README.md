# Control-M to Airflow Web Analyzer

Web application to analyze Control-M `.json` definitions for Airflow migration readiness.

## What it provides

- Upload Control-M JSON and click **Analyze**.
- HTML report on same page with:
  - total number of jobs and folder count,
  - split by job type with percentages,
  - job type detection and migration classification,
  - migratable vs partially migratable vs needs-assessment jobs,
  - dependency and interlinked graph insights,
  - recommendation for one DAG vs multiple DAGs,
  - event-to-wait-for and cross-folder event detection,
  - ExternalTaskSensor/Datasets relevance,
  - variables, dynamic variables, `ODATE`, `ORDERID`,
  - manual schedules, calendars used,
  - host groups,
  - action-based dependencies,
  - standalone (shift-left candidate) job count.
  - standalone job list with schedules and migration recommendation,
  - jobs without schedule list,
  - dependency graph preview + full dependency edge CSV.
- Download reports as CSV:
  - **Jobs CSV** (detailed per job)
  - **Summary CSV** (platform-level metrics)
  - **Standalone Jobs CSV**
  - **Jobs Without Schedule CSV**
  - **Dependency Edges CSV**
  - **Markdown Report** (structured report format aligned to migration-report style)

## Supported job type families in report

The analyzer identifies and reports these job families (with combinations):

- Script
- Command
- Dataset
- EventDriven
- CalendarBased
- FileWatcher
- SLAManagement
- EmbeddedScript
- Dummy
- BashOperator
- Database
- Unknown

## Quick start

```bash
cd controlm-airflow-web-analyzer
python -m venv .venv
source .venv/bin/activate   # Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```

Open: `http://localhost:8000`

## Run with Gunicorn (recommended)

```bash
gunicorn --bind 0.0.0.0:8000 --workers 4 wsgi:application
```

## NGINX deployment

Use config: `deploy/nginx-site.conf`

1. Run app via Gunicorn on `127.0.0.1:8000`.
2. Place NGINX site config and reload NGINX.

## Apache deployment

Use config: `deploy/apache-vhost.conf`

1. Enable `proxy` and `proxy_http` modules.
2. Run app via Gunicorn on `127.0.0.1:8000`.
3. Enable vhost and reload Apache.

## Systemd service example

Use `deploy/controlm-analyzer.service`.

## Input notes

Accepts common Control-M JSON shapes such as:

- `{"folders": [...]}`
- `{"Folders": [...]}`
- `{"Folder": {...}}`
- keyed folder-map export, e.g. `{"APO_OMSS": {"Jobs":[...]}, "APO_FEED": {"Jobs":[...]}}`
- single-folder structures with `Jobs/jobs/SMARTFolder/SubFolders`.

## Sample input

`./samples/controlm_sample.json`
