from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
import json
import re
from typing import Any


KNOWN_JOB_TYPES = [
    "Script",
    "Command",
    "Dataset",
    "EventDriven",
    "CalendarBased",
    "FileWatcher",
    "SLAManagement",
    "EmbeddedScript",
    "Dummy",
    "BashOperator",
    "Database",
    "Unknown",
]


TYPE_HINTS = {
    "script": "Script",
    "cmd": "Command",
    "command": "Command",
    "os": "Command",
    "dataset": "Dataset",
    "event": "EventDriven",
    "filewatch": "FileWatcher",
    "watchfile": "FileWatcher",
    "sla": "SLAManagement",
    "embedded": "EmbeddedScript",
    "dummy": "Dummy",
    "bashoperator": "BashOperator",
    "bash": "BashOperator",
    "database": "Database",
    "sql": "Database",
}


MIGRATION_GUIDANCE = {
    "Script": ("Migratable", "PythonOperator/BashOperator", "Direct script wrapping is usually straightforward."),
    "Command": ("Migratable", "BashOperator", "OS command jobs map directly to shell operators."),
    "Dataset": ("Migratable", "Datasets + scheduling", "Dataset-triggered orchestration is supported in Airflow."),
    "EventDriven": ("Partially Migratable", "ExternalTaskSensor/Datasets/TriggerDagRunOperator", "Requires event contract redesign and clear ownership."),
    "CalendarBased": ("Migratable", "Cron timetable", "Control-M calendars can be translated to DAG schedules."),
    "FileWatcher": ("Partially Migratable", "FileSensor/Deferrable FileSensor", "Needs shared storage semantics and anti-polling design."),
    "SLAManagement": ("Partially Migratable", "SLA/Deadline alerts + observability", "Control-M SLA workflows need custom alert orchestration."),
    "EmbeddedScript": ("Migratable", "PythonOperator/TaskFlow API", "Inline logic can move into Python callable tasks."),
    "Dummy": ("Migratable", "EmptyOperator", "Dummy/control jobs map directly to empty control steps."),
    "BashOperator": ("Migratable", "BashOperator", "Already aligned with Airflow operator model."),
    "Database": ("Migratable", "SQLExecuteQueryOperator or DB provider operators", "Use provider hooks/operators with connection IDs."),
    "Unknown": ("Needs Assessment", "Custom operator or refactor", "Job type is not explicit; manual mapping required."),
}


OPERATOR_MAPPING = {
    "Script": "BashOperator / SSHOperator",
    "Command": "BashOperator / SSHOperator",
    "Dataset": "Datasets + TriggerDagRunOperator",
    "EventDriven": "ExternalTaskSensor / Datasets / TriggerDagRunOperator",
    "CalendarBased": "Cron timetable / custom timetable",
    "FileWatcher": "FileSensor / SFTPSensor (mode=reschedule)",
    "SLAManagement": "sla=timedelta(...) + sla_miss_callback on DAG/task",
    "EmbeddedScript": "BashOperator (inline script) / SSHOperator",
    "Dummy": "EmptyOperator (sync gate)",
    "BashOperator": "BashOperator",
    "Database": "OracleOperator / MsSqlOperator / PythonOperator",
    "Unknown": "Custom operator / assessment required",
}


CTM_AIRFLOW_REFERENCE: list[tuple[str, str]] = [
    ("eventsToWaitFor + eventsToAdd", "Task dependencies (>>)"),
    ("Cross-folder eventsToWaitFor", "ExternalTaskSensor"),
    ("Job:Dummy (no FileName)", "EmptyOperator"),
    ("Job:Dummy (with FileName/Script)", "VERIFY - may be BashOperator"),
    ("Job:Command / Job:Script / Job:EmbeddedScript", "BashOperator / SSHOperator"),
    ("Job:FileWatcher:Create", "FileSensor / SFTPSensor (mode=reschedule)"),
    ("Job:FileWatcher:Delete", "FileSensor (check deletion, mode=reschedule)"),
    ("Job:Database:StoredProcedure", "OracleOperator / MsSqlOperator"),
    ("Job:SLAManagement", "sla=timedelta(...) + sla_miss_callback"),
    ("Rerun: Every N Units Times M", "retries=M, retry_delay=timedelta(N units)"),
    ("Resource:Pool Quantity=N", "Airflow Pool (pool_slots=N)"),
    ("Resource:Lock Exclusive", "Airflow Pool with pool_slots=1 (singleton)"),
    ("When: FromTime / ToTime", "TimeSensor or timetable plugin"),
    ("When: RuleBasedCalendars", "Custom Airflow timetable plugin"),
    ("When: MonthDays / WeekDays", "Cron expression in schedule_interval"),
    ("If:CompletionStatus conditional", "BranchPythonOperator + skip logic"),
    ("Variables: PARM1, PARM2", "Airflow params or Variable.get()"),
    ("%%$ODATE", "{{ ds }} (execution date)"),
    ("%%JOBNAME", "{{ task.task_id }}"),
    ("%%ORDERID / %%RUNCOUNT", "{{ run_id }}"),
    ("OrderMethod: Manual", "schedule=None, trigger via REST API / UI"),
    ("Priority: Very Low / High", "priority_weight on task"),
]


def _as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def _bool_like(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        return value != 0
    if isinstance(value, str):
        return value.strip().upper() in {"Y", "YES", "TRUE", "1"}
    return False


def _to_int(value: Any, default: int = 0) -> int:
    if value is None:
        return default
    if isinstance(value, int):
        return value
    text = str(value).strip()
    if not text:
        return default
    digits = re.sub(r"[^\d-]", "", text)
    if not digits:
        return default
    try:
        return int(digits)
    except ValueError:
        return default


def _tokens(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [token for token in re.split(r"[,\s]+", value.strip()) if token]
    if isinstance(value, list):
        items: list[str] = []
        for item in value:
            items.extend(_tokens(item))
        return items
    if isinstance(value, dict):
        items: list[str] = []
        token_keys = {
            "name",
            "value",
            "event",
            "events",
            "condition",
            "conditions",
            "incondition",
            "inconditions",
            "outcondition",
            "outconditions",
            "eventstowaitfor",
            "eventstoadd",
            "eventstodelete",
            "eventtowaitfor",
            "waitfor",
            "waitforevents",
        }
        for key, candidate_value in value.items():
            if str(key).strip().lower() in token_keys:
                items.extend(_tokens(candidate_value))
        return items
    return [str(value)]


def _collect_job_dict_strings(obj: Any) -> list[str]:
    result: list[str] = []
    if isinstance(obj, dict):
        for key, value in obj.items():
            result.append(str(key))
            result.extend(_collect_job_dict_strings(value))
    elif isinstance(obj, list):
        for item in obj:
            result.extend(_collect_job_dict_strings(item))
    elif isinstance(obj, (str, int, float, bool)):
        result.append(str(obj))
    return result


def _extract_dynamic_variables(text: str) -> list[str]:
    patterns = [
        r"%%[A-Za-z0-9_\.]+",
        r"\$\{[A-Za-z0-9_\.:-]+\}",
        r"\{\{\s*[^}]+\s*\}\}",
        r"%[A-Za-z0-9_]+%",
    ]
    found: list[str] = []
    for pattern in patterns:
        found.extend(re.findall(pattern, text))
    return sorted(set(found))


def _parse_json_upload(raw_text: str) -> Any:
    return json.loads(raw_text)


def _folder_name(folder_raw: dict[str, Any], fallback: str) -> str:
    return str(
        folder_raw.get("Name")
        or folder_raw.get("name")
        or folder_raw.get("FolderName")
        or fallback
    )


def _extract_folders(raw: Any) -> list[dict[str, Any]]:
    def _looks_like_folder(candidate: dict[str, Any]) -> bool:
        folder_markers = {
            "Jobs",
            "jobs",
            "SMARTFolder",
            "SubFolders",
            "Objects",
            "ControlmServer",
            "SiteStandard",
            "OrderMethod",
        }
        return any(key in candidate for key in folder_markers)

    if isinstance(raw, list):
        candidates = raw
    elif isinstance(raw, dict):
        if "folders" in raw:
            candidates = _as_list(raw.get("folders"))
        elif "Folders" in raw:
            candidates = _as_list(raw.get("Folders"))
        elif "Folder" in raw:
            candidates = _as_list(raw.get("Folder"))
        elif _looks_like_folder(raw):
            candidates = [raw]
        else:
            folder_entries = [
                (key, value)
                for key, value in raw.items()
                if isinstance(value, dict) and _looks_like_folder(value)
            ]
            if folder_entries:
                candidates = []
                for folder_name, folder_value in folder_entries:
                    folder_obj = dict(folder_value)
                    if not any(key in folder_obj for key in ("Name", "name", "FolderName")):
                        folder_obj["Name"] = str(folder_name)
                    candidates.append(folder_obj)
            else:
                candidates = [raw]
    else:
        raise ValueError("Unsupported Control-M JSON shape")

    folders: list[dict[str, Any]] = []
    for index, item in enumerate(candidates, start=1):
        if isinstance(item, dict):
            folders.append(item)
        else:
            folders.append({"Name": f"folder_{index}", "Jobs": []})
    return folders


def _extract_jobs(folder_raw: dict[str, Any]) -> list[dict[str, Any]]:
    jobs: list[dict[str, Any]] = []
    for key in ("Jobs", "jobs", "SMARTFolder", "SubFolders", "Objects"):
        raw_jobs = folder_raw.get(key)
        if isinstance(raw_jobs, dict):
            for job_name, job_value in raw_jobs.items():
                if isinstance(job_value, dict):
                    job_obj = dict(job_value)
                    if not any(name_key in job_obj for name_key in ("Name", "name", "JobName", "jobName")):
                        job_obj["Name"] = str(job_name)
                    jobs.append(job_obj)
            continue

        for item in _as_list(raw_jobs):
            if isinstance(item, dict):
                jobs.append(item)
    return jobs


def _count_subfolders(folder_raw: dict[str, Any]) -> int:
    subfolders = folder_raw.get("SubFolders")
    if isinstance(subfolders, dict):
        return len(subfolders)
    if isinstance(subfolders, list):
        return len([item for item in subfolders if isinstance(item, dict)])
    smart = folder_raw.get("SMARTFolder")
    if isinstance(smart, dict):
        return len(smart)
    if isinstance(smart, list):
        return len([item for item in smart if isinstance(item, dict)])
    return 0


def _extract_job_rerun(job_raw: dict[str, Any]) -> tuple[int, str, str]:
    rerun_limit = job_raw.get("RerunLimit")
    times = 0
    every = ""
    units = ""

    if isinstance(rerun_limit, dict):
        times = _to_int(rerun_limit.get("Times"), 0)
        every = str(rerun_limit.get("Every") or "").strip()
        units = str(rerun_limit.get("Units") or "").strip()
    else:
        times = _to_int(rerun_limit, 0)

    if not every:
        every = str(job_raw.get("RerunEvery") or job_raw.get("SearchInterval") or "").strip()
    if not units:
        units = str(job_raw.get("RerunUnits") or job_raw.get("SearchUnits") or "").strip()

    return (times, every, units)


def _extract_cyclic(job_raw: dict[str, Any], folder_raw: dict[str, Any]) -> tuple[bool, str, str, str]:
    cyclic_flag = _bool_like(job_raw.get("Cyclic")) or _bool_like(folder_raw.get("Cyclic"))
    interval = (
        job_raw.get("CyclicInterval")
        or folder_raw.get("CyclicInterval")
        or job_raw.get("Interval")
        or folder_raw.get("Interval")
        or ""
    )
    if interval:
        cyclic_flag = True

    if not cyclic_flag:
        return (False, "", "", "")

    units = str(job_raw.get("CyclicUnits") or folder_raw.get("CyclicUnits") or "Minutes").strip()
    max_times = str(job_raw.get("RerunSpecificTimes") or job_raw.get("MaxRunTimes") or "").strip()

    interval_text = str(interval).strip()
    if interval_text:
        schedule = f"{interval_text} {units}".strip()
        cyclic_type = "Interval"
    else:
        schedule = "Cyclic"
        cyclic_type = "Cyclic"

    return (True, cyclic_type, schedule, max_times)


def _parse_resource_refs(job_raw: dict[str, Any]) -> list[str]:
    refs: list[str] = []
    resource_markers = ("resource", "pool", "lock", "semaphore", "mutex")
    ignored = ("notify", "notification")

    for key, value in job_raw.items():
        key_l = str(key).lower()
        if any(marker in key_l for marker in ignored):
            continue
        if any(marker in key_l for marker in resource_markers):
            tokens = _tokens(value)
            if tokens:
                refs.extend(f"{key}:{token}" for token in tokens)
            else:
                flattened = " ".join(_collect_job_dict_strings(value)) if isinstance(value, (dict, list)) else str(value)
                if flattened.strip():
                    refs.append(f"{key}:{flattened.strip()}")

    return sorted(set(refs))


def _is_critical_job(job_raw: dict[str, Any]) -> bool:
    if _bool_like(job_raw.get("Critical")):
        return True
    priority = str(job_raw.get("Priority") or "").strip().upper()
    return priority in {"HIGH", "VERY_HIGH", "URGENT", "P1", "P0"}


def _display_job_type(raw_type: str, normalized_type: str) -> str:
    if raw_type:
        return raw_type
    if normalized_type == "Command":
        return "Job:Command"
    if normalized_type == "Script":
        return "Job:Script"
    if normalized_type == "EmbeddedScript":
        return "Job:EmbeddedScript"
    if normalized_type == "FileWatcher":
        return "Job:FileWatcher"
    if normalized_type == "SLAManagement":
        return "Job:SLAManagement"
    if normalized_type == "Dummy":
        return "Job:Dummy"
    if normalized_type == "Database":
        return "Job:Database"
    return normalized_type


def _parse_calendar(folder_raw: dict[str, Any]) -> list[str]:
    calendar_tokens: list[str] = []
    for key in ("Calendar", "Calendars", "RuleBasedCalendar", "RuleBasedCalendars"):
        calendar_tokens.extend(_tokens(folder_raw.get(key)))

    weekdays = _tokens(folder_raw.get("WeekDays") or folder_raw.get("weekDays"))
    month_days = _tokens(folder_raw.get("MonthDays") or folder_raw.get("monthDays"))
    months = _tokens(folder_raw.get("Months") or folder_raw.get("months"))

    if weekdays:
        calendar_tokens.append(f"WeekDays:{','.join(weekdays)}")
    if month_days:
        calendar_tokens.append(f"MonthDays:{','.join(month_days)}")
    if months:
        calendar_tokens.append(f"Months:{','.join(months)}")

    when_obj = folder_raw.get("When")
    if isinstance(when_obj, dict):
        for key in ("Calendar", "Calendars", "RuleBasedCalendar", "RuleBasedCalendars", "MonthDaysCalendar", "ConfirmationCalendars"):
            calendar_tokens.extend(_tokens(when_obj.get(key)))

        when_weekdays = _tokens(when_obj.get("WeekDays"))
        when_month_days = _tokens(when_obj.get("MonthDays"))
        when_months = _tokens(when_obj.get("Months"))
        when_specific_dates = _tokens(when_obj.get("SpecificDates"))

        if when_weekdays:
            calendar_tokens.append(f"WeekDays:{','.join(when_weekdays)}")
        if when_month_days:
            calendar_tokens.append(f"MonthDays:{','.join(when_month_days)}")
        if when_months:
            calendar_tokens.append(f"Months:{','.join(when_months)}")
        if when_specific_dates:
            calendar_tokens.append(f"SpecificDates:{','.join(when_specific_dates)}")

    return sorted(set(token for token in calendar_tokens if token))


def _extract_schedule_times(folder_raw: dict[str, Any], job_raw: dict[str, Any]) -> tuple[str, str, str]:
    def _normalize_time(value: Any) -> str:
        if value is None:
            return ""
        if isinstance(value, int):
            return str(value).zfill(4)
        text = str(value).strip()
        if not text:
            return ""
        if text in {">", "<", ">=", "<=", "ANY", "NONE"}:
            return ""
        digits = re.sub(r"[^0-9]", "", text)
        if len(digits) >= 4:
            digits = digits[:4]
            return f"{digits[:2]}:{digits[2:]}"
        if len(digits) == 3:
            digits = digits.zfill(4)
            return f"{digits[:2]}:{digits[2:]}"
        return ""

    when_job = job_raw.get("When")
    when_folder = folder_raw.get("When")
    when_obj = when_job if isinstance(when_job, dict) else (when_folder if isinstance(when_folder, dict) else {})

    from_time = (
        when_obj.get("FromTime")
        or job_raw.get("FromTime")
        or folder_raw.get("FromTime")
        or job_raw.get("StartTime")
        or folder_raw.get("StartTime")
    )
    to_time = when_obj.get("ToTime") or job_raw.get("ToTime") or folder_raw.get("ToTime")

    from_norm = _normalize_time(from_time)
    to_norm = _normalize_time(to_time)
    if from_norm and to_norm:
        window = f"{from_norm}-{to_norm}"
    elif from_norm:
        window = from_norm
    elif to_norm:
        window = f"until {to_norm}"
    else:
        window = "Not specified"
    return (from_norm or "-", to_norm or "-", window)


def _schedule_type(folder_raw: dict[str, Any], job_raw: dict[str, Any]) -> tuple[str, str]:
    raw_schedule = (
        job_raw.get("Schedule")
        or folder_raw.get("Schedule")
        or job_raw.get("RunType")
        or folder_raw.get("RunType")
        or job_raw.get("OrderMethod")
        or folder_raw.get("OrderMethod")
        or ""
    )
    schedule_text = str(raw_schedule).strip()

    if str(folder_raw.get("Cyclic", "")).upper() in {"Y", "YES", "TRUE", "1"} or folder_raw.get("CyclicInterval"):
        return ("cyclic", f"Interval={folder_raw.get('CyclicInterval') or folder_raw.get('Interval') or 'unknown'}")

    has_calendar = any(
        folder_raw.get(key)
        for key in ("WeekDays", "weekDays", "MonthDays", "monthDays", "Months", "months", "Calendar", "Calendars")
    )
    if has_calendar:
        return ("calendar", "Calendar-driven")

    when_obj = job_raw.get("When") if isinstance(job_raw.get("When"), dict) else folder_raw.get("When")
    if isinstance(when_obj, dict):
        when_calendar_keys = (
            "WeekDays",
            "MonthDays",
            "Months",
            "SpecificDates",
            "RuleBasedCalendar",
            "RuleBasedCalendars",
            "MonthDaysCalendar",
            "FromTime",
            "ToTime",
        )
        if any(when_obj.get(key) for key in when_calendar_keys):
            return ("calendar", "When-calendar-driven")

    if schedule_text.upper() in {"MANUAL", "NONE", "ONDEMAND", "ON_DEMAND"}:
        return ("manual", schedule_text)

    if not schedule_text:
        return ("manual", "No schedule declared")

    return ("scheduled", schedule_text)
@dataclass
class JobRecord:
    record_id: str
    folder: str
    job_name: str
    normalized_type: str
    raw_type: str
    feature_combo: str
    migration_status: str
    airflow_equivalent: str
    migration_notes: str
    dependencies: list[str]
    unresolved_dependencies: list[str]
    in_events: list[str]
    out_events: list[str]
    event_to_wait_for: list[str]
    cross_folder_events: list[str]
    variables: list[str]
    dynamic_variables: list[str]
    uses_odate: bool
    uses_orderid: bool
    schedule_type: str
    schedule_detail: str
    schedule_from_time: str
    schedule_to_time: str
    schedule_time_window: str
    calendar_used: list[str]
    host_groups: list[str]
    action_dependencies: list[str]
    resource_refs: list[str]
    host: str
    application: str
    sub_application: str
    created_by: str
    description: str
    priority: str
    ctm_type: str
    critical: bool
    is_cyclic: bool
    cyclic_type: str
    cyclic_schedule: str
    cyclic_max_times: str
    rerun_limit: int
    rerun_every: str
    rerun_units: str
    suspicious_dummy: bool
    standalone: bool = False
    dependents: int = 0


def _detect_job_type(job_raw: dict[str, Any], schedule_type: str, in_events: list[str], wait_events: list[str]) -> tuple[str, str]:
    raw_type = str(
        job_raw.get("JobType")
        or job_raw.get("jobType")
        or job_raw.get("Type")
        or job_raw.get("type")
        or job_raw.get("TaskType")
        or job_raw.get("ApplicationType")
        or ""
    ).strip()

    lowered = raw_type.lower()
    for hint, normalized in TYPE_HINTS.items():
        if hint in lowered:
            return (normalized, raw_type)

    text_blob = " ".join(_collect_job_dict_strings(job_raw)).lower()

    if any(token in text_blob for token in ("filewatch", "waitforfile", "filewatcher", "filename")):
        return ("FileWatcher", raw_type)
    if any(token in text_blob for token in ("embeddedscript", "embedded_script", "inlinepython")):
        return ("EmbeddedScript", raw_type)
    if any(token in text_blob for token in ("sla", "deadline", "servicelevel")):
        return ("SLAManagement", raw_type)
    if any(token in text_blob for token in ("dataset", "dataasset")):
        return ("Dataset", raw_type)
    if any(token in text_blob for token in ("sql", "database", "db_connection", "jdbc", "oracle", "postgres")):
        return ("Database", raw_type)

    command = str(job_raw.get("Command") or job_raw.get("command") or job_raw.get("Script") or "").strip()
    if command:
        cmd_lower = command.lower()
        if any(token in cmd_lower for token in (".sh", "bash ", "/bin/bash", "#!/bin/bash")):
            return ("BashOperator", raw_type)
        if any(token in cmd_lower for token in ("python ", "perl ", "ruby ", "node ", ".py", ".pl", ".rb", ".js")):
            return ("Script", raw_type)
        return ("Command", raw_type)

    if in_events or wait_events:
        return ("EventDriven", raw_type)

    if schedule_type in {"calendar", "cyclic"}:
        return ("CalendarBased", raw_type)

    if str(job_raw.get("Dummy") or "").upper() in {"Y", "YES", "TRUE", "1"}:
        return ("Dummy", raw_type)

    return ("Unknown", raw_type)


def _parse_dependencies(job_raw: dict[str, Any]) -> list[str]:
    dependency_fields = [
        "DependsOn",
        "dependsOn",
        "Dependencies",
        "Predecessors",
        "predecessors",
        "Parents",
        "parentJobs",
    ]
    deps: list[str] = []
    for field in dependency_fields:
        deps.extend(_tokens(job_raw.get(field)))
    return sorted(set(dep for dep in deps if dep))


def _parse_events(job_raw: dict[str, Any]) -> tuple[list[str], list[str], list[str]]:
    in_fields = [
        "InCondition",
        "InConditions",
        "inConditions",
        "EventsToWaitFor",
        "eventsToWaitFor",
        "eventToWaitFor",
        "WaitForEvents",
    ]
    out_fields = [
        "OutCondition",
        "OutConditions",
        "outConditions",
        "EventsToAdd",
        "eventsToAdd",
        "eventToAdd",
    ]
    explicit_wait_fields = ["EventToWaitFor", "eventToWaitFor", "WaitFor", "eventsToDelete", "EventsToDelete"]

    in_events: list[str] = []
    out_events: list[str] = []
    wait_events: list[str] = []

    for field in in_fields:
        in_events.extend(_tokens(job_raw.get(field)))
    for field in out_fields:
        out_events.extend(_tokens(job_raw.get(field)))
    for field in explicit_wait_fields:
        wait_events.extend(_tokens(job_raw.get(field)))

    when_obj = job_raw.get("When")
    if isinstance(when_obj, dict):
        for field in in_fields:
            in_events.extend(_tokens(when_obj.get(field)))
        for field in out_fields:
            out_events.extend(_tokens(when_obj.get(field)))
        for field in explicit_wait_fields:
            wait_events.extend(_tokens(when_obj.get(field)))

    return (
        sorted(set(event for event in in_events if event)),
        sorted(set(event for event in out_events if event)),
        sorted(set(event for event in wait_events if event)),
    )


def _parse_host_groups(job_raw: dict[str, Any]) -> list[str]:
    host_groups: list[str] = []
    for field in ("HostGroup", "HostGroups"):
        host_groups.extend(_tokens(job_raw.get(field)))

    # In Control-M exports, Host can represent host-group when RunOnAllAgentsInGroup=Y.
    if _bool_like(job_raw.get("RunOnAllAgentsInGroup")):
        host_groups.extend(_tokens(job_raw.get("Host")))

    return sorted(set(group for group in host_groups if group))


def _parse_action_dependencies(job_raw: dict[str, Any]) -> list[str]:
    action_markers: set[str] = set()

    if _parse_dependencies(job_raw):
        action_markers.add("DependsOn")
    if any(_tokens(job_raw.get(field)) for field in ("eventsToWaitFor", "EventsToWaitFor", "EventToWaitFor")):
        action_markers.add("WaitForEvents")
    if any(_tokens(job_raw.get(field)) for field in ("eventsToAdd", "EventsToAdd")):
        action_markers.add("AddEvents")
    if any(_tokens(job_raw.get(field)) for field in ("eventsToDelete", "EventsToDelete")):
        action_markers.add("DeleteEvents")
    if any(_tokens(job_raw.get(field)) for field in ("InCondition", "InConditions", "OutCondition", "OutConditions")):
        action_markers.add("Conditions")

    for key, value in job_raw.items():
        key_lower = str(key).lower()

        if key_lower.startswith("ifbase:job:"):
            action_markers.add(str(key))
            continue

        if key_lower.startswith("action:"):
            action_markers.add(str(key))
            continue

        if key_lower.startswith("if:"):
            flattened = " ".join(_collect_job_dict_strings(value)) if isinstance(value, (dict, list)) else str(value)
            if any(token in flattened.lower() for token in ("event", "condition", "wait", "dependency", "job")):
                action_markers.add(str(key))

    return sorted(action_markers)


def _parse_variables(job_raw: dict[str, Any], command: str) -> tuple[list[str], list[str]]:
    variable_tokens: list[str] = []

    for field in ("Variables", "Variable", "variables", "AutoEdit", "SetVar", "SetVariable"):
        value = job_raw.get(field)
        if isinstance(value, dict):
            variable_tokens.extend(str(key) for key in value.keys())
            variable_tokens.extend(_collect_job_dict_strings(value))
        else:
            variable_tokens.extend(_tokens(value))

    variable_tokens.extend(_extract_dynamic_variables(command))

    all_variables = sorted(set(token for token in variable_tokens if token))
    dynamic_variables = sorted(set(_extract_dynamic_variables(" ".join(all_variables + [command]))))

    return (all_variables, dynamic_variables)


def _collect_functional_text(job_raw: dict[str, Any], command: str, variables: list[str]) -> str:
    parts: list[str] = [command, " ".join(variables)]

    for key in ("ODATE", "ODate", "odate", "OrderID", "ORDERID", "orderId"):
        if key in job_raw:
            parts.append(str(job_raw.get(key)))

    for key in ("Script", "script", "Arguments", "Args", "Parameter", "Parameters"):
        if key in job_raw:
            value = job_raw.get(key)
            if isinstance(value, (dict, list)):
                parts.extend(_collect_job_dict_strings(value))
            else:
                parts.append(str(value))

    for key in (
        "InCondition",
        "InConditions",
        "OutCondition",
        "OutConditions",
        "eventsToWaitFor",
        "eventsToAdd",
        "eventsToDelete",
        "EventToWaitFor",
    ):
        if key in job_raw:
            parts.extend(_tokens(job_raw.get(key)))

    return " ".join(part for part in parts if part)


def _detect_functional_token_usage(job_raw: dict[str, Any], command: str, variables: list[str]) -> tuple[bool, bool]:
    text = _collect_functional_text(job_raw, command, variables).upper()
    uses_odate = bool(re.search(r"(?<![A-Z0-9_])(%%\$?ODATE|ODATE)(?![A-Z0-9_])", text))
    uses_orderid = bool(re.search(r"(?<![A-Z0-9_])(%%\$?ORDERID|ORDERID)(?![A-Z0-9_])", text))
    return (uses_odate, uses_orderid)


def _migration_decision(
    normalized_type: str,
    has_action_dependencies: bool,
    has_cross_folder_event: bool,
    has_unresolved_dependencies: bool,
) -> tuple[str, str, str]:
    base = MIGRATION_GUIDANCE.get(normalized_type, MIGRATION_GUIDANCE["Unknown"])
    status, airflow_equivalent, notes = base

    if has_action_dependencies:
        notes = f"{notes} Action-based dependencies need rule translation."

    if has_cross_folder_event and status == "Migratable":
        status = "Partially Migratable"
        notes = f"{notes} Cross-folder orchestration needs ExternalTaskSensor/Datasets."

    if has_unresolved_dependencies:
        status = "Needs Assessment"
        notes = f"{notes} Some dependencies are unresolved and need design clarification."

    return (status, airflow_equivalent, notes)


def _feature_combo(normalized_type: str, schedule_type: str, has_events: bool, has_calendar: bool, has_host_group: bool) -> str:
    features = {normalized_type}
    if has_events:
        features.add("EventDriven")
    if has_calendar or schedule_type in {"calendar", "cyclic"}:
        features.add("CalendarBased")
    if has_host_group:
        features.add("HostGroup")
    return "+".join(sorted(features))


def _safe_node_id(value: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9_]+", "_", value.strip())
    cleaned = re.sub(r"_+", "_", cleaned).strip("_")
    if not cleaned:
        return "NODE"
    if cleaned[0].isdigit():
        return f"N_{cleaned}"
    return cleaned


def _folder_bau_category(
    folder_name: str,
    application: str,
    sub_application: str,
    records: list[JobRecord],
) -> str:
    text = " ".join([folder_name, application, sub_application]).lower()
    technical_keywords = {"infra", "ops", "admin", "util", "monitor", "support", "control", "platform", "sys"}
    bau_keywords = {"trade", "payment", "risk", "billing", "settlement", "customer", "finance", "market", "order"}

    has_tech_kw = any(keyword in text for keyword in technical_keywords)
    has_bau_kw = any(keyword in text for keyword in bau_keywords)

    tech_types = sum(1 for record in records if record.normalized_type in {"Dummy", "FileWatcher", "SLAManagement"})
    bau_types = sum(1 for record in records if record.normalized_type in {"Command", "Script", "Database", "BashOperator"})
    total = max(len(records), 1)

    tech_ratio = tech_types / total
    bau_ratio = bau_types / total

    is_technical = has_tech_kw or tech_ratio >= 0.45
    is_bau = has_bau_kw or bau_ratio >= 0.45

    if is_technical and is_bau:
        return "Mixed"
    if is_bau:
        return "BAU"
    if is_technical:
        return "Technical"
    return "Unknown"


def _folder_classification(
    folder_name: str,
    site_standard: str,
    created_by: str,
    records: list[JobRecord],
    standalone_count: int,
    cross_folder_deps: int,
) -> tuple[str, str]:
    text = " ".join([folder_name, site_standard, created_by]).lower()
    demo_markers = {"demo", "test", "sandbox", "dev", "poc", "sample", "uat"}

    if "no-wcm-rule" in text or any(marker in text for marker in demo_markers):
        return (
            "DEMO / ARCHIVE",
            "SiteStandard indicates non-governed workload or naming suggests test/demo scope",
        )

    total = max(len(records), 1)
    dummy_ratio = sum(1 for record in records if record.normalized_type == "Dummy") / total
    if dummy_ratio > 0.7:
        return ("RETIRE / DECOMMISSION", "Mostly control/dummy workload with limited executable value")

    if standalone_count / total >= 0.8 and cross_folder_deps == 0:
        return ("SHIFT LEFT -> CRON", "Predominantly independent jobs suitable for standalone scheduling")

    return ("MIGRATE TO AIRFLOW", "Executable workload with manageable orchestration dependencies")


def _priority_label(classification: str, jobs: int, cross_folder_deps: int, critical_jobs: int, cyclic_jobs: int) -> str:
    if classification in {"DEMO / ARCHIVE", "RETIRE / DECOMMISSION"}:
        return "P5 - Defer"

    score = cross_folder_deps * 3 + critical_jobs * 2 + cyclic_jobs + max(jobs // 80, 0)
    if jobs >= 800 or score >= 70:
        return "P1 - Highest"
    if jobs >= 300 or score >= 35:
        return "P2 - High"
    if jobs >= 120 or score >= 18:
        return "P3 - Medium"
    return "P4 - Low"


def _effort_label(jobs: int, cross_folder_deps: int) -> str:
    if jobs <= 30 and cross_folder_deps <= 5:
        return "XS (< 1 day)"
    if jobs <= 100 and cross_folder_deps <= 15:
        return "S (1-3 days)"
    if jobs <= 300 and cross_folder_deps <= 40:
        return "M (3-7 days)"
    if jobs <= 800:
        return "L (1-3 weeks)"
    return "XL (3+ weeks)"


def _dynamic_var_equivalent(variable: str) -> str:
    upper = variable.upper()
    if "ODATE" in upper:
        return "{{ ds }}"
    if "JOBNAME" in upper:
        return "{{ task.task_id }}"
    if "ORDERID" in upper or "RUNCOUNT" in upper:
        return "{{ run_id }}"
    return "Airflow Variable / params / macro"


def _markdown_table(headers: list[str], rows: list[list[str]]) -> list[str]:
    lines = ["| " + " | ".join(headers) + " |", "|---" * len(headers) + "|"]
    for row in rows:
        safe = [value.replace("\n", " ").replace("|", "\\|") for value in row]
        lines.append("| " + " | ".join(safe) + " |")
    return lines


def _format_detected(value: bool) -> str:
    return "Yes" if value else "-"


def _build_markdown_report(report: dict[str, Any]) -> str:
    metadata = report.get("report_metadata", {})
    summary = report.get("summary", {})
    folder_details = report.get("folder_detailed_analysis", [])
    job_inventory = report.get("job_inventory", [])
    category_summary = report.get("classification_summary", {})
    complexity = report.get("workload_complexity", {})
    bau_breakdown = report.get("bau_technical_breakdown", {})

    generated = metadata.get("generated_utc", "")
    source_file = metadata.get("source_file", "uploaded.json")
    total_folders = str(summary.get("total_folders", 0))
    total_jobs = str(summary.get("total_jobs", 0))

    lines: list[str] = []
    lines.append("# Control-M to Airflow - Migration Analysis Report")
    lines.append("")
    lines.extend(
        _markdown_table(
            ["", ""],
            [
                ["**Generated**", generated],
                ["**Source**", source_file],
                ["**Folders analysed**", total_folders],
                ["**Total jobs**", total_jobs],
            ],
        )
    )
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## Executive Summary")
    lines.append("")
    lines.extend(
        _markdown_table(
            ["Category", "Folders", "Jobs"],
            [
                ["Migrate to Airflow", str(category_summary.get("MIGRATE TO AIRFLOW", {}).get("folders", 0)), str(category_summary.get("MIGRATE TO AIRFLOW", {}).get("jobs", 0))],
                ["Shift Left -> Cron", str(category_summary.get("SHIFT LEFT -> CRON", {}).get("folders", 0)), str(category_summary.get("SHIFT LEFT -> CRON", {}).get("jobs", 0))],
                ["Retire / Decommission", str(category_summary.get("RETIRE / DECOMMISSION", {}).get("folders", 0)), str(category_summary.get("RETIRE / DECOMMISSION", {}).get("jobs", 0))],
                ["Demo / Archive", str(category_summary.get("DEMO / ARCHIVE", {}).get("folders", 0)), str(category_summary.get("DEMO / ARCHIVE", {}).get("jobs", 0))],
                ["**TOTAL**", f"**{total_folders}**", f"**{total_jobs}**"],
            ],
        )
    )
    lines.append("")

    cross_folder_total = int(complexity.get("cross_folder_event_dependencies", 0))
    if cross_folder_total > 0:
        lines.append(
            f"> Cross-folder event dependencies detected: **{cross_folder_total}**. "
            "Validate full export coverage before final migration sizing."
        )
        lines.append("")

    lines.append("### Workload Complexity Metrics")
    lines.append("")
    lines.extend(
        _markdown_table(
            ["Metric", "Count"],
            [
                ["Cyclic (self-rescheduling) jobs", str(complexity.get("cyclic_jobs", 0))],
                ["Standalone jobs (no inbound deps)", str(complexity.get("standalone_inbound_jobs", 0))],
                ["Jobs targeting host groups", str(complexity.get("jobs_with_hostgroups", 0))],
                ["Jobs with unresolved CTM dynamic variables", str(complexity.get("jobs_with_dynamic_variables", 0))],
                ["Resource Pool / Lock references", str(complexity.get("jobs_with_resources", 0))],
                ["Action-based dependency edges (IfStatement)", str(complexity.get("jobs_with_action_dependencies", 0))],
                ["Nested sub-folders", str(complexity.get("nested_subfolders", 0))],
            ],
        )
    )
    lines.append("")
    lines.append("### Folder BAU / Technical Breakdown")
    lines.append("")
    lines.extend(
        _markdown_table(
            ["Category", "Folders"],
            [
                ["BAU (business workload)", str(bau_breakdown.get("BAU", 0))],
                ["Technical / Ops", str(bau_breakdown.get("Technical", 0))],
                ["Mixed BAU + Technical", str(bau_breakdown.get("Mixed", 0))],
                ["Uncategorised", str(bau_breakdown.get("Unknown", 0))],
            ],
        )
    )
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## Job Inventory")
    lines.append("")

    inventory_rows: list[list[str]] = []
    for index, row in enumerate(job_inventory, start=1):
        inventory_rows.append(
            [
                str(index),
                row.get("folder", ""),
                row.get("server", ""),
                row.get("application", ""),
                str(row.get("jobs", 0)),
                str(row.get("cyclic_jobs", 0)),
                str(row.get("critical_jobs", 0)),
                str(row.get("dummy_jobs", 0)),
                str(row.get("external_dependencies", 0)),
                row.get("bau_category", "Unknown"),
                row.get("classification", ""),
                row.get("priority", ""),
            ]
        )

    lines.extend(
        _markdown_table(
            ["#", "Folder", "Server", "Application", "Jobs", "Cyclic", "Critical", "Dummy", "Ext.Deps", "Category", "Classification", "Priority"],
            inventory_rows,
        )
    )
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## Detailed Folder Analysis")
    lines.append("")

    for index, folder in enumerate(folder_details, start=1):
        lines.append(f"### {index}. `{folder.get('folder', '')}`")
        lines.append("")
        lines.append(f"**{folder.get('classification', '')}**")
        lines.append("")
        lines.extend(
            _markdown_table(
                ["Attribute", "Value"],
                [
                    ["Source File", folder.get("source_file", "")],
                    ["CTM Server", folder.get("controlm_server", "")],
                    ["Application", folder.get("application", "")],
                    ["Sub-Application", folder.get("sub_application", "")],
                    ["Order Method", folder.get("order_method", "")],
                    ["Created By", folder.get("created_by", "")],
                    ["Site Standard", folder.get("site_standard", "")],
                    ["Description", folder.get("description", "")],
                    ["**Total Jobs**", f"**{folder.get('total_jobs', 0)}**"],
                    ["Standalone Jobs (no inbound deps)", str(folder.get("standalone_inbound", 0))],
                    ["Cyclic Jobs", str(folder.get("cyclic_jobs", 0))],
                    ["Mixed Cyclic+Acyclic", "Yes" if folder.get("mixed_cyclic") else "No"],
                    ["Critical Jobs", str(folder.get("critical_jobs", 0))],
                    ["Dummy Jobs", str(folder.get("dummy_jobs", 0))],
                    ["Suspicious Dummies (FileName set)", str(folder.get("suspicious_dummy_jobs", 0))],
                    ["Sub-folders", str(folder.get("subfolders", 0))],
                    ["Cross-folder Event Deps", str(folder.get("cross_folder_dependencies", 0))],
                    ["Action-based Dep Edges", str(folder.get("action_dependency_jobs", 0))],
                    ["Host Groups", str(folder.get("host_group_jobs", 0))],
                    ["Resource Pools/Locks", str(folder.get("resource_jobs", 0))],
                    ["Dynamic CTM Variables", str(folder.get("dynamic_variable_jobs", 0))],
                    ["BAU/Technical Category", folder.get("bau_category", "Unknown")],
                    ["**Priority**", f"**{folder.get('priority', '')}**"],
                    ["**Effort**", f"**{folder.get('effort', '')}**"],
                ],
            )
        )
        lines.append("")
        lines.append("**Classification Rationale:**  ")
        lines.append(folder.get("classification_rationale", "No explicit rationale"))
        lines.append("")

        lines.append("**Job Type Breakdown:**")
        lines.append("")
        type_rows = [
            [row.get("ctm_type", ""), str(row.get("count", 0)), row.get("airflow_operator", "")]
            for row in folder.get("job_type_breakdown", [])
        ]
        lines.extend(_markdown_table(["CTM Type", "Count", "Airflow Operator"], type_rows))
        lines.append("")

        cross_deps = folder.get("cross_folder_dependency_list", [])
        if cross_deps:
            lines.append(f"**Cross-folder Dependencies** ({len(cross_deps)} total):")
            lines.append("")
            preview = cross_deps[:10]
            for dep in preview:
                lines.append(f"- `{dep}`")
            remaining = len(cross_deps) - len(preview)
            if remaining > 0:
                lines.append(f"- _... and {remaining} more_")
            lines.append("")

        standalone = folder.get("standalone_jobs", [])
        if standalone:
            lines.append(f"**Standalone Jobs** ({folder.get('standalone_inbound', 0)} - no inbound event dependencies):")
            lines.append("")
            rows = [
                [item.get("job_name", ""), item.get("type", ""), item.get("host", "")]
                for item in standalone[:10]
            ]
            if len(standalone) > 10:
                rows.append([f"_... and {len(standalone) - 10} more_", "", ""])
            lines.extend(_markdown_table(["Job Name", "Type", "Host"], rows))
            lines.append("")

        retries = folder.get("retry_jobs", [])
        if retries:
            lines.append(f"**Retry-on-Failure Jobs** ({len(retries)} - RerunLimit configured):")
            lines.append("")
            rows = [
                [
                    item.get("job_name", ""),
                    str(item.get("max_retries", 0)),
                    item.get("interval", ""),
                    item.get("units", ""),
                    item.get("airflow_mapping", ""),
                ]
                for item in retries[:15]
            ]
            if len(retries) > 15:
                rows.append([f"_... and {len(retries) - 15} more_", "", "", "", ""])
            lines.extend(_markdown_table(["Job Name", "Max Retries", "Interval", "Units", "Airflow Mapping"], rows))
            lines.append("")

        cyclic_jobs = folder.get("cyclic_job_rows", [])
        if cyclic_jobs:
            lines.append(f"**Cyclic Jobs** ({len(cyclic_jobs)} - self-rescheduling):")
            lines.append("")
            rows = [
                [
                    item.get("job_name", ""),
                    item.get("cyclic_type", ""),
                    item.get("schedule", ""),
                    item.get("max_times", ""),
                    item.get("airflow_pattern", ""),
                ]
                for item in cyclic_jobs
            ]
            lines.extend(_markdown_table(["Job Name", "Cyclic Type", "Schedule", "Max Times", "Airflow Pattern"], rows))
            lines.append("")

        if folder.get("mixed_cyclic"):
            lines.append("> Mixed workflow: folder contains both cyclic and one-shot jobs - consider splitting into two DAGs.")
            lines.append("")

        dynamic_rows = folder.get("dynamic_variables", [])
        if dynamic_rows:
            lines.append(f"**CTM Dynamic Variables** ({len(dynamic_rows)} unresolved):")
            lines.append("")
            rows = [
                [
                    item.get("variable", ""),
                    item.get("expression", ""),
                    item.get("airflow_equivalent", ""),
                    item.get("fields", ""),
                ]
                for item in dynamic_rows[:20]
            ]
            if len(dynamic_rows) > 20:
                rows.append([f"_... and {len(dynamic_rows) - 20} more_", "", "", ""])
            lines.extend(_markdown_table(["CTM Variable", "Expression", "Airflow Equivalent", "Fields"], rows))
            lines.append("")

        complexity_rows = folder.get("scheduling_complexity", {})
        signal_count = sum(1 for value in complexity_rows.values() if value)
        lines.append(f"**Scheduling Complexity** ({signal_count} signal(s)):")
        lines.append("")
        lines.extend(
            _markdown_table(
                ["Signal", "Detected", "Airflow Handling"],
                [
                    ["Time window (FromTime/ToTime)", _format_detected(complexity_rows.get("time_window", False)), "TimeSensor or start_date + deadline"],
                    ["Weekday rule", _format_detected(complexity_rows.get("weekday_rule", False)), "schedule_interval cron expression"],
                    ["Month-day rule", _format_detected(complexity_rows.get("monthday_rule", False)), "schedule_interval cron expression"],
                    ["Combined weekday+monthday", _format_detected(complexity_rows.get("combined_weekday_monthday", False)), "Custom Airflow timetable plugin (AIP-39)"],
                    ["Month filter", _format_detected(complexity_rows.get("month_filter", False)), "schedule_interval monthly cron"],
                    ["Specific dates", _format_detected(complexity_rows.get("specific_dates", False)), "Custom timetable or manual trigger"],
                    ["Rule-based calendar", _format_detected(complexity_rows.get("rule_based_calendar", False)), "Custom timetable plugin from CTM calendar def"],
                ],
            )
        )
        lines.append("")

        flags = folder.get("flags", [])
        if flags:
            lines.append("**Flags:**")
            lines.append("")
            for flag in flags:
                lines.append(f"- {flag}")
            lines.append("")

        lines.append("---")
        lines.append("")

    lines.append("## CTM -> Airflow Operator Mapping Reference")
    lines.append("")
    lines.extend(_markdown_table(["Control-M Construct", "Airflow Equivalent"], [[left, right] for left, right in CTM_AIRFLOW_REFERENCE]))
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## Effort Sizing Summary")
    lines.append("")
    effort_rows = [
        [
            row.get("stream", ""),
            row.get("folder", ""),
            row.get("classification", ""),
            str(row.get("jobs", 0)),
            str(row.get("external_dependencies", 0)),
            row.get("effort", ""),
            row.get("priority", ""),
        ]
        for row in report.get("effort_sizing", [])
    ]
    lines.extend(_markdown_table(["Stream", "Folder", "Classification", "Jobs", "Ext. Deps", "Effort", "Priority"], effort_rows))
    lines.append("")
    lines.append(f"_Report generated {generated}_")
    lines.append("")
    return "\n".join(lines)


def analyze_controlm(raw: Any, source_name: str = "") -> dict[str, Any]:
    folder_objects = _extract_folders(raw)
    source_label = source_name or "uploaded.json"
    generated_utc = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    records: list[JobRecord] = []
    id_counter = 1

    jobs_by_folder_name: dict[tuple[str, str], list[str]] = defaultdict(list)
    jobs_by_name_global: dict[str, list[str]] = defaultdict(list)
    record_index: dict[str, JobRecord] = {}

    folder_job_ids: dict[str, list[str]] = defaultdict(list)
    folder_schedule_types: dict[str, set[str]] = defaultdict(set)
    folder_calendars: dict[str, set[str]] = defaultdict(set)
    folder_metadata: dict[str, dict[str, Any]] = {}
    folder_application_counter: dict[str, Counter[str]] = defaultdict(Counter)
    folder_subapp_counter: dict[str, Counter[str]] = defaultdict(Counter)
    folder_created_by_counter: dict[str, Counter[str]] = defaultdict(Counter)

    out_event_emitters: dict[tuple[str, str], str] = {}
    out_event_emitters_global: dict[str, list[str]] = defaultdict(list)

    pending_dependencies: dict[str, list[str]] = defaultdict(list)

    for folder_idx, folder_raw in enumerate(folder_objects, start=1):
        folder_name = _folder_name(folder_raw, f"folder_{folder_idx}")
        jobs = _extract_jobs(folder_raw)
        calendar_used = _parse_calendar(folder_raw)
        for cal in calendar_used:
            folder_calendars[folder_name].add(cal)
        folder_metadata[folder_name] = {
            "source_file": source_label,
            "controlm_server": str(folder_raw.get("ControlmServer") or folder_raw.get("ControlMServer") or folder_raw.get("Server") or "").strip(),
            "application": str(folder_raw.get("Application") or "").strip(),
            "sub_application": str(folder_raw.get("SubApplication") or "").strip(),
            "order_method": str(folder_raw.get("OrderMethod") or "").strip(),
            "created_by": str(folder_raw.get("CreatedBy") or "").strip(),
            "site_standard": str(folder_raw.get("SiteStandard") or "").strip(),
            "description": str(folder_raw.get("Description") or "").strip(),
            "subfolders": _count_subfolders(folder_raw),
        }

        for job_idx, job_raw in enumerate(jobs, start=1):
            job_name = str(
                job_raw.get("Name")
                or job_raw.get("name")
                or job_raw.get("JobName")
                or job_raw.get("jobName")
                or f"job_{job_idx}"
            )
            record_id = f"J{id_counter:06d}"
            id_counter += 1

            schedule_type, schedule_detail = _schedule_type(folder_raw, job_raw)
            schedule_from_time, schedule_to_time, schedule_time_window = _extract_schedule_times(folder_raw, job_raw)
            folder_schedule_types[folder_name].add(schedule_type)

            in_events, out_events, wait_events = _parse_events(job_raw)
            command = str(job_raw.get("Command") or job_raw.get("command") or job_raw.get("Script") or "").strip()
            normalized_type, raw_type = _detect_job_type(job_raw, schedule_type, in_events, wait_events)

            dependencies = _parse_dependencies(job_raw)
            pending_dependencies[record_id].extend(dependencies)

            hosts = _parse_host_groups(job_raw)
            actions = _parse_action_dependencies(job_raw)
            variables, dynamic_variables = _parse_variables(job_raw, command)
            uses_odate, uses_orderid = _detect_functional_token_usage(job_raw, command, variables)
            resource_refs = _parse_resource_refs(job_raw)

            host = str(job_raw.get("Host") or "").strip()
            application = str(job_raw.get("Application") or "").strip()
            sub_application = str(job_raw.get("SubApplication") or "").strip()
            created_by = str(job_raw.get("CreatedBy") or "").strip()
            description = str(job_raw.get("Description") or "").strip()
            priority = str(job_raw.get("Priority") or "").strip()
            ctm_type = _display_job_type(
                str(raw_type or job_raw.get("Type") or job_raw.get("JobType") or "").strip(),
                normalized_type,
            )
            critical = _is_critical_job(job_raw)
            is_cyclic, cyclic_type, cyclic_schedule, cyclic_max_times = _extract_cyclic(job_raw, folder_raw)
            rerun_limit, rerun_every, rerun_units = _extract_job_rerun(job_raw)
            suspicious_dummy = normalized_type == "Dummy" and bool(job_raw.get("FileName") or command)

            if application:
                folder_application_counter[folder_name][application] += 1
            if sub_application:
                folder_subapp_counter[folder_name][sub_application] += 1
            if created_by:
                folder_created_by_counter[folder_name][created_by] += 1

            has_events = bool(in_events or out_events or wait_events)
            feature_combo = _feature_combo(
                normalized_type=normalized_type,
                schedule_type=schedule_type,
                has_events=has_events,
                has_calendar=bool(calendar_used),
                has_host_group=bool(hosts),
            )

            record = JobRecord(
                record_id=record_id,
                folder=folder_name,
                job_name=job_name,
                normalized_type=normalized_type,
                raw_type=raw_type,
                feature_combo=feature_combo,
                migration_status="",
                airflow_equivalent="",
                migration_notes="",
                dependencies=[],
                unresolved_dependencies=[],
                in_events=in_events,
                out_events=out_events,
                event_to_wait_for=wait_events,
                cross_folder_events=[],
                variables=variables,
                dynamic_variables=dynamic_variables,
                uses_odate=uses_odate,
                uses_orderid=uses_orderid,
                schedule_type=schedule_type,
                schedule_detail=schedule_detail,
                schedule_from_time=schedule_from_time,
                schedule_to_time=schedule_to_time,
                schedule_time_window=schedule_time_window,
                calendar_used=calendar_used,
                host_groups=hosts,
                action_dependencies=actions,
                resource_refs=resource_refs,
                host=host,
                application=application,
                sub_application=sub_application,
                created_by=created_by,
                description=description,
                priority=priority,
                ctm_type=ctm_type,
                critical=critical,
                is_cyclic=is_cyclic,
                cyclic_type=cyclic_type,
                cyclic_schedule=cyclic_schedule,
                cyclic_max_times=cyclic_max_times,
                rerun_limit=rerun_limit,
                rerun_every=rerun_every,
                rerun_units=rerun_units,
                suspicious_dummy=suspicious_dummy,
            )

            records.append(record)
            record_index[record_id] = record
            folder_job_ids[folder_name].append(record_id)
            jobs_by_folder_name[(folder_name.lower(), job_name.lower())].append(record_id)
            jobs_by_name_global[job_name.lower()].append(record_id)

            for event in out_events:
                out_event_emitters[(folder_name.lower(), event.lower())] = record_id
                out_event_emitters_global[event.lower()].append(record_id)

    for folder_name in folder_job_ids:
        metadata = folder_metadata.get(folder_name, {})
        if not metadata.get("application") and folder_application_counter[folder_name]:
            metadata["application"] = folder_application_counter[folder_name].most_common(1)[0][0]
        if not metadata.get("sub_application") and folder_subapp_counter[folder_name]:
            metadata["sub_application"] = folder_subapp_counter[folder_name].most_common(1)[0][0]
        if not metadata.get("created_by") and folder_created_by_counter[folder_name]:
            metadata["created_by"] = folder_created_by_counter[folder_name].most_common(1)[0][0]

    forward_edges: dict[str, set[str]] = defaultdict(set)
    reverse_edges: dict[str, set[str]] = defaultdict(set)
    edge_reasons: dict[tuple[str, str], set[str]] = defaultdict(set)

    for record in records:
        dep_names = pending_dependencies.get(record.record_id, [])

        for dep_name in dep_names:
            dep = dep_name.strip()
            if not dep:
                continue

            target_ids: list[str] = []

            if "::" in dep:
                folder_part, job_part = dep.split("::", 1)
                target_ids = jobs_by_folder_name.get((folder_part.strip().lower(), job_part.strip().lower()), [])
            elif "/" in dep:
                folder_part, job_part = dep.rsplit("/", 1)
                target_ids = jobs_by_folder_name.get((folder_part.strip().lower(), job_part.strip().lower()), [])
            else:
                same_folder = jobs_by_folder_name.get((record.folder.lower(), dep.lower()), [])
                if same_folder:
                    target_ids = same_folder
                else:
                    global_hits = jobs_by_name_global.get(dep.lower(), [])
                    if len(global_hits) == 1:
                        target_ids = global_hits
                    elif len(global_hits) > 1:
                        record.unresolved_dependencies.append(f"{dep} (ambiguous)")
                        continue

            if target_ids:
                target = target_ids[0]
                record.dependencies.append(record_index[target].job_name)
                forward_edges[target].add(record.record_id)
                reverse_edges[record.record_id].add(target)
                edge_reasons[(target, record.record_id)].add("dependency")
            else:
                record.unresolved_dependencies.append(dep)

        for event in record.in_events + record.event_to_wait_for:
            key = event.lower()
            local_emitter = out_event_emitters.get((record.folder.lower(), key))
            global_emitters = out_event_emitters_global.get(key, [])

            if local_emitter:
                if local_emitter != record.record_id:
                    source = local_emitter
                    source_job_name = record_index[source].job_name
                    if source_job_name not in record.dependencies:
                        record.dependencies.append(source_job_name)
                    forward_edges[source].add(record.record_id)
                    reverse_edges[record.record_id].add(source)
                    edge_reasons[(source, record.record_id)].add("event")
                continue

            if global_emitters:
                source = global_emitters[0]
                source_record = record_index[source]
                if source_record.folder != record.folder:
                    marker = f"{source_record.folder}::{event}"
                    if marker not in record.cross_folder_events:
                        record.cross_folder_events.append(marker)
                    if source_record.job_name not in record.dependencies:
                        record.dependencies.append(source_record.job_name)
                    forward_edges[source].add(record.record_id)
                    reverse_edges[record.record_id].add(source)
                    edge_reasons[(source, record.record_id)].add("cross_folder_event")
            else:
                if any(separator in event for separator in ("::", "/", ":")):
                    marker = f"external::{event}"
                    if marker not in record.cross_folder_events:
                        record.cross_folder_events.append(marker)
                else:
                    record.unresolved_dependencies.append(f"event:{event}")

        record.dependencies = sorted(set(record.dependencies))
        record.unresolved_dependencies = sorted(set(record.unresolved_dependencies))
        record.cross_folder_events = sorted(set(record.cross_folder_events))

    for record in records:
        record.dependents = len(forward_edges.get(record.record_id, set()))
        record.standalone = len(reverse_edges.get(record.record_id, set())) == 0

        status, equivalent, notes = _migration_decision(
            normalized_type=record.normalized_type,
            has_action_dependencies=bool(record.action_dependencies),
            has_cross_folder_event=bool(record.cross_folder_events),
            has_unresolved_dependencies=bool(record.unresolved_dependencies),
        )
        record.migration_status = status
        record.airflow_equivalent = equivalent
        record.migration_notes = notes

    folder_suggestions: list[dict[str, Any]] = []
    for folder_name, ids in folder_job_ids.items():
        components = _count_components(ids, forward_edges, reverse_edges)
        cross_folder_links = sum(1 for record_id in ids if record_index[record_id].cross_folder_events)
        schedules = folder_schedule_types.get(folder_name, {"manual"})

        if cross_folder_links > 0:
            recommendation = "Multiple DAGs with ExternalTaskSensor/Datasets for cross-folder orchestration"
        elif components > 1:
            recommendation = "Multiple DAGs: folder has disconnected dependency graphs"
        elif len(ids) > 150:
            recommendation = "Split into multiple DAGs for operability and blast-radius reduction"
        elif len(schedules) > 1:
            recommendation = "Multiple DAGs to avoid mixed schedule semantics"
        else:
            recommendation = "One DAG is possible"

        folder_suggestions.append(
            {
                "folder": folder_name,
                "jobs": len(ids),
                "components": components,
                "cross_folder_links": cross_folder_links,
                "schedule_types": ", ".join(sorted(schedules)),
                "recommendation": recommendation,
            }
        )

    type_counter = Counter(record.normalized_type for record in records)
    migration_counter = Counter(record.migration_status for record in records)
    combo_counter = Counter(record.feature_combo for record in records)

    calendar_counter = Counter(
        calendar
        for record in records
        for calendar in record.calendar_used
    )

    summary = {
        "total_folders": len(folder_job_ids),
        "total_jobs": len(records),
        "migratable_jobs": migration_counter.get("Migratable", 0),
        "partially_migratable_jobs": migration_counter.get("Partially Migratable", 0),
        "needs_assessment_jobs": migration_counter.get("Needs Assessment", 0),
        "standalone_jobs": sum(1 for record in records if record.standalone),
        "jobs_without_dependencies": sum(1 for record in records if record.standalone),
        "jobs_with_hostgroups": sum(1 for record in records if record.host_groups),
        "jobs_with_dynamic_variables": sum(1 for record in records if record.dynamic_variables),
        "jobs_with_action_dependencies": sum(1 for record in records if record.action_dependencies),
        "jobs_with_resources": sum(1 for record in records if record.resource_refs),
        "jobs_using_odate": sum(1 for record in records if record.uses_odate),
        "jobs_using_orderid": sum(1 for record in records if record.uses_orderid),
        "manual_schedule_jobs": sum(1 for record in records if record.schedule_type == "manual"),
        "jobs_waiting_for_events": sum(1 for record in records if record.in_events or record.event_to_wait_for),
        "jobs_with_cross_folder_events": sum(1 for record in records if record.cross_folder_events),
        "cyclic_jobs": sum(1 for record in records if record.is_cyclic),
    }

    type_breakdown = [
        {
            "job_type": job_type,
            "count": type_counter.get(job_type, 0),
            "default_airflow_equivalent": MIGRATION_GUIDANCE.get(job_type, MIGRATION_GUIDANCE["Unknown"])[1],
        }
        for job_type in KNOWN_JOB_TYPES
    ]

    total_jobs = max(len(records), 1)
    type_split = [
        {
            "job_type": row["job_type"],
            "count": row["count"],
            "percentage": round((row["count"] / total_jobs) * 100, 2),
            "default_airflow_equivalent": row["default_airflow_equivalent"],
        }
        for row in sorted(type_breakdown, key=lambda item: item["count"], reverse=True)
        if row["count"] > 0
    ]

    combo_breakdown = [
        {"combination": combo, "count": count}
        for combo, count in combo_counter.most_common()
    ]

    migration_breakdown = [
        {"status": status, "count": count}
        for status, count in migration_counter.most_common()
    ]

    migratable_types = sorted(
        job_type
        for job_type in KNOWN_JOB_TYPES
        if job_type in type_counter and MIGRATION_GUIDANCE.get(job_type, ("", "", ""))[0] == "Migratable"
    )

    non_direct_types = sorted(
        job_type
        for job_type in KNOWN_JOB_TYPES
        if job_type in type_counter and MIGRATION_GUIDANCE.get(job_type, ("", "", ""))[0] != "Migratable"
    )

    job_rows = [
        {
            "folder": record.folder,
            "job_name": record.job_name,
            "raw_type": record.raw_type,
            "normalized_type": record.normalized_type,
            "feature_combo": record.feature_combo,
            "migration_status": record.migration_status,
            "airflow_equivalent": record.airflow_equivalent,
            "migration_notes": record.migration_notes,
            "dependencies": "; ".join(record.dependencies),
            "unresolved_dependencies": "; ".join(record.unresolved_dependencies),
            "dependents": record.dependents,
            "standalone": "Yes" if record.standalone else "No",
            "in_events": "; ".join(record.in_events),
            "out_events": "; ".join(record.out_events),
            "event_to_wait_for": "; ".join(record.event_to_wait_for),
            "cross_folder_events": "; ".join(record.cross_folder_events),
            "schedule_type": record.schedule_type,
            "schedule_detail": record.schedule_detail,
            "schedule_from_time": record.schedule_from_time,
            "schedule_to_time": record.schedule_to_time,
            "schedule_time_window": record.schedule_time_window,
            "calendar_used": "; ".join(record.calendar_used),
            "host_groups": "; ".join(record.host_groups),
            "variables": "; ".join(record.variables),
            "dynamic_variables": "; ".join(record.dynamic_variables),
            "uses_odate": "Yes" if record.uses_odate else "No",
            "uses_orderid": "Yes" if record.uses_orderid else "No",
            "action_dependencies": "; ".join(record.action_dependencies),
            "resource_refs": "; ".join(record.resource_refs),
            "application": record.application,
            "sub_application": record.sub_application,
            "host": record.host,
            "critical": "Yes" if record.critical else "No",
            "ctm_type": record.ctm_type,
            "rerun_limit": record.rerun_limit,
            "rerun_every": record.rerun_every,
            "rerun_units": record.rerun_units,
            "is_cyclic": "Yes" if record.is_cyclic else "No",
            "cyclic_type": record.cyclic_type,
            "cyclic_schedule": record.cyclic_schedule,
            "cyclic_max_times": record.cyclic_max_times,
        }
        for record in records
    ]

    standalone_rows = [
        {
            "folder": record.folder,
            "job_name": record.job_name,
            "normalized_type": record.normalized_type,
            "schedule_type": record.schedule_type,
            "schedule_detail": record.schedule_detail,
            "schedule_from_time": record.schedule_from_time,
            "schedule_to_time": record.schedule_to_time,
            "schedule_time_window": record.schedule_time_window,
            "calendar_used": "; ".join(record.calendar_used),
            "migration_recommendation": "Move to standalone DAG or lightweight grouped DAG",
            "airflow_equivalent": record.airflow_equivalent,
        }
        for record in sorted(records, key=lambda item: (item.folder, item.job_name))
        if record.standalone
    ]

    no_schedule_rows = [
        {
            "folder": record.folder,
            "job_name": record.job_name,
            "normalized_type": record.normalized_type,
            "migration_status": record.migration_status,
            "schedule_type": record.schedule_type,
            "schedule_detail": record.schedule_detail,
            "schedule_from_time": record.schedule_from_time,
            "schedule_to_time": record.schedule_to_time,
            "schedule_time_window": record.schedule_time_window,
            "airflow_equivalent": record.airflow_equivalent,
        }
        for record in sorted(records, key=lambda item: (item.folder, item.job_name))
        if record.schedule_type == "manual"
    ]

    dependency_edges: list[dict[str, Any]] = []
    for (source_id, target_id), reasons in edge_reasons.items():
        source = record_index[source_id]
        target = record_index[target_id]
        is_cross_folder = source.folder != target.folder
        dependency_edges.append(
            {
                "from_folder": source.folder,
                "from_job": source.job_name,
                "to_folder": target.folder,
                "to_job": target.job_name,
                "relation": ", ".join(sorted(reasons)),
                "cross_folder": "Yes" if is_cross_folder else "No",
            }
        )

    dependency_edges = sorted(
        dependency_edges,
        key=lambda item: (item["from_folder"], item["from_job"], item["to_folder"], item["to_job"]),
    )

    max_graph_edges = 350
    preview_edges = dependency_edges[:max_graph_edges]
    graph_lines = ["graph TD"]
    for edge in preview_edges:
        source_node = _safe_node_id(f"{edge['from_folder']}__{edge['from_job']}")
        target_node = _safe_node_id(f"{edge['to_folder']}__{edge['to_job']}")
        source_graph_label = f"{edge['from_folder']}/{edge['from_job']}".replace('"', "'")
        target_graph_label = f"{edge['to_folder']}/{edge['to_job']}".replace('"', "'")
        graph_lines.append(f'  {source_node}["{source_graph_label}"] --> {target_node}["{target_graph_label}"]')

    mermaid_graph = "\n".join(graph_lines)
    graph_truncated = len(dependency_edges) > max_graph_edges
    isolated_nodes = sum(
        1
        for record in records
        if len(reverse_edges.get(record.record_id, set())) == 0 and len(forward_edges.get(record.record_id, set())) == 0
    )

    dependency_graph = {
        "total_edges": len(dependency_edges),
        "cross_folder_edges": sum(1 for edge in dependency_edges if edge["cross_folder"] == "Yes"),
        "intra_folder_edges": sum(1 for edge in dependency_edges if edge["cross_folder"] == "No"),
        "isolated_nodes": isolated_nodes,
        "preview_edges": preview_edges,
        "preview_edge_count": len(preview_edges),
        "graph_truncated": graph_truncated,
        "mermaid": mermaid_graph,
    }

    folder_detailed_analysis: list[dict[str, Any]] = []
    job_inventory: list[dict[str, Any]] = []
    effort_sizing: list[dict[str, Any]] = []
    classification_summary: dict[str, dict[str, int]] = {
        "MIGRATE TO AIRFLOW": {"folders": 0, "jobs": 0},
        "SHIFT LEFT -> CRON": {"folders": 0, "jobs": 0},
        "RETIRE / DECOMMISSION": {"folders": 0, "jobs": 0},
        "DEMO / ARCHIVE": {"folders": 0, "jobs": 0},
    }
    bau_technical_breakdown: Counter[str] = Counter()
    total_subfolders = 0

    for folder_name in sorted(folder_job_ids.keys()):
        ids = folder_job_ids[folder_name]
        folder_records = [record_index[item] for item in ids]
        metadata = folder_metadata.get(folder_name, {})
        total_jobs_in_folder = len(folder_records)
        total_subfolders += int(metadata.get("subfolders") or 0)

        inbound_standalone = sum(1 for item in ids if len(reverse_edges.get(item, set())) == 0)
        cyclic_jobs = sum(1 for record in folder_records if record.is_cyclic)
        critical_jobs = sum(1 for record in folder_records if record.critical)
        dummy_jobs = sum(1 for record in folder_records if record.normalized_type == "Dummy")
        suspicious_dummy_jobs = sum(1 for record in folder_records if record.suspicious_dummy)
        cross_folder_dependency_list = sorted({event for record in folder_records for event in record.cross_folder_events})
        cross_folder_dependencies = len(cross_folder_dependency_list)
        action_dependency_jobs = sum(1 for record in folder_records if record.action_dependencies)
        host_group_jobs = sum(1 for record in folder_records if record.host_groups)
        resource_jobs = sum(1 for record in folder_records if record.resource_refs)
        dynamic_variable_jobs = sum(1 for record in folder_records if record.dynamic_variables)

        application = str(metadata.get("application") or "").strip()
        sub_application = str(metadata.get("sub_application") or "").strip()
        created_by = str(metadata.get("created_by") or "").strip()
        site_standard = str(metadata.get("site_standard") or "").strip()

        bau_category = _folder_bau_category(folder_name, application, sub_application, folder_records)
        classification, rationale = _folder_classification(
            folder_name=folder_name,
            site_standard=site_standard,
            created_by=created_by,
            records=folder_records,
            standalone_count=inbound_standalone,
            cross_folder_deps=cross_folder_dependencies,
        )
        priority = _priority_label(classification, total_jobs_in_folder, cross_folder_dependencies, critical_jobs, cyclic_jobs)
        effort = _effort_label(total_jobs_in_folder, cross_folder_dependencies)

        classification_summary[classification]["folders"] += 1
        classification_summary[classification]["jobs"] += total_jobs_in_folder
        bau_technical_breakdown[bau_category] += 1

        type_counter_by_folder = Counter(record.ctm_type for record in folder_records)
        type_rows = []
        for ctm_type, count in type_counter_by_folder.most_common():
            sample = next((record for record in folder_records if record.ctm_type == ctm_type), None)
            normalized = sample.normalized_type if sample else "Unknown"
            type_rows.append(
                {
                    "ctm_type": ctm_type,
                    "count": count,
                    "airflow_operator": OPERATOR_MAPPING.get(normalized, OPERATOR_MAPPING["Unknown"]),
                }
            )

        standalone_jobs_rows = [
            {
                "job_name": record.job_name,
                "type": record.ctm_type,
                "host": record.host,
            }
            for record in sorted(folder_records, key=lambda item: item.job_name)
            if len(reverse_edges.get(record.record_id, set())) == 0
        ]

        retry_jobs_rows = []
        for record in sorted(folder_records, key=lambda item: item.job_name):
            if record.rerun_limit <= 0:
                continue
            every = record.rerun_every or "1"
            units = record.rerun_units or "Minutes"
            retry_jobs_rows.append(
                {
                    "job_name": record.job_name,
                    "max_retries": record.rerun_limit,
                    "interval": every,
                    "units": units,
                    "airflow_mapping": f"retries={record.rerun_limit}, retry_delay=timedelta({every} {units})",
                }
            )

        cyclic_rows = []
        for record in sorted(folder_records, key=lambda item: item.job_name):
            if not record.is_cyclic:
                continue
            cyclic_rows.append(
                {
                    "job_name": record.job_name,
                    "cyclic_type": record.cyclic_type or "Cyclic",
                    "schedule": record.cyclic_schedule or "Cyclic",
                    "max_times": record.cyclic_max_times or "-",
                    "airflow_pattern": "ScheduleInterval / TimeDelta",
                }
            )

        dynamic_vars_rows = []
        seen_dynamic: set[str] = set()
        for record in folder_records:
            for item in record.dynamic_variables:
                if item in seen_dynamic:
                    continue
                seen_dynamic.add(item)
                dynamic_vars_rows.append(
                    {
                        "variable": re.sub(r"[^A-Za-z0-9_]", "", item).upper()[:64] or item,
                        "expression": item,
                        "airflow_equivalent": _dynamic_var_equivalent(item),
                        "fields": "Command/Variables",
                    }
                )

        calendar_tokens = set(token for record in folder_records for token in record.calendar_used)
        weekday_rule = any(token.startswith("WeekDays:") for token in calendar_tokens)
        monthday_rule = any(token.startswith("MonthDays:") for token in calendar_tokens)
        month_filter = any(token.startswith("Months:") for token in calendar_tokens)
        specific_dates = any(token.startswith("SpecificDates:") for token in calendar_tokens)
        rule_based_calendar = any("rulebasedcalendar" in token.lower() for token in calendar_tokens)
        time_window = any(record.schedule_from_time != "-" or record.schedule_to_time != "-" for record in folder_records)

        flags: list[str] = []
        if classification == "DEMO / ARCHIVE":
            flags.append("Demo/test artefact - confirm with owner before archiving")
        if cross_folder_dependencies > 0:
            flags.append("Cross-folder dependencies present - use ExternalTaskSensor/Datasets")
        if cyclic_jobs > 0 and cyclic_jobs < total_jobs_in_folder:
            flags.append("Mixed cyclic and one-shot jobs - consider splitting into multiple DAGs")

        folder_detailed_analysis.append(
            {
                "folder": folder_name,
                "classification": classification,
                "source_file": source_label,
                "controlm_server": metadata.get("controlm_server", ""),
                "application": application,
                "sub_application": sub_application,
                "order_method": metadata.get("order_method", ""),
                "created_by": created_by,
                "site_standard": site_standard,
                "description": metadata.get("description", ""),
                "total_jobs": total_jobs_in_folder,
                "standalone_inbound": inbound_standalone,
                "cyclic_jobs": cyclic_jobs,
                "mixed_cyclic": cyclic_jobs > 0 and cyclic_jobs < total_jobs_in_folder,
                "critical_jobs": critical_jobs,
                "dummy_jobs": dummy_jobs,
                "suspicious_dummy_jobs": suspicious_dummy_jobs,
                "subfolders": metadata.get("subfolders", 0),
                "cross_folder_dependencies": cross_folder_dependencies,
                "cross_folder_dependency_list": cross_folder_dependency_list,
                "action_dependency_jobs": action_dependency_jobs,
                "host_group_jobs": host_group_jobs,
                "resource_jobs": resource_jobs,
                "dynamic_variable_jobs": dynamic_variable_jobs,
                "bau_category": bau_category,
                "priority": priority,
                "effort": effort,
                "classification_rationale": rationale,
                "job_type_breakdown": type_rows,
                "standalone_jobs": standalone_jobs_rows,
                "retry_jobs": retry_jobs_rows,
                "cyclic_job_rows": cyclic_rows,
                "dynamic_variables": dynamic_vars_rows,
                "scheduling_complexity": {
                    "time_window": time_window,
                    "weekday_rule": weekday_rule,
                    "monthday_rule": monthday_rule,
                    "combined_weekday_monthday": weekday_rule and monthday_rule,
                    "month_filter": month_filter,
                    "specific_dates": specific_dates,
                    "rule_based_calendar": rule_based_calendar,
                },
                "flags": flags,
            }
        )

        job_inventory.append(
            {
                "folder": folder_name,
                "server": metadata.get("controlm_server", ""),
                "application": application,
                "jobs": total_jobs_in_folder,
                "cyclic_jobs": cyclic_jobs,
                "critical_jobs": critical_jobs,
                "dummy_jobs": dummy_jobs,
                "external_dependencies": cross_folder_dependencies,
                "bau_category": bau_category,
                "classification": classification,
                "priority": priority,
            }
        )

        effort_sizing.append(
            {
                "stream": application,
                "folder": folder_name,
                "classification": classification,
                "jobs": total_jobs_in_folder,
                "external_dependencies": cross_folder_dependencies,
                "effort": effort.split(" ", 1)[0],
                "priority": priority,
            }
        )

    workload_complexity = {
        "cyclic_jobs": summary["cyclic_jobs"],
        "standalone_inbound_jobs": summary["standalone_jobs"],
        "jobs_with_hostgroups": summary["jobs_with_hostgroups"],
        "jobs_with_dynamic_variables": summary["jobs_with_dynamic_variables"],
        "jobs_with_resources": summary["jobs_with_resources"],
        "jobs_with_action_dependencies": summary["jobs_with_action_dependencies"],
        "nested_subfolders": total_subfolders,
        "cross_folder_event_dependencies": dependency_graph["cross_folder_edges"],
    }

    result = {
        "report_metadata": {
            "generated_utc": generated_utc,
            "source_file": source_label,
        },
        "summary": summary,
        "type_breakdown": type_breakdown,
        "type_split": type_split,
        "migration_breakdown": migration_breakdown,
        "combination_breakdown": combo_breakdown,
        "calendar_breakdown": [
            {"calendar": calendar, "count": count}
            for calendar, count in calendar_counter.most_common()
        ],
        "folder_recommendations": sorted(folder_suggestions, key=lambda item: item["folder"]),
        "migratable_types": migratable_types,
        "non_direct_types": non_direct_types,
        "standalone_jobs": standalone_rows,
        "jobs_without_schedule": no_schedule_rows,
        "dependency_edges": dependency_edges,
        "dependency_graph": dependency_graph,
        "jobs": job_rows,
        "classification_summary": classification_summary,
        "workload_complexity": workload_complexity,
        "bau_technical_breakdown": {
            "BAU": bau_technical_breakdown.get("BAU", 0),
            "Technical": bau_technical_breakdown.get("Technical", 0),
            "Mixed": bau_technical_breakdown.get("Mixed", 0),
            "Unknown": bau_technical_breakdown.get("Unknown", 0),
        },
        "job_inventory": job_inventory,
        "folder_detailed_analysis": folder_detailed_analysis,
        "effort_sizing": effort_sizing,
    }
    result["markdown_report"] = _build_markdown_report(result)
    return result


def _count_components(job_ids: list[str], forward: dict[str, set[str]], reverse: dict[str, set[str]]) -> int:
    if not job_ids:
        return 0

    remaining = set(job_ids)
    components = 0

    while remaining:
        seed = remaining.pop()
        stack = [seed]
        components += 1

        while stack:
            node = stack.pop()
            neighbors = set(forward.get(node, set())) | set(reverse.get(node, set()))
            for neighbor in neighbors:
                if neighbor in remaining:
                    remaining.remove(neighbor)
                    stack.append(neighbor)

    return components


def parse_and_analyze_json(raw_text: str, source_name: str = "") -> dict[str, Any]:
    parsed = _parse_json_upload(raw_text)
    return analyze_controlm(parsed, source_name=source_name)
