import json
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from analyzer import analyze_controlm  # noqa: E402


class AnalyzerTests(unittest.TestCase):
    def test_sample_analysis(self) -> None:
        sample = Path(__file__).resolve().parents[1] / "samples" / "controlm_sample.json"
        data = json.loads(sample.read_text(encoding="utf-8"))
        report = analyze_controlm(data)

        self.assertEqual(report["summary"]["total_jobs"], 10)
        self.assertEqual(report["summary"]["total_folders"], 2)
        self.assertGreaterEqual(report["summary"]["migratable_jobs"], 1)
        self.assertGreaterEqual(report["summary"]["jobs_with_cross_folder_events"], 1)
        self.assertTrue(any(row["normalized_type"] == "FileWatcher" for row in report["jobs"]))
        self.assertIn("type_split", report)
        self.assertIn("standalone_jobs", report)
        self.assertIn("jobs_without_schedule", report)
        self.assertIn("dependency_graph", report)
        self.assertIn("schedule_time_window", report["jobs"][0])
        self.assertIn("schedule_time_window", report["standalone_jobs"][0])
        self.assertIn("markdown_report", report)
        self.assertIn("Migration Analysis Report", report["markdown_report"])

    def test_keyed_folder_map_and_lowercase_events(self) -> None:
        data = {
            "FOLDER_A": {
                "Type": "Folder",
                "Jobs": [
                    {
                        "Name": "JOB_A",
                        "Type": "Job:Command",
                        "Command": "echo done",
                        "eventsToAdd": {
                            "Type": "AddEvents",
                            "Events": [{"Event": "EVENT_A_DONE"}],
                        },
                        "When": {"WeekDays": ["MON"], "MonthDays": ["NONE"]},
                    }
                ],
            },
            "FOLDER_B": {
                "Type": "Folder",
                "Jobs": [
                    {
                        "Name": "JOB_B",
                        "Type": "Job:Script",
                        "Command": "python task.py",
                        "eventsToWaitFor": {
                            "Type": "WaitForEvents",
                            "Events": [{"Event": "EVENT_A_DONE"}],
                        },
                    }
                ],
            },
        }

        report = analyze_controlm(data)
        summary = report["summary"]

        self.assertEqual(summary["total_folders"], 2)
        self.assertEqual(summary["total_jobs"], 2)
        self.assertEqual(summary["jobs_waiting_for_events"], 1)
        self.assertEqual(summary["jobs_with_cross_folder_events"], 1)
        self.assertGreaterEqual(report["dependency_graph"]["total_edges"], 1)
        self.assertIn("schedule_time_window", report["jobs"][0])


if __name__ == "__main__":
    unittest.main()
