# Apache Airflow with Podman - Complete Installation Guide

## Overview

This automated installation provides a production-ready Apache Airflow setup using Podman containers on RHEL 8/9.

## Prerequisites

- RHEL 8 or RHEL 9
- Root or sudo access
- Internet connectivity

## Installation

### Step 1: Download Installation Script

```bash
# Make the installation script executable
chmod +x install-airflow.sh

# Run the installation
./install-airflow.sh
```

The script will automatically:
- ✓ Detect RHEL version (8 or 9)
- ✓ Install Podman and dependencies
- ✓ Install podman-compose
- ✓ Create directory structure
- ✓ Generate all configuration files
- ✓ Create management scripts
- ✓ Configure SELinux
- ✓ Set proper permissions
- ✓ Configure firewall rules
- ✓ Create sample DAG

### Step 2: Start Airflow

```bash
cd ~/airflow-podman
./scripts/start.sh
```

### Step 3: Access Web UI

Open your browser and navigate to:
- **URL**: http://localhost:8080
- **Username**: admin
- **Password**: admin

## Management Scripts

All management scripts are located in `~/airflow-podman/scripts/`

### Start Services
```bash
./scripts/start.sh
```
Starts all Airflow services (webserver, scheduler, postgres)

### Stop Services
```bash
./scripts/stop.sh
```
Gracefully stops all services

### Restart Services
```bash
./scripts/restart.sh
```
Stops and starts all services

### Check Status
```bash
./scripts/status.sh
```
Shows container status and health checks

### View Logs
```bash
# View all logs
./scripts/logs.sh

# View specific service logs
./scripts/logs.sh airflow-webserver
./scripts/logs.sh airflow-scheduler
./scripts/logs.sh postgres
```

### Cleanup All Data
```bash
./scripts/cleanup.sh
```
**WARNING**: Removes all data, DAGs, logs, and database. Use with caution!

## Directory Structure

```
~/airflow-podman/
├── dags/                      # Your DAG files go here
│   └── sample_dag.py         # Sample DAG for testing
├── logs/                      # Airflow execution logs
├── plugins/                   # Custom Airflow plugins
├── config/                    # Configuration files
├── scripts/                   # Management scripts
│   ├── start.sh              # Start services
│   ├── stop.sh               # Stop services
│   ├── restart.sh            # Restart services
│   ├── status.sh             # Check status
│   ├── logs.sh               # View logs
│   └── cleanup.sh            # Remove all data
├── .env                       # Environment variables
├── podman-compose.yml        # Container orchestration
└── README.md                  # Documentation
```

## Working with DAGs

### Creating a New DAG

1. Create a Python file in the `dags/` directory:

```bash
cd ~/airflow-podman
nano dags/my_new_dag.py
```

2. Add your DAG code:

```python
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    'my_new_dag',
    default_args=default_args,
    description='My new DAG',
    schedule_interval=timedelta(days=1),
    catchup=False,
) as dag:

    task1 = BashOperator(
        task_id='task1',
        bash_command='echo "Hello from my new DAG!"',
    )
```

3. The DAG will automatically appear in the Airflow UI within a few seconds

### Testing the Sample DAG

A sample DAG is already created at `dags/sample_dag.py`

To run it:
1. Go to http://localhost:8080
2. Find "sample_dag" in the DAG list
3. Toggle it ON (unpause)
4. Click "Trigger DAG" to run it manually

## Configuration

### Environment Variables

Edit `~/airflow-podman/.env` to customize:

```bash
# Airflow version
AIRFLOW_IMAGE_NAME=apache/airflow:2.8.1

# Admin user credentials
AIRFLOW_ADMIN_USERNAME=admin
AIRFLOW_ADMIN_PASSWORD=admin
AIRFLOW_ADMIN_EMAIL=admin@example.com

# PostgreSQL settings
POSTGRES_USER=airflow
POSTGRES_PASSWORD=airflow
POSTGRES_DB=airflow
```

After changing `.env`, restart services:
```bash
./scripts/restart.sh
```

### Airflow Configuration

To customize Airflow settings, you can:

1. Add configuration to environment variables in `podman-compose.yml`
2. Create `config/airflow.cfg` for advanced settings
3. Use environment variables in `.env`

## Troubleshooting

### Services Won't Start

```bash
# Check container status
./scripts/status.sh

# View detailed logs
./scripts/logs.sh

# Check individual container logs
podman logs airflow-webserver
podman logs airflow-scheduler
podman logs airflow-postgres
```

### Permission Errors

```bash
cd ~/airflow-podman
sudo chown -R 50000:0 dags/ logs/ plugins/ config/
```

### SELinux Issues

```bash
# Check for denials
sudo ausearch -m AVC -ts recent

# Fix SELinux contexts
sudo chcon -R -t container_file_t ~/airflow-podman/dags
sudo chcon -R -t container_file_t ~/airflow-podman/logs
sudo chcon -R -t container_file_t ~/airflow-podman/plugins
sudo chcon -R -t container_file_t ~/airflow-podman/config
```

### Can't Access Web UI

```bash
# Check if firewall is blocking
sudo firewall-cmd --list-ports

# Add port if needed
sudo firewall-cmd --add-port=8080/tcp --permanent
sudo firewall-cmd --reload

# Check if webserver is running
podman ps | grep webserver
curl http://localhost:8080/health
```

### Database Connection Issues

```bash
# Check postgres logs
./scripts/logs.sh postgres

# Restart postgres
podman-compose restart postgres
```

### Reset Everything

If something goes wrong, you can completely reset:

```bash
./scripts/cleanup.sh
./scripts/start.sh
```

## Advanced Usage

### Manual Container Management

```bash
cd ~/airflow-podman

# Start services in foreground (see live logs)
podman-compose up

# Start specific service
podman-compose up -d airflow-webserver

# Rebuild containers
podman-compose up -d --build

# View all containers
podman-compose ps

# Execute command in container
podman-compose exec airflow-webserver airflow version
podman-compose exec airflow-webserver airflow dags list
```

### Database Operations

```bash
# Access postgres directly
podman exec -it airflow-postgres psql -U airflow

# Backup database
podman exec airflow-postgres pg_dump -U airflow airflow > backup.sql

# Restore database
cat backup.sql | podman exec -i airflow-postgres psql -U airflow airflow
```

### Performance Tuning

Edit `podman-compose.yml` to adjust resources:

```yaml
services:
  airflow-webserver:
    deploy:
      resources:
        limits:
          cpus: '2'
          memory: 2G
        reservations:
          cpus: '1'
          memory: 1G
```

## Upgrading Airflow

1. Edit `.env` and change the version:
```bash
AIRFLOW_IMAGE_NAME=apache/airflow:2.9.0
```

2. Rebuild and restart:
```bash
cd ~/airflow-podman
podman-compose down
podman-compose up -d
```

## Uninstalling

To completely remove Airflow:

```bash
# Use the uninstall script
chmod +x uninstall-airflow.sh
./uninstall-airflow.sh
```

Or manually:
```bash
cd ~/airflow-podman
./scripts/cleanup.sh
cd ~
rm -rf ~/airflow-podman
```

## Security Recommendations

1. **Change default password** after first login
2. **Use strong passwords** in production
3. **Enable HTTPS** for production deployments
4. **Restrict network access** using firewall rules
5. **Keep Airflow updated** to latest stable version
6. **Use secrets management** for sensitive data

## Backup Strategy

### Backup DAGs
```bash
tar -czf dags-backup-$(date +%Y%m%d).tar.gz ~/airflow-podman/dags/
```

### Backup Database
```bash
podman exec airflow-postgres pg_dump -U airflow airflow > airflow-db-backup-$(date +%Y%m%d).sql
```

### Backup Everything
```bash
cd ~
tar -czf airflow-full-backup-$(date +%Y%m%d).tar.gz airflow-podman/
```

## Support and Documentation

- Airflow Documentation: https://airflow.apache.org/docs/
- Podman Documentation: https://docs.podman.io/
- This installation: `~/airflow-podman/README.md`

## Quick Reference

| Task | Command |
|------|---------|
| Start | `./scripts/start.sh` |
| Stop | `./scripts/stop.sh` |
| Restart | `./scripts/restart.sh` |
| Status | `./scripts/status.sh` |
| Logs | `./scripts/logs.sh` |
| Cleanup | `./scripts/cleanup.sh` |
| Web UI | http://localhost:8080 |
| Default Login | admin / admin |

## License

This installation script is provided as-is for Apache Airflow deployment on RHEL systems.
