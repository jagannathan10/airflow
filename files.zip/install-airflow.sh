#!/bin/bash

################################################################################
# Apache Airflow Installation Script for RHEL 8/9 with Podman Compose
# This script automates the complete installation and setup of Apache Airflow
################################################################################

set -e

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration variables
INSTALL_DIR="${HOME}/airflow-podman"
AIRFLOW_VERSION="2.8.1"
AIRFLOW_UID=50000
AIRFLOW_GID=0
POSTGRES_VERSION="13"

# Functions
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_rhel_version() {
    print_info "Checking RHEL version..."
    if [ -f /etc/redhat-release ]; then
        RHEL_VERSION=$(grep -oE '[0-9]+' /etc/redhat-release | head -1)
        if [ "$RHEL_VERSION" -eq 8 ] || [ "$RHEL_VERSION" -eq 9 ]; then
            print_success "RHEL $RHEL_VERSION detected"
        else
            print_error "This script supports RHEL 8 and 9 only"
            exit 1
        fi
    else
        print_error "This does not appear to be a RHEL system"
        exit 1
    fi
}

install_dependencies() {
    print_info "Installing Podman and dependencies..."
    
    sudo dnf install -y podman python3-pip curl
    
    # Install podman-compose
    print_info "Installing podman-compose..."
    pip3 install --user podman-compose
    
    # Add to PATH if not already there
    if ! command -v podman-compose &> /dev/null; then
        export PATH="$HOME/.local/bin:$PATH"
        echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
    fi
    
    print_success "Dependencies installed successfully"
}

verify_installations() {
    print_info "Verifying installations..."
    
    if ! command -v podman &> /dev/null; then
        print_error "Podman installation failed"
        exit 1
    fi
    
    if ! command -v podman-compose &> /dev/null; then
        print_error "Podman-compose installation failed"
        exit 1
    fi
    
    print_success "Podman version: $(podman --version)"
    print_success "Podman-compose version: $(podman-compose --version)"
}

create_directory_structure() {
    print_info "Creating directory structure at $INSTALL_DIR..."
    
    mkdir -p "$INSTALL_DIR"/{dags,logs,plugins,config,scripts}
    cd "$INSTALL_DIR"
    
    print_success "Directory structure created"
}

create_env_file() {
    print_info "Creating environment file..."
    
    cat > "$INSTALL_DIR/.env" << EOF
# Airflow Configuration
AIRFLOW_UID=$AIRFLOW_UID
AIRFLOW_GID=$AIRFLOW_GID
AIRFLOW_IMAGE_NAME=apache/airflow:$AIRFLOW_VERSION

# PostgreSQL Configuration
POSTGRES_USER=airflow
POSTGRES_PASSWORD=airflow
POSTGRES_DB=airflow
POSTGRES_VERSION=$POSTGRES_VERSION

# Airflow Admin User
AIRFLOW_ADMIN_USERNAME=admin
AIRFLOW_ADMIN_PASSWORD=admin
AIRFLOW_ADMIN_EMAIL=admin@example.com
AIRFLOW_ADMIN_FIRSTNAME=Admin
AIRFLOW_ADMIN_LASTNAME=User
EOF
    
    print_success "Environment file created"
}

create_compose_file() {
    print_info "Creating podman-compose.yml..."
    
    cat > "$INSTALL_DIR/podman-compose.yml" << 'EOF'
version: '3.8'

x-airflow-common:
  &airflow-common
  image: ${AIRFLOW_IMAGE_NAME:-apache/airflow:2.8.1}
  environment:
    &airflow-common-env
    AIRFLOW__CORE__EXECUTOR: LocalExecutor
    AIRFLOW__DATABASE__SQL_ALCHEMY_CONN: postgresql+psycopg2://${POSTGRES_USER}:${POSTGRES_PASSWORD}@postgres/${POSTGRES_DB}
    AIRFLOW__CORE__FERNET_KEY: ''
    AIRFLOW__CORE__DAGS_ARE_PAUSED_AT_CREATION: 'true'
    AIRFLOW__CORE__LOAD_EXAMPLES: 'false'
    AIRFLOW__API__AUTH_BACKENDS: 'airflow.api.auth.backend.basic_auth,airflow.api.auth.backend.session'
    AIRFLOW__SCHEDULER__ENABLE_HEALTH_CHECK: 'true'
    AIRFLOW__WEBSERVER__EXPOSE_CONFIG: 'true'
    AIRFLOW__WEBSERVER__RBAC: 'true'
  volumes:
    - ./dags:/opt/airflow/dags
    - ./logs:/opt/airflow/logs
    - ./plugins:/opt/airflow/plugins
    - ./config:/opt/airflow/config
  user: "${AIRFLOW_UID:-50000}:${AIRFLOW_GID:-0}"
  depends_on:
    postgres:
      condition: service_healthy

services:
  postgres:
    image: postgres:${POSTGRES_VERSION:-13}
    container_name: airflow-postgres
    environment:
      POSTGRES_USER: ${POSTGRES_USER:-airflow}
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD:-airflow}
      POSTGRES_DB: ${POSTGRES_DB:-airflow}
    volumes:
      - postgres-db-volume:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD", "pg_isready", "-U", "${POSTGRES_USER:-airflow}"]
      interval: 10s
      retries: 5
      start_period: 5s
    restart: always
    ports:
      - "5432:5432"

  airflow-webserver:
    <<: *airflow-common
    container_name: airflow-webserver
    command: webserver
    ports:
      - "8080:8080"
    healthcheck:
      test: ["CMD", "curl", "--fail", "http://localhost:8080/health"]
      interval: 30s
      timeout: 10s
      retries: 5
      start_period: 30s
    restart: always
    depends_on:
      airflow-init:
        condition: service_completed_successfully

  airflow-scheduler:
    <<: *airflow-common
    container_name: airflow-scheduler
    command: scheduler
    healthcheck:
      test: ["CMD", "curl", "--fail", "http://localhost:8974/health"]
      interval: 30s
      timeout: 10s
      retries: 5
      start_period: 30s
    restart: always
    depends_on:
      airflow-init:
        condition: service_completed_successfully

  airflow-init:
    <<: *airflow-common
    container_name: airflow-init
    entrypoint: /bin/bash
    command:
      - -c
      - |
        echo "Creating directories..."
        mkdir -p /sources/logs /sources/dags /sources/plugins /sources/config
        chown -R "${AIRFLOW_UID}:${AIRFLOW_GID}" /sources/{logs,dags,plugins,config}
        
        echo "Initializing database..."
        airflow db migrate
        
        echo "Creating admin user..."
        airflow users create \
          --username ${AIRFLOW_ADMIN_USERNAME:-admin} \
          --firstname ${AIRFLOW_ADMIN_FIRSTNAME:-Admin} \
          --lastname ${AIRFLOW_ADMIN_LASTNAME:-User} \
          --role Admin \
          --email ${AIRFLOW_ADMIN_EMAIL:-admin@example.com} \
          --password ${AIRFLOW_ADMIN_PASSWORD:-admin} || echo "User already exists"
        
        echo "Initialization complete!"
    environment:
      <<: *airflow-common-env
      _AIRFLOW_DB_MIGRATE: 'true'
      _AIRFLOW_WWW_USER_CREATE: 'true'
    user: "0:0"
    volumes:
      - .:/sources

volumes:
  postgres-db-volume:
EOF
    
    print_success "Compose file created"
}

create_start_script() {
    print_info "Creating start script..."
    
    cat > "$INSTALL_DIR/scripts/start.sh" << 'EOF'
#!/bin/bash

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}Starting Apache Airflow...${NC}"

cd "$PROJECT_DIR"

# Check if containers are already running
if podman-compose ps | grep -q "Up"; then
    echo -e "${GREEN}Airflow is already running${NC}"
    podman-compose ps
    exit 0
fi

# Start services
echo "Starting all services..."
podman-compose up -d

# Wait for services to be healthy
echo "Waiting for services to be ready..."
sleep 10

# Check status
echo ""
echo -e "${GREEN}Container Status:${NC}"
podman-compose ps

echo ""
echo -e "${GREEN}Airflow is starting up!${NC}"
echo "Web UI will be available at: http://localhost:8080"
echo "Default credentials:"
echo "  Username: admin"
echo "  Password: admin"
echo ""
echo "Use './scripts/logs.sh' to view logs"
echo "Use './scripts/stop.sh' to stop services"
EOF
    
    chmod +x "$INSTALL_DIR/scripts/start.sh"
    print_success "Start script created"
}

create_stop_script() {
    print_info "Creating stop script..."
    
    cat > "$INSTALL_DIR/scripts/stop.sh" << 'EOF'
#!/bin/bash

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}Stopping Apache Airflow...${NC}"

cd "$PROJECT_DIR"

# Stop all services
podman-compose down

echo -e "${RED}All services stopped${NC}"
echo ""
echo "To start again, run: ./scripts/start.sh"
echo "To cleanup all data, run: ./scripts/cleanup.sh"
EOF
    
    chmod +x "$INSTALL_DIR/scripts/stop.sh"
    print_success "Stop script created"
}

create_cleanup_script() {
    print_info "Creating cleanup script..."
    
    cat > "$INSTALL_DIR/scripts/cleanup.sh" << 'EOF'
#!/bin/bash

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${RED}WARNING: This will remove all Airflow data including DAGs, logs, and database!${NC}"
read -p "Are you sure you want to continue? (yes/no): " confirm

if [ "$confirm" != "yes" ]; then
    echo "Cleanup cancelled"
    exit 0
fi

cd "$PROJECT_DIR"

echo -e "${YELLOW}Stopping all services...${NC}"
podman-compose down -v

echo -e "${YELLOW}Removing containers and volumes...${NC}"
podman-compose rm -f 2>/dev/null || true

echo -e "${YELLOW}Cleaning up directories...${NC}"
rm -rf logs/* dags/* plugins/* config/*

echo -e "${YELLOW}Removing unused volumes...${NC}"
podman volume prune -f

echo ""
echo -e "${RED}Cleanup complete!${NC}"
echo "All data has been removed."
echo ""
echo "To reinstall, run: ./scripts/start.sh"
EOF
    
    chmod +x "$INSTALL_DIR/scripts/cleanup.sh"
    print_success "Cleanup script created"
}

create_logs_script() {
    print_info "Creating logs script..."
    
    cat > "$INSTALL_DIR/scripts/logs.sh" << 'EOF'
#!/bin/bash

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_DIR"

SERVICE=${1:-}

if [ -z "$SERVICE" ]; then
    echo "Following logs for all services (Ctrl+C to exit)..."
    echo ""
    podman-compose logs -f
else
    echo "Following logs for $SERVICE (Ctrl+C to exit)..."
    echo ""
    podman-compose logs -f "$SERVICE"
fi
EOF
    
    chmod +x "$INSTALL_DIR/scripts/logs.sh"
    print_success "Logs script created"
}

create_status_script() {
    print_info "Creating status script..."
    
    cat > "$INSTALL_DIR/scripts/status.sh" << 'EOF'
#!/bin/bash

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

cd "$PROJECT_DIR"

echo -e "${BLUE}=== Airflow Container Status ===${NC}"
echo ""
podman-compose ps
echo ""

echo -e "${BLUE}=== Health Checks ===${NC}"
echo ""

# Check if webserver is responding
if curl -s http://localhost:8080/health > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Webserver is healthy${NC}"
else
    echo "✗ Webserver is not responding"
fi

# Check scheduler health
SCHEDULER_ID=$(podman ps -q -f name=airflow-scheduler)
if [ -n "$SCHEDULER_ID" ]; then
    echo -e "${GREEN}✓ Scheduler is running${NC}"
else
    echo "✗ Scheduler is not running"
fi

# Check postgres
POSTGRES_ID=$(podman ps -q -f name=airflow-postgres)
if [ -n "$POSTGRES_ID" ]; then
    echo -e "${GREEN}✓ PostgreSQL is running${NC}"
else
    echo "✗ PostgreSQL is not running"
fi

echo ""
echo -e "${BLUE}=== Access Information ===${NC}"
echo "Webserver: http://localhost:8080"
echo "Username: admin"
echo "Password: admin"
EOF
    
    chmod +x "$INSTALL_DIR/scripts/status.sh"
    print_success "Status script created"
}

create_restart_script() {
    print_info "Creating restart script..."
    
    cat > "$INSTALL_DIR/scripts/restart.sh" << 'EOF'
#!/bin/bash

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

YELLOW='\033[1;33m'
GREEN='\033[0;32m'
NC='\033[0m'

echo -e "${YELLOW}Restarting Apache Airflow...${NC}"

# Stop services
"$SCRIPT_DIR/stop.sh"

# Wait a moment
sleep 3

# Start services
"$SCRIPT_DIR/start.sh"

echo ""
echo -e "${GREEN}Restart complete!${NC}"
EOF
    
    chmod +x "$INSTALL_DIR/scripts/restart.sh"
    print_success "Restart script created"
}

create_sample_dag() {
    print_info "Creating sample DAG..."
    
    cat > "$INSTALL_DIR/dags/sample_dag.py" << 'EOF'
"""
Sample Airflow DAG for testing the installation
"""
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator

def print_hello():
    print("Hello from Airflow on Podman!")
    return "Hello World"

def print_system_info():
    import platform
    print(f"Python Version: {platform.python_version()}")
    print(f"System: {platform.system()}")
    print(f"Machine: {platform.machine()}")
    return "System info printed"

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    'sample_dag',
    default_args=default_args,
    description='A sample DAG for testing',
    schedule_interval=timedelta(days=1),
    catchup=False,
    tags=['sample', 'test'],
) as dag:

    task_print_date = BashOperator(
        task_id='print_date',
        bash_command='date',
    )

    task_hello = PythonOperator(
        task_id='print_hello',
        python_callable=print_hello,
    )

    task_system_info = PythonOperator(
        task_id='print_system_info',
        python_callable=print_system_info,
    )

    task_sleep = BashOperator(
        task_id='sleep',
        bash_command='sleep 5',
    )

    task_final = BashOperator(
        task_id='final_task',
        bash_command='echo "DAG execution completed successfully!"',
    )

    # Define task dependencies
    task_print_date >> [task_hello, task_system_info] >> task_sleep >> task_final
EOF
    
    print_success "Sample DAG created"
}

configure_selinux() {
    if command -v getenforce &> /dev/null; then
        SELINUX_STATUS=$(getenforce)
        if [ "$SELINUX_STATUS" = "Enforcing" ]; then
            print_info "Configuring SELinux..."
            
            sudo chcon -R -t container_file_t "$INSTALL_DIR/dags" "$INSTALL_DIR/logs" "$INSTALL_DIR/plugins" "$INSTALL_DIR/config" 2>/dev/null || true
            sudo setsebool -P container_manage_cgroup on 2>/dev/null || true
            
            print_success "SELinux configured"
        fi
    fi
}

set_permissions() {
    print_info "Setting directory permissions..."
    
    sudo chown -R $AIRFLOW_UID:$AIRFLOW_GID "$INSTALL_DIR/dags" "$INSTALL_DIR/logs" "$INSTALL_DIR/plugins" "$INSTALL_DIR/config"
    
    print_success "Permissions set"
}

configure_firewall() {
    print_info "Configuring firewall..."
    
    if command -v firewall-cmd &> /dev/null; then
        if sudo firewall-cmd --state &> /dev/null; then
            sudo firewall-cmd --add-port=8080/tcp --permanent 2>/dev/null || true
            sudo firewall-cmd --reload 2>/dev/null || true
            print_success "Firewall configured to allow port 8080"
        fi
    fi
}

create_readme() {
    print_info "Creating README..."
    
    cat > "$INSTALL_DIR/README.md" << 'EOF'
# Apache Airflow with Podman

This installation provides Apache Airflow running in Podman containers.

## Quick Start

### Start Airflow
```bash
./scripts/start.sh
```

### Stop Airflow
```bash
./scripts/stop.sh
```

### Restart Airflow
```bash
./scripts/restart.sh
```

### Check Status
```bash
./scripts/status.sh
```

### View Logs
```bash
# All services
./scripts/logs.sh

# Specific service
./scripts/logs.sh airflow-webserver
./scripts/logs.sh airflow-scheduler
./scripts/logs.sh postgres
```

### Clean Up Everything
```bash
./scripts/cleanup.sh
```

## Access

- **Web UI**: http://localhost:8080
- **Username**: admin
- **Password**: admin

## Directory Structure

```
.
├── dags/           # Place your DAG files here
├── logs/           # Airflow logs
├── plugins/        # Custom Airflow plugins
├── config/         # Configuration files
├── scripts/        # Management scripts
└── podman-compose.yml
```

## Adding DAGs

Place your Python DAG files in the `dags/` directory. They will be automatically picked up by Airflow.

A sample DAG has been provided: `dags/sample_dag.py`

## Troubleshooting

### Permission Issues
```bash
sudo chown -R 50000:0 dags/ logs/ plugins/ config/
```

### View Container Logs
```bash
podman logs airflow-webserver
podman logs airflow-scheduler
podman logs airflow-postgres
```

### Reset Everything
```bash
./scripts/cleanup.sh
./scripts/start.sh
```

## Manual Commands

All services can also be managed using podman-compose directly:

```bash
# Start
podman-compose up -d

# Stop
podman-compose down

# View logs
podman-compose logs -f

# List containers
podman-compose ps
```
EOF
    
    print_success "README created"
}

print_completion_message() {
    echo ""
    echo "=========================================================================="
    print_success "Apache Airflow installation completed successfully!"
    echo "=========================================================================="
    echo ""
    echo "Installation directory: $INSTALL_DIR"
    echo ""
    echo "To start Airflow, run:"
    echo "  cd $INSTALL_DIR"
    echo "  ./scripts/start.sh"
    echo ""
    echo "Available scripts:"
    echo "  ./scripts/start.sh    - Start Airflow services"
    echo "  ./scripts/stop.sh     - Stop Airflow services"
    echo "  ./scripts/restart.sh  - Restart Airflow services"
    echo "  ./scripts/status.sh   - Check service status"
    echo "  ./scripts/logs.sh     - View logs"
    echo "  ./scripts/cleanup.sh  - Remove all data and reset"
    echo ""
    echo "After starting, access Airflow at:"
    echo "  URL: http://localhost:8080"
    echo "  Username: admin"
    echo "  Password: admin"
    echo ""
    echo "=========================================================================="
}

# Main execution
main() {
    echo ""
    echo "=========================================================================="
    echo "          Apache Airflow Installation for RHEL 8/9"
    echo "=========================================================================="
    echo ""
    
    check_rhel_version
    install_dependencies
    verify_installations
    create_directory_structure
    create_env_file
    create_compose_file
    create_start_script
    create_stop_script
    create_cleanup_script
    create_logs_script
    create_status_script
    create_restart_script
    create_sample_dag
    configure_selinux
    set_permissions
    configure_firewall
    create_readme
    print_completion_message
}

# Run main function
main
