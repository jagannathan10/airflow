#!/bin/bash

# ══════════════════════════════════════════════════════════════
# cleanup.sh — System & Application Cleanup Script
# ══════════════════════════════════════════════════════════════
# Usage  : ./cleanup.sh
# Schedule: Every Sunday at midnight via cron_wrapper.sh
# Retries : 1 with 5s delay
# ══════════════════════════════════════════════════════════════

set -euo pipefail

# ── Configuration ──
APP_NAME="myapp"
APP_LOG_DIR="/apps/${APP_NAME}/logs"
CRON_LOG_DIR="/apps/cron/logs"
TMP_DIR="/apps/tmp"
CACHE_DIR="/apps/${APP_NAME}/cache"
SESSION_DIR="/apps/${APP_NAME}/sessions"
UPLOAD_TMP_DIR="/apps/${APP_NAME}/uploads/tmp"

# Retention periods (in days)
APP_LOG_RETENTION=14
CRON_LOG_RETENTION=30
TMP_FILE_RETENTION=3
SESSION_RETENTION=7
UPLOAD_TMP_RETENTION=1

# Disk usage thresholds
DISK_WARN_PERCENT=80
DISK_CRITICAL_PERCENT=90

# ── Logging Helper ──
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [CLEANUP] $1"
}

# ── Counters ──
TOTAL_FILES_DELETED=0
TOTAL_SPACE_FREED=0

# Helper: Delete old files and track stats
cleanup_directory() {
    local DIR="$1"
    local PATTERN="$2"
    local RETENTION="$3"
    local LABEL="$4"

    if [ ! -d "$DIR" ]; then
        log "  SKIP: Directory not found: ${DIR}"
        return 0
    fi

    # Calculate size before
    SIZE_BEFORE=$(du -sb "$DIR" 2>/dev/null | awk '{print $1}')

    # Find and delete
    FILE_COUNT=$(find "$DIR" -type f -name "$PATTERN" -mtime +${RETENTION} -print -delete 2>/dev/null | wc -l)

    # Calculate size after
    SIZE_AFTER=$(du -sb "$DIR" 2>/dev/null | awk '{print $1}')
    FREED=$(( SIZE_BEFORE - SIZE_AFTER ))
    FREED_MB=$(echo "scale=2; $FREED / 1048576" | bc 2>/dev/null || echo "0")

    TOTAL_FILES_DELETED=$(( TOTAL_FILES_DELETED + FILE_COUNT ))
    TOTAL_SPACE_FREED=$(( TOTAL_SPACE_FREED + FREED ))

    log "  ${LABEL}: Deleted ${FILE_COUNT} files, freed ${FREED_MB} MB"
}

log "Starting system cleanup..."
log "═══════════════════════════════════"

# ══════════════════════════════════════════════════════════════
# STEP 1: Clean Application Logs
# ══════════════════════════════════════════════════════════════
log "STEP 1: Cleaning application logs (>${APP_LOG_RETENTION} days)..."

cleanup_directory "$APP_LOG_DIR" "*.log" "$APP_LOG_RETENTION" "App Logs"
cleanup_directory "$APP_LOG_DIR" "*.log.gz" "$APP_LOG_RETENTION" "App Logs (compressed)"

# Truncate current log files that are too large (>500MB)
if [ -d "$APP_LOG_DIR" ]; then
    find "$APP_LOG_DIR" -type f -name "*.log" -size +500M | while read -r LARGE_LOG; do
        ORIGINAL_SIZE=$(du -sh "$LARGE_LOG" | awk '{print $1}')
        # Keep last 10000 lines
        tail -n 10000 "$LARGE_LOG" > "${LARGE_LOG}.tmp"
        mv "${LARGE_LOG}.tmp" "$LARGE_LOG"
        log "  Truncated oversized log: ${LARGE_LOG} (was ${ORIGINAL_SIZE})"
    done
fi

# ══════════════════════════════════════════════════════════════
# STEP 2: Clean Cron Execution Logs
# ══════════════════════════════════════════════════════════════
log "STEP 2: Cleaning cron logs (>${CRON_LOG_RETENTION} days)..."

cleanup_directory "$CRON_LOG_DIR" "cron_status_metrics_*.json" "$CRON_LOG_RETENTION" "Cron JSON Logs"

# ══════════════════════════════════════════════════════════════
# STEP 3: Clean Temporary Files
# ══════════════════════════════════════════════════════════════
log "STEP 3: Cleaning temporary files (>${TMP_FILE_RETENTION} days)..."

cleanup_directory "$TMP_DIR" "*" "$TMP_FILE_RETENTION" "Temp Files"

# Clean system temp files owned by app user
cleanup_directory "/tmp" "${APP_NAME}_*" "$TMP_FILE_RETENTION" "System Temp"

# ══════════════════════════════════════════════════════════════
# STEP 4: Clean Expired Sessions
# ══════════════════════════════════════════════════════════════
log "STEP 4: Cleaning expired sessions (>${SESSION_RETENTION} days)..."

cleanup_directory "$SESSION_DIR" "sess_*" "$SESSION_RETENTION" "Sessions"

# ══════════════════════════════════════════════════════════════
# STEP 5: Clean Orphaned Upload Temp Files
# ══════════════════════════════════════════════════════════════
log "STEP 5: Cleaning orphaned upload temp files (>${UPLOAD_TMP_RETENTION} days)..."

cleanup_directory "$UPLOAD_TMP_DIR" "*" "$UPLOAD_TMP_RETENTION" "Upload Temp"

# ══════════════════════════════════════════════════════════════
# STEP 6: Clean Application Cache
# ══════════════════════════════════════════════════════════════
log "STEP 6: Cleaning application cache..."

if [ -d "$CACHE_DIR" ]; then
    CACHE_SIZE_BEFORE=$(du -sh "$CACHE_DIR" 2>/dev/null | awk '{print $1}')

    # Remove expired cache entries (>7 days)
    find "$CACHE_DIR" -type f -mtime +7 -delete 2>/dev/null

    # Remove empty directories
    find "$CACHE_DIR" -type d -empty -delete 2>/dev/null

    CACHE_SIZE_AFTER=$(du -sh "$CACHE_DIR" 2>/dev/null | awk '{print $1}')
    log "  Cache: ${CACHE_SIZE_BEFORE} → ${CACHE_SIZE_AFTER}"
fi

# ══════════════════════════════════════════════════════════════
# STEP 7: Clean Docker Artifacts (if Docker is present)
# ══════════════════════════════════════════════════════════════
if command -v docker &> /dev/null; then
    log "STEP 7: Cleaning Docker artifacts..."

    # Remove stopped containers older than 48h
    docker container prune -f --filter "until=48h" > /dev/null 2>&1 || true

    # Remove dangling images
    docker image prune -f > /dev/null 2>&1 || true

    # Remove unused volumes
    docker volume prune -f > /dev/null 2>&1 || true

    log "  Docker cleanup complete."
else
    log "STEP 7: Docker not found. Skipping."
fi

# ══════════════════════════════════════════════════════════════
# STEP 8: Disk Usage Health Check
# ══════════════════════════════════════════════════════════════
log "STEP 8: Disk usage health check..."

DISK_USAGE=$(df -h /apps | awk 'NR==2 {print $5}' | tr -d '%')
DISK_AVAIL=$(df -h /apps | awk 'NR==2 {print $4}')

if [ "$DISK_USAGE" -ge "$DISK_CRITICAL_PERCENT" ]; then
    log "  CRITICAL: Disk usage at ${DISK_USAGE}% (available: ${DISK_AVAIL})"
    log "  ACTION REQUIRED: Manual intervention needed!"
    # Could trigger an alert here (PagerDuty, Slack, email, etc.)
    exit 1
elif [ "$DISK_USAGE" -ge "$DISK_WARN_PERCENT" ]; then
    log "  WARNING: Disk usage at ${DISK_USAGE}% (available: ${DISK_AVAIL})"
else
    log "  OK: Disk usage at ${DISK_USAGE}% (available: ${DISK_AVAIL})"
fi

# ══════════════════════════════════════════════════════════════
# Summary
# ══════════════════════════════════════════════════════════════
TOTAL_FREED_MB=$(echo "scale=2; $TOTAL_SPACE_FREED / 1048576" | bc 2>/dev/null || echo "0")

log "═══════════════════════════════════"
log " CLEANUP COMPLETED SUCCESSFULLY"
log " Files deleted : ${TOTAL_FILES_DELETED}"
log " Space freed   : ${TOTAL_FREED_MB} MB"
log " Disk usage    : ${DISK_USAGE}%"
log "═══════════════════════════════════"

exit 0
