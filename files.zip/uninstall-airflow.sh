#!/bin/bash

################################################################################
# Apache Airflow Uninstall Script for RHEL 8/9 with Podman
# This script completely removes Airflow installation
################################################################################

set -e

RED='\033[0;31m'
YELLOW='\033[1;33m'
GREEN='\033[0;32m'
NC='\033[0m'

INSTALL_DIR="${HOME}/airflow-podman"

echo ""
echo "=========================================================================="
echo -e "${RED}          Apache Airflow Uninstall Script${NC}"
echo "=========================================================================="
echo ""
echo -e "${YELLOW}WARNING: This will completely remove Apache Airflow and all data!${NC}"
echo ""
echo "This will:"
echo "  - Stop all running containers"
echo "  - Remove all containers and volumes"
echo "  - Delete installation directory: $INSTALL_DIR"
echo "  - Remove all DAGs, logs, and configuration"
echo ""
read -p "Are you absolutely sure you want to continue? (type 'yes' to confirm): " confirm

if [ "$confirm" != "yes" ]; then
    echo "Uninstall cancelled"
    exit 0
fi

echo ""
echo -e "${YELLOW}Starting uninstall process...${NC}"

# Change to install directory if it exists
if [ -d "$INSTALL_DIR" ]; then
    cd "$INSTALL_DIR"
    
    # Stop all services
    echo -e "${YELLOW}Stopping all services...${NC}"
    podman-compose down -v 2>/dev/null || true
    
    # Remove any remaining containers
    echo -e "${YELLOW}Removing containers...${NC}"
    podman rm -f airflow-webserver airflow-scheduler airflow-postgres airflow-init 2>/dev/null || true
    
    # Remove volumes
    echo -e "${YELLOW}Removing volumes...${NC}"
    podman volume rm airflow-podman_postgres-db-volume 2>/dev/null || true
    podman volume prune -f 2>/dev/null || true
fi

# Remove installation directory
echo -e "${YELLOW}Removing installation directory...${NC}"
rm -rf "$INSTALL_DIR"

# Optional: Remove podman-compose (ask user)
echo ""
read -p "Do you want to remove podman-compose as well? (yes/no): " remove_compose

if [ "$remove_compose" = "yes" ]; then
    pip3 uninstall -y podman-compose 2>/dev/null || true
    echo -e "${GREEN}podman-compose removed${NC}"
fi

# Optional: Remove Podman (ask user)
echo ""
read -p "Do you want to remove Podman? (yes/no): " remove_podman

if [ "$remove_podman" = "yes" ]; then
    sudo dnf remove -y podman 2>/dev/null || true
    echo -e "${GREEN}Podman removed${NC}"
fi

echo ""
echo "=========================================================================="
echo -e "${GREEN}Uninstall completed successfully!${NC}"
echo "=========================================================================="
echo ""
echo "All Airflow data and containers have been removed."
echo ""
