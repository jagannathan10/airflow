# Apache Airflow Automated Installation for RHEL 8/9

## Quick Start (5 Minutes Setup)

### 1. Run Installation Script

```bash
chmod +x install-airflow.sh
./install-airflow.sh
```

### 2. Start Airflow

```bash
cd ~/airflow-podman
./scripts/start.sh
```

### 3. Access Web UI

Open browser: **http://localhost:8080**
- Username: `admin`
- Password: `admin`

## What You Get

✅ **Fully Automated Installation**
- Automatic RHEL 8/9 detection
- Podman and podman-compose installation
- Complete directory structure setup
- SELinux and firewall configuration

✅ **Management Scripts**
- `start.sh` - Start all services
- `stop.sh` - Stop all services  
- `restart.sh` - Restart services
- `status.sh` - Health checks
- `logs.sh` - View logs
- `cleanup.sh` - Remove all data

✅ **Production Ready**
- PostgreSQL database
- LocalExecutor
- Health checks enabled
- Auto-restart on failure
- Sample DAG included

## File Structure

```
install-airflow.sh          # Main installation script
uninstall-airflow.sh        # Complete removal script
INSTALLATION_GUIDE.md       # Detailed documentation
README.md                   # This file
```

After installation, you'll have:

```
~/airflow-podman/
├── scripts/               # All management scripts
├── dags/                  # Your DAG files
├── logs/                  # Airflow logs
├── plugins/              # Custom plugins
├── config/               # Configuration
└── podman-compose.yml    # Container definition
```

## Common Commands

```bash
cd ~/airflow-podman

# Start services
./scripts/start.sh

# Check status
./scripts/status.sh

# View logs
./scripts/logs.sh

# Stop services  
./scripts/stop.sh

# Complete cleanup
./scripts/cleanup.sh
```

## Requirements

- RHEL 8 or RHEL 9
- Root/sudo access
- Internet connection
- ~2GB free disk space

## Features

| Feature | Included |
|---------|----------|
| Apache Airflow 2.8.1 | ✅ |
| PostgreSQL 13 | ✅ |
| Web UI | ✅ |
| Scheduler | ✅ |
| Auto-restart | ✅ |
| Health checks | ✅ |
| SELinux support | ✅ |
| Firewall config | ✅ |
| Sample DAG | ✅ |
| Management scripts | ✅ |

## Troubleshooting

**Services won't start?**
```bash
cd ~/airflow-podman
./scripts/logs.sh
```

**Permission errors?**
```bash
cd ~/airflow-podman
sudo chown -R 50000:0 dags/ logs/ plugins/ config/
```

**Can't access web UI?**
```bash
sudo firewall-cmd --add-port=8080/tcp --permanent
sudo firewall-cmd --reload
```

**Need to reset?**
```bash
cd ~/airflow-podman
./scripts/cleanup.sh
./scripts/start.sh
```

## Uninstall

```bash
chmod +x uninstall-airflow.sh
./uninstall-airflow.sh
```

## Documentation

See **INSTALLATION_GUIDE.md** for:
- Detailed usage instructions
- DAG development guide
- Configuration options
- Advanced troubleshooting
- Backup strategies
- Security recommendations

## Support

- Airflow Docs: https://airflow.apache.org/docs/
- Podman Docs: https://docs.podman.io/

## Platform Support

✅ Red Hat Enterprise Linux 8  
✅ Red Hat Enterprise Linux 9  
✅ CentOS Stream 8/9  
✅ Rocky Linux 8/9  
✅ AlmaLinux 8/9
