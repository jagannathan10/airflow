#!/bin/bash

# ══════════════════════════════════════════════════════════════
# data_sync.sh — Data Synchronization Between Environments
# ══════════════════════════════════════════════════════════════
# Usage  : ./data_sync.sh
# Schedule: Every 6 hours via cron_wrapper.sh
# Retries : 2 with fixed 10s delay (handles network blips)
# ══════════════════════════════════════════════════════════════

set -euo pipefail

# ── Configuration ──
SOURCE_API="https://api.upstream-service.com/v2"
TARGET_DB_HOST="localhost"
TARGET_DB_PORT="5432"
TARGET_DB_NAME="analytics_db"
TARGET_DB_USER="sync_user"
SYNC_DIR="/apps/data_sync/staging"
STATE_FILE="/apps/data_sync/.last_sync_state"
API_TOKEN="${DATA_SYNC_API_TOKEN:-}"
BATCH_SIZE=1000
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

# ── Logging Helper ──
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [DATA_SYNC] $1"
}

# ── Pre-checks ──
log "Starting data synchronization..."

mkdir -p "$SYNC_DIR"

# Validate API token
if [ -z "$API_TOKEN" ]; then
    log "ERROR: DATA_SYNC_API_TOKEN is not set."
    exit 1
fi

# Check target database
if ! pg_isready -h "$TARGET_DB_HOST" -p "$TARGET_DB_PORT" -U "$TARGET_DB_USER" -d "$TARGET_DB_NAME" -t 10 > /dev/null 2>&1; then
    log "ERROR: Cannot connect to target database."
    exit 1
fi
log "Target database connection OK."

# ══════════════════════════════════════════════════════════════
# STEP 1: Determine Last Sync Point (Incremental Sync)
# ══════════════════════════════════════════════════════════════
if [ -f "$STATE_FILE" ]; then
    LAST_SYNC_TIMESTAMP=$(cat "$STATE_FILE")
    log "Resuming incremental sync from: ${LAST_SYNC_TIMESTAMP}"
else
    LAST_SYNC_TIMESTAMP="1970-01-01T00:00:00Z"
    log "No previous sync state found. Running full sync."
fi

# ══════════════════════════════════════════════════════════════
# STEP 2: Fetch Data from Source API (Paginated)
# ══════════════════════════════════════════════════════════════
log "Fetching data from source API..."

PAGE=1
TOTAL_RECORDS=0
HAS_MORE=true

while [ "$HAS_MORE" = true ]; do

    RESPONSE_FILE="${SYNC_DIR}/page_${PAGE}_${TIMESTAMP}.json"

    HTTP_CODE=$(curl -s -w "%{http_code}" -o "$RESPONSE_FILE" \
        -H "Authorization: Bearer ${API_TOKEN}" \
        -H "Content-Type: application/json" \
        "${SOURCE_API}/records?since=${LAST_SYNC_TIMESTAMP}&page=${PAGE}&limit=${BATCH_SIZE}")

    # Check HTTP response
    if [ "$HTTP_CODE" -ne 200 ]; then
        log "ERROR: API returned HTTP ${HTTP_CODE} on page ${PAGE}"
        cat "$RESPONSE_FILE" 2>/dev/null
        exit 1
    fi

    # Parse record count and pagination
    RECORD_COUNT=$(python3 -c "
import json
with open('${RESPONSE_FILE}') as f:
    data = json.load(f)
print(len(data.get('records', [])))
" 2>/dev/null || echo "0")

    HAS_MORE=$(python3 -c "
import json
with open('${RESPONSE_FILE}') as f:
    data = json.load(f)
print(str(data.get('has_more', False)).lower())
" 2>/dev/null || echo "false")

    TOTAL_RECORDS=$(( TOTAL_RECORDS + RECORD_COUNT ))
    log "  Page ${PAGE}: fetched ${RECORD_COUNT} records (total: ${TOTAL_RECORDS})"

    PAGE=$(( PAGE + 1 ))

    # Safety: max 100 pages per sync
    if [ $PAGE -gt 100 ]; then
        log "WARNING: Hit max page limit (100). Stopping pagination."
        break
    fi
done

log "Total records fetched: ${TOTAL_RECORDS}"

if [ "$TOTAL_RECORDS" -eq 0 ]; then
    log "No new records to sync. Exiting."
    exit 0
fi

# ══════════════════════════════════════════════════════════════
# STEP 3: Transform & Validate Data
# ══════════════════════════════════════════════════════════════
log "Transforming and validating data..."

TRANSFORMED_FILE="${SYNC_DIR}/transformed_${TIMESTAMP}.csv"

python3 <<PYEOF
import json, csv, glob, sys, os

staging_dir = "${SYNC_DIR}"
timestamp = "${TIMESTAMP}"
output_file = "${TRANSFORMED_FILE}"

records = []
for page_file in sorted(glob.glob(f"{staging_dir}/page_*_{timestamp}.json")):
    with open(page_file) as f:
        data = json.load(f)
        records.extend(data.get("records", []))

# Validate & transform
valid_records = []
skipped = 0
for r in records:
    # Required fields check
    if not all(k in r for k in ("id", "name", "value", "updated_at")):
        skipped += 1
        continue
    # Type coercion
    r["value"] = float(r.get("value", 0))
    valid_records.append(r)

print(f"Valid: {len(valid_records)}, Skipped: {skipped}")

# Write CSV for COPY
if valid_records:
    with open(output_file, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["id", "name", "value", "updated_at"])
        writer.writeheader()
        writer.writerows(valid_records)

sys.exit(0 if valid_records else 1)
PYEOF

log "Data transformation complete: ${TRANSFORMED_FILE}"

# ══════════════════════════════════════════════════════════════
# STEP 4: Load into Target Database (Upsert via temp table)
# ══════════════════════════════════════════════════════════════
log "Loading data into target database..."

psql -h "$TARGET_DB_HOST" \
     -p "$TARGET_DB_PORT" \
     -U "$TARGET_DB_USER" \
     -d "$TARGET_DB_NAME" \
     -v ON_ERROR_STOP=1 <<SQL
-- Create temp staging table
CREATE TEMP TABLE staging_sync (
    id          BIGINT,
    name        TEXT,
    value       DOUBLE PRECISION,
    updated_at  TIMESTAMPTZ
);

-- Bulk load CSV
\\COPY staging_sync FROM '${TRANSFORMED_FILE}' WITH (FORMAT csv, HEADER true);

-- Upsert into target table
INSERT INTO synced_records (id, name, value, updated_at, synced_at)
SELECT id, name, value, updated_at, NOW()
FROM staging_sync
ON CONFLICT (id) DO UPDATE SET
    name       = EXCLUDED.name,
    value      = EXCLUDED.value,
    updated_at = EXCLUDED.updated_at,
    synced_at  = NOW();

-- Drop temp table
DROP TABLE staging_sync;
SQL

LOADED_COUNT=$(psql -h "$TARGET_DB_HOST" -p "$TARGET_DB_PORT" -U "$TARGET_DB_USER" -d "$TARGET_DB_NAME" -t -c \
    "SELECT COUNT(*) FROM synced_records WHERE synced_at >= NOW() - INTERVAL '1 minute';" | tr -d ' ')

log "Loaded ${LOADED_COUNT} records into target database."

# ══════════════════════════════════════════════════════════════
# STEP 5: Update Sync State & Cleanup
# ══════════════════════════════════════════════════════════════
date -u +"%Y-%m-%dT%H:%M:%SZ" > "$STATE_FILE"
log "Sync state updated: $(cat $STATE_FILE)"

# Clean up staging files
rm -f "${SYNC_DIR}/page_*_${TIMESTAMP}.json"
rm -f "$TRANSFORMED_FILE"
log "Staging files cleaned up."

# ══════════════════════════════════════════════════════════════
# Summary
# ══════════════════════════════════════════════════════════════
log "═══════════════════════════════════"
log " DATA SYNC COMPLETED SUCCESSFULLY"
log " Records fetched : ${TOTAL_RECORDS}"
log " Records loaded  : ${LOADED_COUNT}"
log " Sync mode       : Incremental"
log "═══════════════════════════════════"

exit 0
