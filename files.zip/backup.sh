#!/bin/bash

# ══════════════════════════════════════════════════════════════
# backup.sh — Database & Application Backup Script
# ══════════════════════════════════════════════════════════════
# Usage  : ./backup.sh
# Schedule: Daily at 2:30 AM via cron_wrapper.sh
# Retries : 3 with exponential backoff (handles DB connection issues)
# ══════════════════════════════════════════════════════════════

set -euo pipefail

# ── Configuration ──
APP_NAME="myapp"
BACKUP_DIR="/apps/backups"
DB_HOST="localhost"
DB_PORT="5432"
DB_NAME="production_db"
DB_USER="backup_user"
RETENTION_DAYS=30
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
S3_BUCKET="s3://company-backups/daily"

# ── Logging Helper ──
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [BACKUP] $1"
}

# ── Pre-checks ──
log "Starting backup process..."

# Ensure backup directory exists
mkdir -p "${BACKUP_DIR}/db" "${BACKUP_DIR}/app" "${BACKUP_DIR}/config"

# Verify database connectivity
log "Checking database connectivity..."
if ! pg_isready -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -t 10 > /dev/null 2>&1; then
    log "ERROR: Cannot connect to database at ${DB_HOST}:${DB_PORT}"
    exit 1
fi
log "Database connection OK."

# ══════════════════════════════════════════════════════════════
# STEP 1: Database Backup (pg_dump)
# ══════════════════════════════════════════════════════════════
DB_BACKUP_FILE="${BACKUP_DIR}/db/${APP_NAME}_db_${TIMESTAMP}.sql.gz"

log "Dumping database '${DB_NAME}'..."
pg_dump -h "$DB_HOST" \
        -p "$DB_PORT" \
        -U "$DB_USER" \
        -d "$DB_NAME" \
        --no-owner \
        --no-privileges \
        --format=plain \
    | gzip > "$DB_BACKUP_FILE"

DB_SIZE=$(du -sh "$DB_BACKUP_FILE" | awk '{print $1}')
log "Database backup complete: ${DB_BACKUP_FILE} (${DB_SIZE})"

# ══════════════════════════════════════════════════════════════
# STEP 2: Application Files Backup
# ══════════════════════════════════════════════════════════════
APP_BACKUP_FILE="${BACKUP_DIR}/app/${APP_NAME}_app_${TIMESTAMP}.tar.gz"

log "Archiving application files..."
tar -czf "$APP_BACKUP_FILE" \
    --exclude='*.log' \
    --exclude='node_modules' \
    --exclude='.git' \
    --exclude='__pycache__' \
    /apps/${APP_NAME}/src \
    /apps/${APP_NAME}/templates \
    /apps/${APP_NAME}/static \
    2>/dev/null || true

APP_SIZE=$(du -sh "$APP_BACKUP_FILE" | awk '{print $1}')
log "Application backup complete: ${APP_BACKUP_FILE} (${APP_SIZE})"

# ══════════════════════════════════════════════════════════════
# STEP 3: Config Files Backup
# ══════════════════════════════════════════════════════════════
CONFIG_BACKUP_FILE="${BACKUP_DIR}/config/${APP_NAME}_config_${TIMESTAMP}.tar.gz"

log "Archiving configuration files..."
tar -czf "$CONFIG_BACKUP_FILE" \
    /apps/${APP_NAME}/config \
    /apps/${APP_NAME}/.env \
    /etc/nginx/sites-available/${APP_NAME}.conf \
    /etc/systemd/system/${APP_NAME}.service \
    2>/dev/null || true

log "Config backup complete: ${CONFIG_BACKUP_FILE}"

# ══════════════════════════════════════════════════════════════
# STEP 4: Upload to S3 (Remote Storage)
# ══════════════════════════════════════════════════════════════
log "Uploading backups to S3..."

if command -v aws &> /dev/null; then
    aws s3 cp "$DB_BACKUP_FILE"     "${S3_BUCKET}/db/" --quiet
    aws s3 cp "$APP_BACKUP_FILE"    "${S3_BUCKET}/app/" --quiet
    aws s3 cp "$CONFIG_BACKUP_FILE" "${S3_BUCKET}/config/" --quiet
    log "S3 upload complete."
else
    log "WARNING: AWS CLI not found. Skipping S3 upload."
fi

# ══════════════════════════════════════════════════════════════
# STEP 5: Cleanup Old Backups (Retention Policy)
# ══════════════════════════════════════════════════════════════
log "Cleaning up backups older than ${RETENTION_DAYS} days..."

DELETED_COUNT=$(find "$BACKUP_DIR" -type f -name "*.gz" -mtime +${RETENTION_DAYS} -print -delete | wc -l)
log "Removed ${DELETED_COUNT} old backup file(s)."

# ══════════════════════════════════════════════════════════════
# STEP 6: Verify Backup Integrity
# ══════════════════════════════════════════════════════════════
log "Verifying backup integrity..."

for FILE in "$DB_BACKUP_FILE" "$APP_BACKUP_FILE" "$CONFIG_BACKUP_FILE"; do
    if [ ! -s "$FILE" ]; then
        log "ERROR: Backup file is empty: ${FILE}"
        exit 1
    fi
    # Test gzip integrity
    if ! gzip -t "$FILE" 2>/dev/null; then
        log "ERROR: Backup file is corrupted: ${FILE}"
        exit 1
    fi
done

log "All backup files verified OK."

# ══════════════════════════════════════════════════════════════
# Summary
# ══════════════════════════════════════════════════════════════
log "═══════════════════════════════════"
log " BACKUP COMPLETED SUCCESSFULLY"
log " Database : ${DB_SIZE}"
log " App Files: ${APP_SIZE}"
log " Stored in: ${BACKUP_DIR}"
log "═══════════════════════════════════"

exit 0
