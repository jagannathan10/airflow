#!/bin/bash

# ══════════════════════════════════════════════════════════════
# report.sh — Daily System & Application Health Report
# ══════════════════════════════════════════════════════════════
# Usage  : ./report.sh
# Schedule: Daily at 12:00 PM via cron_wrapper.sh
# Retries : 0 (no retries needed for reporting)
# ══════════════════════════════════════════════════════════════

set -euo pipefail

# ── Configuration ──
APP_NAME="myapp"
REPORT_DIR="/apps/reports"
CRON_LOG_DIR="/apps/cron/logs"
DB_HOST="localhost"
DB_PORT="5432"
DB_NAME="production_db"
DB_USER="report_user"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
REPORT_DATE=$(date +"%Y-%m-%d")
HOSTNAME=$(hostname)

# Email / Notification
REPORT_EMAIL="ops-team@company.com"
SLACK_WEBHOOK="${SLACK_WEBHOOK_URL:-}"

# ── Logging Helper ──
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [REPORT] $1"
}

log "Generating daily report for ${REPORT_DATE}..."

mkdir -p "$REPORT_DIR"

REPORT_FILE="${REPORT_DIR}/daily_report_${TIMESTAMP}.json"
HTML_REPORT="${REPORT_DIR}/daily_report_${TIMESTAMP}.html"

# ══════════════════════════════════════════════════════════════
# SECTION 1: System Metrics
# ══════════════════════════════════════════════════════════════
log "Collecting system metrics..."

# CPU load averages
LOAD_1=$(uptime | awk -F'load average:' '{print $2}' | awk -F',' '{print $1}' | tr -d ' ')
LOAD_5=$(uptime | awk -F'load average:' '{print $2}' | awk -F',' '{print $2}' | tr -d ' ')
LOAD_15=$(uptime | awk -F'load average:' '{print $2}' | awk -F',' '{print $3}' | tr -d ' ')

# Memory usage
MEM_TOTAL=$(free -m | awk '/^Mem:/ {print $2}')
MEM_USED=$(free -m | awk '/^Mem:/ {print $3}')
MEM_PERCENT=$(echo "scale=1; $MEM_USED * 100 / $MEM_TOTAL" | bc)

# Disk usage
DISK_USAGE=$(df -h /apps | awk 'NR==2 {print $5}' | tr -d '%')
DISK_TOTAL=$(df -h /apps | awk 'NR==2 {print $2}')
DISK_AVAIL=$(df -h /apps | awk 'NR==2 {print $4}')

# Uptime
SYSTEM_UPTIME=$(uptime -p 2>/dev/null || uptime | awk -F'up ' '{print $2}' | awk -F',' '{print $1, $2}')

# ══════════════════════════════════════════════════════════════
# SECTION 2: Application Health Metrics
# ══════════════════════════════════════════════════════════════
log "Collecting application health metrics..."

# Check if app process is running
APP_RUNNING=false
APP_PID=""
APP_CPU=""
APP_MEM=""

if pgrep -f "$APP_NAME" > /dev/null 2>&1; then
    APP_RUNNING=true
    APP_PID=$(pgrep -f "$APP_NAME" -o)
    APP_CPU=$(ps -p "$APP_PID" -o %cpu --no-headers 2>/dev/null | tr -d ' ' || echo "0")
    APP_MEM=$(ps -p "$APP_PID" -o %mem --no-headers 2>/dev/null | tr -d ' ' || echo "0")
fi

# Application endpoint health check
APP_STATUS_CODE=0
APP_RESPONSE_TIME=0
if command -v curl &> /dev/null; then
    HEALTH_RESPONSE=$(curl -s -o /dev/null -w "%{http_code}:%{time_total}" \
        "http://localhost:8080/health" 2>/dev/null || echo "000:0")
    APP_STATUS_CODE=$(echo "$HEALTH_RESPONSE" | cut -d':' -f1)
    APP_RESPONSE_TIME=$(echo "$HEALTH_RESPONSE" | cut -d':' -f2)
fi

# ══════════════════════════════════════════════════════════════
# SECTION 3: Database Metrics
# ══════════════════════════════════════════════════════════════
log "Collecting database metrics..."

DB_REACHABLE=false
DB_SIZE=""
DB_CONNECTIONS=""
DB_SLOW_QUERIES=""

if pg_isready -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -t 5 > /dev/null 2>&1; then
    DB_REACHABLE=true

    DB_SIZE=$(psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -t -c \
        "SELECT pg_size_pretty(pg_database_size('${DB_NAME}'));" 2>/dev/null | tr -d ' ' || echo "unknown")

    DB_CONNECTIONS=$(psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -t -c \
        "SELECT count(*) FROM pg_stat_activity WHERE datname='${DB_NAME}';" 2>/dev/null | tr -d ' ' || echo "0")

    DB_SLOW_QUERIES=$(psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -t -c \
        "SELECT count(*) FROM pg_stat_activity WHERE datname='${DB_NAME}' AND state='active' AND now()-query_start > interval '30 seconds';" 2>/dev/null | tr -d ' ' || echo "0")
fi

# ══════════════════════════════════════════════════════════════
# SECTION 4: Cron Job Metrics (from cron_wrapper.sh logs)
# ══════════════════════════════════════════════════════════════
log "Analyzing cron job execution history..."

CRON_TOTAL=0
CRON_COMPLETED=0
CRON_FAILED=0
CRON_RETRIED=0
CRON_AVG_DURATION=0

if [ -d "$CRON_LOG_DIR" ]; then
    # Analyze today's cron logs
    CRON_METRICS=$(python3 <<PYEOF
import json, glob, os
from datetime import datetime, timedelta

log_dir = "${CRON_LOG_DIR}"
today = datetime.now().strftime("%Y%m%d")
total = completed = failed = retried = 0
durations = []

for log_file in glob.glob(f"{log_dir}/cron_status_metrics_{today}*.json"):
    try:
        with open(log_file) as f:
            data = json.load(f)
        total += 1
        status = data.get("cron.status", "")
        if status == "completed":
            completed += 1
        elif status == "FAILED":
            failed += 1

        retry_count = data.get("retry.retried_failed_job", 0)
        if retry_count > 0:
            retried += 1

        duration = data.get("cron.total_duration_seconds", 0)
        durations.append(duration)
    except (json.JSONDecodeError, KeyError):
        continue

avg_dur = round(sum(durations) / len(durations), 2) if durations else 0

print(json.dumps({
    "total": total,
    "completed": completed,
    "failed": failed,
    "retried": retried,
    "avg_duration": avg_dur
}))
PYEOF
    )

    CRON_TOTAL=$(echo "$CRON_METRICS" | python3 -c "import sys,json; print(json.load(sys.stdin)['total'])")
    CRON_COMPLETED=$(echo "$CRON_METRICS" | python3 -c "import sys,json; print(json.load(sys.stdin)['completed'])")
    CRON_FAILED=$(echo "$CRON_METRICS" | python3 -c "import sys,json; print(json.load(sys.stdin)['failed'])")
    CRON_RETRIED=$(echo "$CRON_METRICS" | python3 -c "import sys,json; print(json.load(sys.stdin)['retried'])")
    CRON_AVG_DURATION=$(echo "$CRON_METRICS" | python3 -c "import sys,json; print(json.load(sys.stdin)['avg_duration'])")
fi

# ══════════════════════════════════════════════════════════════
# SECTION 5: Security Checks
# ══════════════════════════════════════════════════════════════
log "Running security checks..."

# Failed SSH attempts (last 24h)
FAILED_SSH=0
if [ -f /var/log/auth.log ]; then
    FAILED_SSH=$(grep "Failed password" /var/log/auth.log 2>/dev/null | \
        awk -v d="$(date -d '1 day ago' '+%b %d')" '$0 ~ d' | wc -l || echo "0")
fi

# Pending security updates
PENDING_UPDATES=0
if command -v apt &> /dev/null; then
    PENDING_UPDATES=$(apt list --upgradable 2>/dev/null | grep -c "security" || echo "0")
fi

# SSL certificate expiry
SSL_DAYS_LEFT="N/A"
if command -v openssl &> /dev/null; then
    SSL_EXPIRY=$(echo | openssl s_client -servername localhost -connect localhost:443 2>/dev/null | \
        openssl x509 -noout -enddate 2>/dev/null | cut -d= -f2 || echo "")
    if [ -n "$SSL_EXPIRY" ]; then
        SSL_DAYS_LEFT=$(( ( $(date -d "$SSL_EXPIRY" +%s) - $(date +%s) ) / 86400 ))
    fi
fi

# ══════════════════════════════════════════════════════════════
# BUILD JSON REPORT
# ══════════════════════════════════════════════════════════════
log "Building JSON report..."

cat > "$REPORT_FILE" <<EOF
{
    "report": {
        "type": "daily_health_report",
        "date": "${REPORT_DATE}",
        "generated_at": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
        "host": "${HOSTNAME}"
    },

    "system": {
        "uptime": "${SYSTEM_UPTIME}",
        "load_average": {
            "1min": ${LOAD_1},
            "5min": ${LOAD_5},
            "15min": ${LOAD_15}
        },
        "memory": {
            "total_mb": ${MEM_TOTAL},
            "used_mb": ${MEM_USED},
            "usage_percent": ${MEM_PERCENT}
        },
        "disk": {
            "mount": "/apps",
            "total": "${DISK_TOTAL}",
            "available": "${DISK_AVAIL}",
            "usage_percent": ${DISK_USAGE}
        }
    },

    "application": {
        "name": "${APP_NAME}",
        "running": ${APP_RUNNING},
        "pid": "${APP_PID:-N/A}",
        "cpu_percent": "${APP_CPU:-0}",
        "memory_percent": "${APP_MEM:-0}",
        "health_check": {
            "endpoint": "http://localhost:8080/health",
            "http_status": ${APP_STATUS_CODE},
            "response_time_seconds": ${APP_RESPONSE_TIME}
        }
    },

    "database": {
        "host": "${DB_HOST}",
        "name": "${DB_NAME}",
        "reachable": ${DB_REACHABLE},
        "size": "${DB_SIZE:-unknown}",
        "active_connections": ${DB_CONNECTIONS:-0},
        "slow_queries": ${DB_SLOW_QUERIES:-0}
    },

    "cron_jobs": {
        "date": "${REPORT_DATE}",
        "total_executions": ${CRON_TOTAL},
        "completed": ${CRON_COMPLETED},
        "failed": ${CRON_FAILED},
        "retried": ${CRON_RETRIED},
        "avg_duration_seconds": ${CRON_AVG_DURATION},
        "success_rate_percent": $(echo "scale=1; if ($CRON_TOTAL > 0) $CRON_COMPLETED * 100 / $CRON_TOTAL else 0" | bc 2>/dev/null || echo "0")
    },

    "security": {
        "failed_ssh_attempts_24h": ${FAILED_SSH},
        "pending_security_updates": ${PENDING_UPDATES},
        "ssl_certificate_days_left": "${SSL_DAYS_LEFT}"
    },

    "alerts": [
        $(
            ALERTS=""
            if [ "$DISK_USAGE" -ge 80 ]; then
                ALERTS="${ALERTS}{\"severity\": \"warning\", \"message\": \"Disk usage at ${DISK_USAGE}%\"},"
            fi
            if [ "${MEM_PERCENT%.*}" -ge 90 ]; then
                ALERTS="${ALERTS}{\"severity\": \"warning\", \"message\": \"Memory usage at ${MEM_PERCENT}%\"},"
            fi
            if [ "$APP_RUNNING" = false ]; then
                ALERTS="${ALERTS}{\"severity\": \"critical\", \"message\": \"Application ${APP_NAME} is NOT running\"},"
            fi
            if [ "$DB_REACHABLE" = false ]; then
                ALERTS="${ALERTS}{\"severity\": \"critical\", \"message\": \"Database ${DB_NAME} is unreachable\"},"
            fi
            if [ "$CRON_FAILED" -gt 0 ]; then
                ALERTS="${ALERTS}{\"severity\": \"warning\", \"message\": \"${CRON_FAILED} cron job(s) failed today\"},"
            fi
            if [ "$APP_STATUS_CODE" -ne 200 ] && [ "$APP_STATUS_CODE" -ne 0 ]; then
                ALERTS="${ALERTS}{\"severity\": \"critical\", \"message\": \"Health check returned HTTP ${APP_STATUS_CODE}\"},"
            fi
            # Remove trailing comma
            echo "${ALERTS%,}"
        )
    ]
}
EOF

log "JSON report written: ${REPORT_FILE}"

# ══════════════════════════════════════════════════════════════
# BUILD HTML REPORT (for email)
# ══════════════════════════════════════════════════════════════
log "Building HTML report..."

python3 <<PYEOF
import json

with open("${REPORT_FILE}") as f:
    data = json.load(f)

# Status indicators
def status_badge(ok, label_ok="OK", label_fail="ALERT"):
    if ok:
        return f'<span style="background:#10b981;color:#fff;padding:2px 10px;border-radius:12px;">{label_ok}</span>'
    return f'<span style="background:#ef4444;color:#fff;padding:2px 10px;border-radius:12px;">{label_fail}</span>'

sys = data["system"]
app = data["application"]
db = data["database"]
cron = data["cron_jobs"]
sec = data["security"]
alerts = data.get("alerts", [])

alert_html = ""
for a in alerts:
    color = "#ef4444" if a["severity"] == "critical" else "#f59e0b"
    alert_html += f'<tr><td style="color:{color};font-weight:bold;">{a["severity"].upper()}</td><td>{a["message"]}</td></tr>'

if not alert_html:
    alert_html = '<tr><td colspan="2" style="color:#10b981;">No alerts - all systems healthy</td></tr>'

html = f"""<!DOCTYPE html>
<html>
<head><style>
  body {{ font-family: -apple-system, Arial, sans-serif; margin: 20px; background: #f9fafb; }}
  .container {{ max-width: 700px; margin: 0 auto; background: #fff; border-radius: 8px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }}
  h1 {{ color: #111827; font-size: 22px; border-bottom: 2px solid #e5e7eb; padding-bottom: 10px; }}
  h2 {{ color: #374151; font-size: 16px; margin-top: 24px; }}
  table {{ width: 100%; border-collapse: collapse; margin: 8px 0; }}
  td {{ padding: 6px 12px; border-bottom: 1px solid #f3f4f6; font-size: 14px; }}
  td:first-child {{ color: #6b7280; width: 40%; }}
  .footer {{ color: #9ca3af; font-size: 12px; margin-top: 20px; text-align: center; }}
</style></head>
<body>
<div class="container">
  <h1>Daily Health Report — {data['report']['date']}</h1>
  <p style="color:#6b7280;">Host: {data['report']['host']} | Generated: {data['report']['generated_at']}</p>

  <h2>Alerts</h2>
  <table>{alert_html}</table>

  <h2>System</h2>
  <table>
    <tr><td>Uptime</td><td>{sys['uptime']}</td></tr>
    <tr><td>Load Average</td><td>{sys['load_average']['1min']} / {sys['load_average']['5min']} / {sys['load_average']['15min']}</td></tr>
    <tr><td>Memory</td><td>{sys['memory']['used_mb']}MB / {sys['memory']['total_mb']}MB ({sys['memory']['usage_percent']}%)</td></tr>
    <tr><td>Disk (/apps)</td><td>{sys['disk']['usage_percent']}% used ({sys['disk']['available']} free)</td></tr>
  </table>

  <h2>Application</h2>
  <table>
    <tr><td>Status</td><td>{status_badge(app['running'], 'Running', 'DOWN')}</td></tr>
    <tr><td>Health Check</td><td>{status_badge(app['health_check']['http_status']==200, f"HTTP {app['health_check']['http_status']}", f"HTTP {app['health_check']['http_status']}")}</td></tr>
    <tr><td>Response Time</td><td>{app['health_check']['response_time_seconds']}s</td></tr>
  </table>

  <h2>Database</h2>
  <table>
    <tr><td>Status</td><td>{status_badge(db['reachable'], 'Connected', 'Unreachable')}</td></tr>
    <tr><td>Size</td><td>{db['size']}</td></tr>
    <tr><td>Connections</td><td>{db['active_connections']}</td></tr>
    <tr><td>Slow Queries</td><td>{db['slow_queries']}</td></tr>
  </table>

  <h2>Cron Jobs (Today)</h2>
  <table>
    <tr><td>Total Runs</td><td>{cron['total_executions']}</td></tr>
    <tr><td>Completed</td><td style="color:#10b981;">{cron['completed']}</td></tr>
    <tr><td>Failed</td><td style="color:#ef4444;">{cron['failed']}</td></tr>
    <tr><td>Retried</td><td>{cron['retried']}</td></tr>
    <tr><td>Avg Duration</td><td>{cron['avg_duration_seconds']}s</td></tr>
  </table>

  <h2>Security</h2>
  <table>
    <tr><td>Failed SSH (24h)</td><td>{sec['failed_ssh_attempts_24h']}</td></tr>
    <tr><td>Pending Updates</td><td>{sec['pending_security_updates']}</td></tr>
    <tr><td>SSL Cert Expiry</td><td>{sec['ssl_certificate_days_left']} days</td></tr>
  </table>

  <div class="footer">Auto-generated by report.sh | {data['report']['host']}</div>
</div>
</body></html>"""

with open("${HTML_REPORT}", "w") as f:
    f.write(html)

print("HTML report generated successfully.")
PYEOF

log "HTML report written: ${HTML_REPORT}"

# ══════════════════════════════════════════════════════════════
# SECTION 6: Send Notifications
# ══════════════════════════════════════════════════════════════

# Email (if mail command is available)
if command -v mail &> /dev/null; then
    log "Sending email report to ${REPORT_EMAIL}..."
    cat "$HTML_REPORT" | mail -s "Daily Health Report - ${HOSTNAME} - ${REPORT_DATE}" \
        -a "Content-Type: text/html" \
        "$REPORT_EMAIL" 2>/dev/null || log "WARNING: Email send failed."
fi

# Slack notification (if webhook is configured)
if [ -n "$SLACK_WEBHOOK" ]; then
    log "Sending Slack notification..."

    SLACK_COLOR=$([ "$CRON_FAILED" -gt 0 ] || [ "$APP_RUNNING" = false ] && echo "#ef4444" || echo "#10b981")

    curl -s -X POST "$SLACK_WEBHOOK" \
        -H "Content-Type: application/json" \
        -d "{
            \"attachments\": [{
                \"color\": \"${SLACK_COLOR}\",
                \"title\": \"Daily Health Report — ${HOSTNAME}\",
                \"text\": \"Date: ${REPORT_DATE}\nDisk: ${DISK_USAGE}% | Mem: ${MEM_PERCENT}% | Cron: ${CRON_COMPLETED}/${CRON_TOTAL} OK\",
                \"footer\": \"report.sh\"
            }]
        }" > /dev/null 2>&1 || log "WARNING: Slack notification failed."
fi

# ══════════════════════════════════════════════════════════════
# Summary
# ══════════════════════════════════════════════════════════════
log "═══════════════════════════════════"
log " DAILY REPORT GENERATED"
log " JSON  : ${REPORT_FILE}"
log " HTML  : ${HTML_REPORT}"
log " Alerts: $(echo "$REPORT_FILE" | xargs python3 -c "import sys,json; print(len(json.load(open(sys.argv[1]))['alerts']))" 2>/dev/null || echo '0')"
log "═══════════════════════════════════"

exit 0
