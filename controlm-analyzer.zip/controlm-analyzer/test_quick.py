import requests
import os
import json

# Find JSON test file
test_files = []
for d in ['.', os.path.expanduser('~/Downloads')]:
    if os.path.isdir(d):
        for f in os.listdir(d):
            if f.endswith('.json') and ('ctrl' in f.lower() or 'ctm' in f.lower() or 'hko' in f.lower()):
                test_files.append(os.path.join(d, f))

if not test_files:
    print('No test JSON files found')
else:
    path = test_files[0]
    print('Testing with:', path)
    with open(path, 'rb') as f:
        resp = requests.post('http://localhost:5000/analyze', files={'file': (os.path.basename(path), f, 'application/json')})
    print('Status:', resp.status_code)
    if resp.status_code == 200:
        data = resp.json()
        summary = data.get('summary', {})
        print('Total jobs:', summary.get('total_jobs', 'N/A'))
        print('Has folders:', bool(summary.get('folders')))
        print('Keys in response:', list(data.keys()))
        print('SUCCESS - Backend works!')
    else:
        print('ERROR:', resp.text[:500])
