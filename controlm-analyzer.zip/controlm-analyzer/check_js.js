// Quick syntax check for app.js
try {
  const fs = require('fs');
  const code = fs.readFileSync('static/js/app.js', 'utf8');
  new Function(code);
  console.log('OK - No syntax errors in app.js');
  console.log('File size:', code.length, 'bytes');
  
  // Check for key functions
  const fns = ['renderAll', 'initUpload', 'analyzeFile', 'renderDependencyGraph'];
  fns.forEach(fn => {
    if (code.includes('function ' + fn)) {
      console.log('  FOUND: function ' + fn);
    } else {
      console.log('  MISSING: function ' + fn);
    }
  });
} catch(e) {
  console.log('SYNTAX ERROR:', e.message);
  // Find line number
  const match = e.message.match(/at position (\d+)/);
  if (match) {
    const code = require('fs').readFileSync('static/js/app.js', 'utf8');
    const pos = parseInt(match[1]);
    const lines = code.substring(0, pos).split('\n');
    console.log('Error at line:', lines.length);
    console.log('Context:', code.substring(Math.max(0, pos - 100), pos + 100));
  }
}
