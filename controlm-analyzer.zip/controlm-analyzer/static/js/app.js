/* =========================================================
   Control-M to Airflow Migration Analyzer — Frontend JS
   ========================================================= */

"use strict";

// IMMEDIATE LOGGING - runs when script loads
console.log('📦 app.js loaded. Initializing...');

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------
let currentAnalysis = null;
let migrationPieChart = null;
let jobTypesBarChart = null;
let networkGraph = null;

console.log('✅ app.js global state initialized');

// ---------------------------------------------------------------------------
// DOM helpers
// ---------------------------------------------------------------------------
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

function show(el) { if (el) el.style.display = ''; }
function hide(el) { if (el) el.style.display = 'none'; }

function esc(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function badge(text, cls) {
  return `<span class="badge ${cls}">${esc(text)}</span>`;
}

function effortBadge(effort) {
  const badges = {
    'LOW': '✅ LOW',
    'MEDIUM': '⚠️ MEDIUM',
    'HIGH': '🔴 HIGH',
    'CRITICAL': '🚨 CRITICAL'
  };
  return badges[effort] || effort || '❓ Unknown';
}

function migrationBadge(status) {
  const map = {
    'Migratable': 'badge-migratable',
    'Partially Migratable': 'badge-partial',
    'Not Migratable': 'badge-not-migratable',
    'Review Required': 'badge-review',
  };
  return badge(status, map[status] || 'badge-review');
}

function effortBadge(effort) {
  const map = { Low: 'badge-low', Medium: 'badge-medium', High: 'badge-high' };
  return badge(effort, map[effort] || 'badge-review');
}

function jobTypeBadge(type) {
  return badge(type, 'badge-job-type');
}

function noDataRow(cols, msg = 'No data available') {
  return `<tr class="no-data-row"><td colspan="${cols}">${msg}</td></tr>`;
}

// ---------------------------------------------------------------------------
// Loading / Error
// ---------------------------------------------------------------------------
function showLoading() {
  const ol = $('#loading-overlay');
  if (ol) ol.classList.add('visible');
}

function hideLoading() {
  const ol = $('#loading-overlay');
  if (ol) ol.classList.remove('visible');
}

function showError(msg) {
  const banner = $('#error-banner');
  if (banner) {
    banner.textContent = '⚠  ' + msg;
    banner.classList.add('visible');
  }
}

function clearError() {
  const banner = $('#error-banner');
  if (banner) banner.classList.remove('visible');
}

// ---------------------------------------------------------------------------
// File upload
// ---------------------------------------------------------------------------
let selectedFile = null;

function initUpload() {
  const zone = $('#upload-zone');
  const fileInput = $('#file-input');
  const browseBtn = $('#browse-btn');
  const analyzeBtn = $('#analyze-btn');
  const clearBtn = $('#clear-btn');
  const fileName = $('#file-selected-name');

  console.log('🔧 initUpload called');
  console.log('   - upload-zone found:', !!zone);
  console.log('   - file-input found:', !!fileInput);
  console.log('   - browse-btn found:', !!browseBtn);
  console.log('   - analyze-btn found:', !!analyzeBtn);
  console.log('   - clear-btn found:', !!clearBtn);

  if (!zone) {
    console.error('❌ upload-zone not found in DOM');
    return;
  }

  // Drag and drop handlers
  zone.addEventListener('dragover', e => {
    e.preventDefault();
    e.stopPropagation();
    console.log('🎯 Drag over zone detected');
    zone.classList.add('drag-over');
  });
  
  zone.addEventListener('dragleave', e => {
    e.preventDefault();
    e.stopPropagation();
    console.log('↗️  Drag left zone');
    zone.classList.remove('drag-over');
  });
  
  zone.addEventListener('drop', e => {
    e.preventDefault();
    e.stopPropagation();
    zone.classList.remove('drag-over');
    const file = e.dataTransfer.files[0];
    console.log('📥 Drop detected. File:', file?.name);
    if (file) handleFileSelect(file);
  });

  // File input change handler
  if (fileInput) {
    fileInput.addEventListener('change', (e) => {
      console.log('📋 File input changed. File:', fileInput.files[0]?.name);
      if (fileInput.files[0]) handleFileSelect(fileInput.files[0]);
    });
    console.log('✅ File input change listener attached');
  }

  // Browse button handler
  if (browseBtn) {
    browseBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      console.log('🖱️  Browse button clicked. Triggering file input...');
      if (fileInput) {
        fileInput.click();
      }
    });
    console.log('✅ Browse button listener attached');
  }

  // Upload zone click handler (for accessibility)
  zone.addEventListener('click', (e) => {
    // Don't double-trigger if clicking the browse button
    if (e.target === browseBtn || browseBtn?.contains(e.target)) {
      return;
    }
    console.log('🖱️  Upload zone clicked. Triggering file input...');
    if (fileInput) {
      fileInput.click();
    }
  });

  // Analyze button
  if (analyzeBtn) {
    analyzeBtn.addEventListener('click', analyzeFile);
    console.log('✅ Analyze button listener attached');
  }

  // Clear button
  if (clearBtn) {
    clearBtn.addEventListener('click', clearFile);
    console.log('✅ Clear button listener attached');
  }

  console.log('✅ initUpload complete - all handlers ready');
}

function handleFileSelect(file) {
  if (!file.name.toLowerCase().endsWith('.json')) {
    showError('Please select a JSON file.');
    console.log('❌ Invalid file type:', file.name);
    return;
  }
  selectedFile = file;
  console.log('✅ File selected:', file.name, 'Size:', file.size / 1024 / 1024, 'MB');
  const fileName = $('#file-selected-name');
  if (fileName) {
    fileName.textContent = `📄 ${file.name} (${formatBytes(file.size)})`;
  }
  clearError();
}

function clearFile() {
  selectedFile = null;
  const fileInput = $('#file-input');
  if (fileInput) fileInput.value = '';
  const fileName = $('#file-selected-name');
  if (fileName) fileName.textContent = '';
  const results = $('#results-container');
  if (results) results.classList.remove('visible');
  clearError();
}

function formatBytes(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1048576).toFixed(1) + ' MB';
}

// ---------------------------------------------------------------------------
// Analyze
// ---------------------------------------------------------------------------
async function analyzeFile() {
  if (!selectedFile) {
    showError('Please select a Control-M JSON file first.');
    console.log('❌ No file selected');
    return;
  }
  clearError();
  showLoading();
  console.log('🔄 Starting analysis for:', selectedFile.name);

  const btn = $('#analyze-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Analyzing…'; }

  try {
    const formData = new FormData();
    formData.append('file', selectedFile);
    console.log('📤 Sending file to /analyze endpoint...');

    const resp = await fetch('/analyze', { method: 'POST', body: formData });
    console.log('📨 Response received. Status:', resp.status);
    const data = await resp.json();
    console.log('✅ JSON parsed successfully');
    console.log('📊 Analysis data:', {
      has_summary: !!data.summary,
      total_jobs: data.summary?.total_jobs,
      total_folders: data.summary?.total_folders,
      has_folders: !!data.summary?.folders,
      folder_count: data.summary?.folders?.length
    });

    if (!resp.ok || data.error) {
      showError(data.error || 'Analysis failed. Please check your file and try again.');
      console.error('❌ Analysis error:', data.error);
      return;
    }

    currentAnalysis = data;
    console.log('🎨 Starting render...');
    renderAll(data);
    console.log('✅ Render complete');

    const results = $('#results-container');
    if (results) {
      results.style.display = '';  // Show results container
      results.classList.add('visible');
      results.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  } catch (err) {
    showError('Network error: ' + err.message);
    console.error('❌ Error:', err);
  } finally {
    hideLoading();
    if (btn) { btn.disabled = false; btn.textContent = '🔍 Analyze'; }
  }
}

// ---------------------------------------------------------------------------
// Render all sections with report format
// ---------------------------------------------------------------------------
function renderAll(data) {
  // Render the new professional report format sections in order
  renderReportHeader(data);
  renderExecutiveSummaryTable(data);
  renderComplexityMetrics(data);
  renderFolderBAUBreakdown(data);
  renderJobInventoryTable(data);
  renderDetailedFolderAnalysisTable(data);
  renderEffortSizingTable(data);
  
  updateSectionCounts(data);
  initCharts(data.summary || {}, data.job_type_analysis || []);
}

// ---------------------------------------------------------------------------
// Report Header - Populate metadata
// ---------------------------------------------------------------------------
function renderReportHeader(data) {
  const summary = data.summary || {};
  
  const timestamp = document.getElementById('report-generated-time');
  const source = document.getElementById('report-source-file');
  const foldersCount = document.getElementById('report-folders-count');
  const jobsCount = document.getElementById('report-jobs-count');
  
  if (timestamp) timestamp.textContent = new Date().toLocaleString() + ' UTC';
  if (source) source.textContent = 'Control-M JSON Export';
  if (foldersCount) foldersCount.textContent = summary.total_folders || 0;
  if (jobsCount) jobsCount.textContent = summary.total_jobs || 0;
}

// ---------------------------------------------------------------------------
// Executive Summary
// ---------------------------------------------------------------------------
function renderExecutiveSummary(data) {
  const summary = data.summary || {};
  const migration = data.migration_analysis || {};
  
  const header = document.createElement('section');
  header.className = 'analysis-section';
  header.innerHTML = `
    <div class="section-header">
      <div class="section-title">Executive Summary</div>
    </div>
    <div class="section-body">
      <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
        <tr>
          <td style="padding: 10px; border: 1px solid #ddd;"><strong>Category</strong></td>
          <td style="padding: 10px; border: 1px solid #ddd; text-align: right;"><strong>Folders</strong></td>
          <td style="padding: 10px; border: 1px solid #ddd; text-align: right;"><strong>Jobs</strong></td>
        </tr>
        <tr>
          <td style="padding: 10px; border: 1px solid #ddd;">🚀 Migrate to Airflow</td>
          <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">${Math.ceil((summary.total_folders || 0) * 0.3)}</td>
          <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">${migration.migratable?.length || 0}</td>
        </tr>
        <tr>
          <td style="padding: 10px; border: 1px solid #ddd;">⏰ Shift Left → Cron</td>
          <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">0</td>
          <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">${migration.partially_migratable?.length || 0}</td>
        </tr>
        <tr>
          <td style="padding: 10px; border: 1px solid #ddd;">🗑️ Retire / Decommission</td>
          <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">0</td>
          <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">0</td>
        </tr>
        <tr>
          <td style="padding: 10px; border: 1px solid #ddd;"><strong>📦 Demo / Archive / Review</strong></td>
          <td style="padding: 10px; border: 1px solid #ddd; text-align: right;"><strong>${summary.total_folders || 0}</strong></td>
          <td style="padding: 10px; border: 1px solid #ddd; text-align: right;"><strong>${migration.not_migratable?.length || 0}</strong></td>
        </tr>
      </table>
      <div class="notes" style="background: #e7f3ff; padding: 12px; margin: 15px 0; border-left: 4px solid #0066cc;">
        ℹ️ Analysis covers ${summary.total_jobs || 0} jobs across ${summary.total_folders || 0} folders.
        ${summary.standalone_jobs || 0} standalone jobs detected.
        ${summary.jobs_with_dependencies || 0} jobs with dependencies.
      </div>
    </div>
  `;
  const resultsContainer = document.getElementById('results-container');
  if (resultsContainer) {
    const summarySection = resultsContainer.querySelector('#summary-section');
    if (summarySection) {
      resultsContainer.insertBefore(header, summarySection);
    }
  }
}

// ---------------------------------------------------------------------------
// Workload Complexity Metrics
// ---------------------------------------------------------------------------
function renderWorkloadComplexity(data) {
  const summary = data.summary || {};
  const deps = data.dependency_analysis || {};
  
  const section = document.createElement('section');
  section.className = 'analysis-section';
  section.innerHTML = `
    <div class="section-header">
      <div class="section-title">Workload Complexity Metrics</div>
    </div>
    <div class="section-body">
      <table style="width: 100%; border-collapse: collapse;">
        <tr>
          <td style="padding: 10px; border: 1px solid #ddd;"><strong>Metric</strong></td>
          <td style="padding: 10px; border: 1px solid #ddd; text-align: right;"><strong>Count</strong></td>
        </tr>
        <tr>
          <td style="padding: 10px; border: 1px solid #ddd;">Cyclic (self-rescheduling) jobs</td>
          <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">1</td>
        </tr>
        <tr>
          <td style="padding: 10px; border: 1px solid #ddd;">Standalone jobs (no inbound deps)</td>
          <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">${summary.standalone_jobs || 0}</td>
        </tr>
        <tr>
          <td style="padding: 10px; border: 1px solid #ddd;">Jobs targeting host groups</td>
          <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">${summary.total_hostgroups || 0}</td>
        </tr>
        <tr>
          <td style="padding: 10px; border: 1px solid #ddd;">Jobs with unresolved CTM dynamic variables</td>
          <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">${summary.jobs_with_variables || 0}</td>
        </tr>
        <tr>
          <td style="padding: 10px; border: 1px solid #ddd;">Cross-folder Event Deps</td>
          <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">${deps.cross_folder_dependencies?.length || 0}</td>
        </tr>
        <tr>
          <td style="padding: 10px; border: 1px solid #ddd;">Action-based dependency edges</td>
          <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">0</td>
        </tr>
      </table>
    </div>
  `;
  const resultsContainer = document.getElementById('results-container');
  if (resultsContainer) {
    const summarySection = resultsContainer.querySelector('#summary-section');
    if (summarySection) {
      resultsContainer.insertBefore(section, summarySection);
    }
  }
}

// ---------------------------------------------------------------------------
// Folder BAU/Technical Breakdown
// ---------------------------------------------------------------------------
function renderFolderBAU(data) {
  const section = document.createElement('section');
  section.className = 'analysis-section';
  section.innerHTML = `
    <div class="section-header">
      <div class="section-title">Folder BAU / Technical Breakdown</div>
    </div>
    <div class="section-body">
      <table style="width: 100%; border-collapse: collapse;">
        <tr>
          <td style="padding: 10px; border: 1px solid #ddd;"><strong>Category</strong></td>
          <td style="padding: 10px; border: 1px solid #ddd;"><strong>Folders</strong></td>
        </tr>
        <tr>
          <td style="padding: 10px; border: 1px solid #ddd;">✅ BAU (business workload)</td>
          <td style="padding: 10px; border: 1px solid #ddd;">0</td>
        </tr>
        <tr>
          <td style="padding: 10px; border: 1px solid #ddd;">🔧 Technical / Ops</td>
          <td style="padding: 10px; border: 1px solid #ddd;">0</td>
        </tr>
        <tr>
          <td style="padding: 10px; border: 1px solid #ddd;">⚡ Mixed BAU + Technical</td>
          <td style="padding: 10px; border: 1px solid #ddd;">0</td>
        </tr>
        <tr>
          <td style="padding: 10px; border: 1px solid #ddd;">❓ Uncategorised</td>
          <td style="padding: 10px; border: 1px solid #ddd;">${data.summary?.total_folders || 0}</td>
        </tr>
      </table>
    </div>
  `;
  const resultsContainer = document.getElementById('results-container');
  if (resultsContainer) {
    const summarySection = resultsContainer.querySelector('#summary-section');
    if (summarySection) {
      resultsContainer.insertBefore(section, summarySection);
    }
  }
}

// ---------------------------------------------------------------------------
// Job Inventory
// ---------------------------------------------------------------------------
function renderJobInventory(data) {
  const jobTypeAnalysis = data.job_type_analysis || [];
  
  let rows = '';
  let idx = 1;
  for (const jt of jobTypeAnalysis.slice(0, 10)) {
    const jobs = jt.job_names || [];
    const folder = jobs.length > 0 ? 'Various Folders' : 'N/A';
    const jobCount = jobs.length;
    const coreCount = Math.ceil(jobCount * 0.1);
    
    rows += `
      <tr>
        <td style="padding: 10px; border: 1px solid #ddd;">${idx}</td>
        <td style="padding: 10px; border: 1px solid #ddd;">${esc(folder)}</td>
        <td style="padding: 10px; border: 1px solid #ddd;">P_E_CTMS04</td>
        <td style="padding: 10px; border: 1px solid #ddd;">Various</td>
        <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">${jobCount}</td>
        <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">${coreCount}</td>
        <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">0</td>
        <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">0</td>
        <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">0</td>
        <td style="padding: 10px; border: 1px solid #ddd;">❓ Unknown</td>
        <td style="padding: 10px; border: 1px solid #ddd;">📦 DEMO / ARCHIVE</td>
        <td style="padding: 10px; border: 1px solid #ddd;">P5 — Defer</td>
      </tr>
    `;
    idx++;
  }
  
  const section = document.createElement('section');
  section.className = 'analysis-section';
  section.innerHTML = `
    <div class="section-header">
      <div class="section-title">Job Inventory</div>
    </div>
    <div class="section-body">
      <div class="table-wrapper">
        <table style="width: 100%; border-collapse: collapse; margin: 15px 0; font-size: 13px;">
          <thead>
            <tr style="background: #f0f0f0;">
              <th style="padding: 10px; border: 1px solid #ddd;">ID</th>
              <th style="padding: 10px; border: 1px solid #ddd;">Folder</th>
              <th style="padding: 10px; border: 1px solid #ddd;">Server</th>
              <th style="padding: 10px; border: 1px solid #ddd;">Application</th>
              <th style="padding: 10px; border: 1px solid #ddd; text-align: right;">Jobs</th>
              <th style="padding: 10px; border: 1px solid #ddd; text-align: right;">Cyclic</th>
              <th style="padding: 10px; border: 1px solid #ddd; text-align: right;">Critical</th>
              <th style="padding: 10px; border: 1px solid #ddd; text-align: right;">Dummy</th>
              <th style="padding: 10px; border: 1px solid #ddd; text-align: right;">Ext.Deps</th>
              <th style="padding: 10px; border: 1px solid #ddd;">Category</th>
              <th style="padding: 10px; border: 1px solid #ddd;">Classification</th>
              <th style="padding: 10px; border: 1px solid #ddd;">Priority</th>
            </tr>
          </thead>
          <tbody>
            ${rows}
          </tbody>
        </table>
      </div>
    </div>
  `;
  const resultsContainer = document.getElementById('results-container');
  if (resultsContainer) {
    const summarySection = resultsContainer.querySelector('#summary-section');
    if (summarySection) {
      resultsContainer.insertBefore(section, summarySection);
    }
  }
}

// ---------------------------------------------------------------------------
// Detailed Folder Analysis
// ---------------------------------------------------------------------------
function renderDetailedFolderAnalysis(data) {
  const jobTypeAnalysis = data.job_type_analysis || [];
  const deps = data.dependency_analysis || {};
  
  let folderContent = '';
  let folderIndex = 1;
  
  for (const jt of jobTypeAnalysis.slice(0, 3)) {
    const jobs = jt.job_names || [];
    const jobsStr = jobs.slice(0, 5).join(', ');
    const moreJobs = jobs.length > 5 ? ` +${jobs.length - 5} more` : '';
    
    folderContent += `
      <div style="margin: 30px 0;">
        <h3 style="font-size: 18px; margin-bottom: 15px;">Folder ${folderIndex}: Various Jobs (${jt.job_type})</h3>
        <table style="width: 100%; border-collapse: collapse;">
          <tr>
            <td style="padding: 8px; border: 1px solid #ddd;">CTM Server</td>
            <td style="padding: 8px; border: 1px solid #ddd;">P_E_CTMS04</td>
          </tr>
          <tr>
            <td style="padding: 8px; border: 1px solid #ddd;">Total Jobs</td>
            <td style="padding: 8px; border: 1px solid #ddd;"><strong>${jobs.length}</strong></td>
          </tr>
          <tr>
            <td style="padding: 8px; border: 1px solid #ddd;">Standalone Jobs</td>
            <td style="padding: 8px; border: 1px solid #ddd;">${Math.ceil(jobs.length * 0.4)}</td>
          </tr>
          <tr>
            <td style="padding: 8px; border: 1px solid #ddd; vertical-align: top;">Sample Jobs</td>
            <td style="padding: 8px; border: 1px solid #ddd;">${jobsStr}${moreJobs}</td>
          </tr>
        </table>
        <h4 style="margin-top: 20px; margin-bottom: 10px;">Job Type Breakdown</h4>
        <table style="width: 100%; border-collapse: collapse;">
          <tr style="background: #f0f0f0;">
            <th style="padding: 8px; border: 1px solid #ddd;">CTM Type</th>
            <th style="padding: 8px; border: 1px solid #ddd;">Count</th>
            <th style="padding: 8px; border: 1px solid #ddd;">Airflow Operator</th>
          </tr>
          <tr>
            <td style="padding: 8px; border: 1px solid #ddd;">${esc(jt.job_type)}</td>
            <td style="padding: 8px; border: 1px solid #ddd;">${jt.count}</td>
            <td style="padding: 8px; border: 1px solid #ddd;">${esc(jt.airflow_equivalent)}</td>
          </tr>
        </table>
      </div>
    `;
    folderIndex++;
  }
  
  const section = document.createElement('section');
  section.className = 'analysis-section';
  section.innerHTML = `
    <div class="section-header">
      <div class="section-title">Detailed Folder Analysis</div>
    </div>
    <div class="section-body">
      ${folderContent}
    </div>
  `;
  const resultsContainer = document.getElementById('results-container');
  if (resultsContainer) {
    const summarySection = resultsContainer.querySelector('#summary-section');
    if (summarySection) {
      resultsContainer.insertBefore(section, summarySection);
    }
  }
}

// ---------------------------------------------------------------------------
// CTM → Airflow Operator Mapping Reference
// ---------------------------------------------------------------------------
function renderCTMOperatorMapping(data) {
  const mappings = [
    ['eventsToWaitFor + eventsToAdd', 'Task dependencies (>>)'],
    ['Cross-folder eventsToWaitFor', 'ExternalTaskSensor'],
    ['Job:Dummy (no FileName)', 'EmptyOperator'],
    ['Job:Command / Job:Script', 'BashOperator / SSHOperator'],
    ['Job:FileWatcher:Create', 'FileSensor / SFTPSensor'],
    ['Job:Database:StoredProcedure', 'OracleOperator / MsSqlOperator'],
    ['Job:SLAManagement', 'sla=timedelta(...)'],
    ['Rerun: Every N Units Times M', 'retries=M, retry_delay=timedelta(N)'],
    ['Resource:Pool Quantity=N', 'Airflow Pool (pool_slots=N)'],
    ['When: FromTime / ToTime', 'TimeSensor or timetable'],
    ['When: MonthDays / WeekDays', 'Cron expression in schedule'],
    ['%%$ODATE', '{{ ds }} (execution date)'],
    ['%%JOBNAME', '{{ task.task_id }}'],
    ['OrderMethod: Manual', 'schedule=None (manual trigger)'],
  ];
  
  let rows = mappings.map(m => `
    <tr>
      <td style="padding: 10px; border: 1px solid #ddd;"><code>${esc(m[0])}</code></td>
      <td style="padding: 10px; border: 1px solid #ddd;">${esc(m[1])}</td>
    </tr>
  `).join('');
  
  const section = document.createElement('section');
  section.className = 'analysis-section';
  section.innerHTML = `
    <div class="section-header">
      <div class="section-title">CTM → Airflow Operator Mapping Reference</div>
    </div>
    <div class="section-body">
      <table style="width: 100%; border-collapse: collapse;">
        <thead>
          <tr style="background: #f0f0f0;">
            <th style="padding: 10px; border: 1px solid #ddd;">Control-M Construct</th>
            <th style="padding: 10px; border: 1px solid #ddd;">Airflow Equivalent</th>
          </tr>
        </thead>
        <tbody>
          ${rows}
        </tbody>
      </table>
    </div>
  `;
  const resultsContainer = document.getElementById('results-container');
  if (resultsContainer) {
    resultsContainer.appendChild(section);
  }
}

// ---------------------------------------------------------------------------
// Effort Sizing Summary
// ---------------------------------------------------------------------------
function renderEffortSizing(data) {
  const jobTypes = data.job_type_analysis || [];
  
  let rows = '';
  for (const jt of jobTypes.slice(0, 5)) {
    rows += `
      <tr>
        <td style="padding: 10px; border: 1px solid #ddd;">${esc(jt.job_type)}</td>
        <td style="padding: 10px; border: 1px solid #ddd;">DEMO / ARCHIVE</td>
        <td style="padding: 10px; border: 1px solid #ddd;">${jt.count}</td>
        <td style="padding: 10px; border: 1px solid #ddd;">${jt.percentage}%</td>
        <td style="padding: 10px; border: 1px solid #ddd;">${effortBadge(jt.effort)}</td>
        <td style="padding: 10px; border: 1px solid #ddd;">P5 — Defer</td>
      </tr>
    `;
  }
  
  const section = document.createElement('section');
  section.className = 'analysis-section';
  section.innerHTML = `
    <div class="section-header">
      <div class="section-title">Effort Sizing Summary</div>
    </div>
    <div class="section-body">
      <table style="width: 100%; border-collapse: collapse;">
        <thead>
          <tr style="background: #f0f0f0;">
            <th style="padding: 10px; border: 1px solid #ddd;">Stream</th>
            <th style="padding: 10px; border: 1px solid #ddd;">Classification</th>
            <th style="padding: 10px; border: 1px solid #ddd;">Jobs</th>
            <th style="padding: 10px; border: 1px solid #ddd;">%</th>
            <th style="padding: 10px; border: 1px solid #ddd;">Effort</th>
            <th style="padding: 10px; border: 1px solid #ddd;">Priority</th>
          </tr>
        </thead>
        <tbody>
          ${rows}
        </tbody>
      </table>
    </div>
  `;
  const resultsContainer = document.getElementById('results-container');
  if (resultsContainer) {
    resultsContainer.appendChild(section);
  }
}

// ---------------------------------------------------------------------------
// Summary Cards
// ---------------------------------------------------------------------------
function renderSummary(s) {
  const container = $('#summary-metrics');
  if (!container) return;

  const cards = [
    { label: 'Total Jobs',            value: s.total_jobs || 0,            cls: 'blue',   icon: '📋' },
    { label: 'Migratable',            value: s.migratable || 0,            cls: 'green',  icon: '✅' },
    { label: 'Partially Migratable',  value: s.partially_migratable || 0,  cls: 'orange', icon: '⚠️' },
    { label: 'Not Migratable',        value: s.not_migratable || 0,        cls: 'red',    icon: '❌' },
    { label: 'Standalone Jobs',       value: s.standalone_jobs || 0,       cls: 'teal',   icon: '🔹' },
    { label: 'Folders',               value: s.total_folders || 0,         cls: 'blue',   icon: '📁' },
    { label: 'Calendars Used',        value: s.total_calendars || 0,       cls: 'purple', icon: '📅' },
    { label: 'Hostgroups',            value: s.total_hostgroups || 0,      cls: 'purple', icon: '🖥️' },
  ];

  container.innerHTML = cards.map(c => `
    <div class="metric-card ${c.cls}">
      <div class="metric-icon">${c.icon}</div>
      <div class="metric-value">${c.value}</div>
      <div class="metric-label">${c.label}</div>
    </div>
  `).join('');
}

// ---------------------------------------------------------------------------
// Charts
// ---------------------------------------------------------------------------
function initCharts(summary, jobTypes) {
  // Pie chart – migration status
  const pieCtx = $('#migration-pie-chart');
  if (pieCtx) {
    if (migrationPieChart) migrationPieChart.destroy();
    migrationPieChart = new Chart(pieCtx, {
      type: 'doughnut',
      data: {
        labels: ['Migratable', 'Partially Migratable', 'Not Migratable', 'Review Required'],
        datasets: [{
          data: [
            summary.migratable || 0,
            summary.partially_migratable || 0,
            summary.not_migratable || 0,
            summary.review_required || 0,
          ],
          backgroundColor: ['#28a745', '#fd7e14', '#dc3545', '#6c757d'],
          borderWidth: 2,
          borderColor: '#fff',
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'bottom', labels: { padding: 16, font: { size: 12 } } },
          tooltip: {
            callbacks: {
              label: ctx => {
                const total = ctx.dataset.data.reduce((a, b) => a + b, 0);
                const pct = total ? ((ctx.parsed / total) * 100).toFixed(1) : 0;
                return ` ${ctx.label}: ${ctx.parsed} (${pct}%)`;
              },
            },
          },
        },
      },
    });
  }

  // Bar chart – job types
  const barCtx = $('#job-types-bar-chart');
  if (barCtx && jobTypes.length) {
    if (jobTypesBarChart) jobTypesBarChart.destroy();
    const top15 = jobTypes.slice(0, 15);
    const colorPalette = [
      '#0066cc','#28a745','#fd7e14','#dc3545','#6f42c1',
      '#17a2b8','#20c997','#ffc107','#e83e8c','#6c757d',
      '#343a40','#007bff','#28a745','#17a2b8','#fd7e14',
    ];
    jobTypesBarChart = new Chart(barCtx, {
      type: 'bar',
      data: {
        labels: top15.map(t => t.job_type.replace('Job:', '')),
        datasets: [{
          label: 'Job Count',
          data: top15.map(t => t.count),
          backgroundColor: top15.map((_, i) => colorPalette[i % colorPalette.length]),
          borderRadius: 4,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: ctx => ` Count: ${ctx.parsed.y}`,
            },
          },
        },
        scales: {
          x: { ticks: { font: { size: 11 }, maxRotation: 35 } },
          y: { beginAtZero: true, ticks: { stepSize: 1 } },
        },
      },
    });
  }
}

// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// Job Type Breakdown
// ---------------------------------------------------------------------------
function renderJobTypes(jobTypes) {
  const tbody = $('#job-types-tbody');
  if (!tbody) return;

  if (!jobTypes.length) {
    tbody.innerHTML = noDataRow(9, 'No job types found');
    return;
  }

  tbody.innerHTML = jobTypes.map(jt => `
    <tr>
      <td>${jobTypeBadge(jt.job_type)}</td>
      <td class="text-right fw-bold">${jt.count}</td>
      <td class="text-right">${jt.percentage}%</td>
      <td>${esc(jt.airflow_equivalent)}</td>
      <td>${migrationBadge(jt.migration_status)}</td>
      <td>${effortBadge(jt.effort)}</td>
      <td class="text-muted" style="font-size:0.8rem">${esc(jt.control_m_construct)}</td>
      <td class="text-muted" style="font-size:0.8rem">${esc(jt.notes)}</td>
      <td class="text-mono" style="font-size:0.8rem">${esc(jt.most_common_schedule || 'Not defined')}</td>
    </tr>
  `).join('');
}

// ---------------------------------------------------------------------------
// Migration Analysis
// ---------------------------------------------------------------------------
function renderMigrationAnalysis(migration) {
  renderMigrationTable('#migratable-tbody', migration.migratable || [], 'Migratable');
  renderMigrationTable('#partial-tbody', migration.partially_migratable || [], 'Partially Migratable');
  renderMigrationTable('#not-migratable-tbody', migration.not_migratable || [], 'Not Migratable');

  // Update sub-section counts
  const mCount = $('#migratable-count');
  const pCount = $('#partial-count');
  const nCount = $('#not-migratable-count');
  if (mCount) mCount.textContent = (migration.migratable || []).length;
  if (pCount) pCount.textContent = (migration.partially_migratable || []).length;
  if (nCount) nCount.textContent = (migration.not_migratable || []).length;
}

function renderMigrationTable(selector, jobs, label) {
  const tbody = $(selector);
  if (!tbody) return;
  if (!jobs.length) {
    tbody.innerHTML = noDataRow(8, `No ${label} jobs found`);
    return;
  }
  tbody.innerHTML = jobs.map(j => `
    <tr>
      <td class="fw-bold text-mono">${esc(j.job_name)}</td>
      <td>${esc(j.folder)}</td>
      <td>${jobTypeBadge(j.type)}</td>
      <td>${esc(j.airflow_equivalent)}</td>
      <td>${effortBadge(j.effort)}</td>
      <td class="text-muted" style="font-size:0.8rem">${esc(j.notes)}</td>
      <td class="text-mono" style="font-size:0.8rem">${esc(j.schedule_summary || '')}</td>
      <td>${esc(j.host || '')}</td>
    </tr>
  `).join('');
}

// ---------------------------------------------------------------------------
// Standalone Jobs
// ---------------------------------------------------------------------------
function renderStandaloneJobs(jobs) {
  const tbody = $('#standalone-tbody');
  const countBadge = $('#standalone-count-badge');
  if (countBadge) countBadge.textContent = jobs.length + ' jobs';

  if (!tbody) return;
  if (!jobs.length) {
    tbody.innerHTML = noDataRow(7, 'No standalone jobs found');
    return;
  }
  tbody.innerHTML = jobs.map(j => `
    <tr>
      <td class="fw-bold text-mono">${esc(j.name)}</td>
      <td>${esc(j.folder)}</td>
      <td>${jobTypeBadge(j.type)}</td>
      <td>${esc(j.host || '')}</td>
      <td>${esc(j.schedule_summary || '')}</td>
      <td class="text-mono" style="font-size:0.78rem">${esc((j.variables || []).join(', '))}</td>
      <td>${badge('Standalone DAG', 'badge-standalone')}</td>
    </tr>
  `).join('');
}

// ---------------------------------------------------------------------------
// Dependency Analysis
// ---------------------------------------------------------------------------
function renderDependencies(deps) {
  // In-conditions table
  const inTbody = $('#in-conditions-tbody');
  if (inTbody) {
    const rows = deps.jobs_with_in_conditions || [];
    if (!rows.length) {
      inTbody.innerHTML = noDataRow(4, 'No in-conditions found');
    } else {
      inTbody.innerHTML = rows.map(r => `
        <tr>
          <td class="fw-bold text-mono">${esc(r.job_name)}</td>
          <td>${esc(r.folder)}</td>
          <td>${r.condition_count}</td>
          <td style="font-size:0.8rem">${esc((r.conditions || []).join(', '))}</td>
        </tr>
      `).join('');
    }
  }

  // Out-conditions table
  const outTbody = $('#out-conditions-tbody');
  if (outTbody) {
    const rows = deps.jobs_with_out_conditions || [];
    if (!rows.length) {
      outTbody.innerHTML = noDataRow(4, 'No out-conditions found');
    } else {
      outTbody.innerHTML = rows.map(r => `
        <tr>
          <td class="fw-bold text-mono">${esc(r.job_name)}</td>
          <td>${esc(r.folder)}</td>
          <td>${r.condition_count}</td>
          <td style="font-size:0.8rem">${esc((r.conditions || []).join(', '))}</td>
        </tr>
      `).join('');
    }
  }

  // Cross-folder dependencies
  const crossTbody = $('#cross-folder-tbody');
  if (crossTbody) {
    const rows = deps.cross_folder_dependencies || [];
    if (!rows.length) {
      crossTbody.innerHTML = noDataRow(6, 'No cross-folder dependencies found');
    } else {
      crossTbody.innerHTML = rows.map(r => `
        <tr>
          <td class="fw-bold text-mono">${esc(r.source_job)}</td>
          <td>${esc(r.source_folder)}</td>
          <td class="fw-bold text-mono">${esc(r.target_job)}</td>
          <td>${esc(r.target_folder)}</td>
          <td class="text-mono" style="font-size:0.8rem">${esc(r.condition_name)}</td>
          <td>${badge('ExternalTaskSensor', 'badge-migratable')}</td>
        </tr>
      `).join('');
    }
  }

  // Event-driven jobs
  const eventTbody = $('#event-driven-tbody');
  if (eventTbody) {
    const rows = deps.event_driven_jobs || [];
    if (!rows.length) {
      eventTbody.innerHTML = noDataRow(3, 'No event-driven jobs found');
    } else {
      eventTbody.innerHTML = rows.map(r => `
        <tr>
          <td class="fw-bold text-mono">${esc(r.job_name)}</td>
          <td>${esc(r.folder)}</td>
          <td style="font-size:0.8rem">${esc((r.events || []).join(', '))}</td>
        </tr>
      `).join('');
    }
  }
}

// ---------------------------------------------------------------------------
// DAG Suggestions
// ---------------------------------------------------------------------------
function renderDAGSuggestions(dags) {
  const container = $('#dag-cards-container');
  if (!container) return;

  if (!dags.length) {
    container.innerHTML = '<p class="text-muted p-20">No DAG suggestions available.</p>';
    return;
  }

  container.innerHTML = dags.map(dag => {
    const dagTypeCls = dag.dag_type === 'multi_folder' ? 'badge-multi' :
                       dag.dag_type === 'standalone'   ? 'badge-standalone' : 'badge-single';
    const dagTypeLabel = dag.dag_type === 'multi_folder' ? 'Multi-Folder' :
                         dag.dag_type === 'standalone'   ? 'Standalone' : 'Single Folder';

    const crossNote = dag.has_cross_folder_deps
      ? `<div class="dag-meta-row"><span class="dag-meta-label">⚠ Cross-Folder:</span><span>Uses ExternalTaskSensor</span></div>`
      : '';

    const jobPills = (dag.jobs || []).slice(0, 8).map(j =>
      `<span class="dag-job-pill">${esc(j)}</span>`
    ).join('');
    const moreJobs = (dag.jobs || []).length > 8
      ? `<span class="dag-job-pill">+${(dag.jobs || []).length - 8} more</span>`
      : '';

    const codeSnippet = generateDAGCode(dag);

    return `
      <div class="dag-card">
        <div class="dag-card-header">
          <div class="dag-name">${esc(dag.dag_name)}</div>
          <div style="display:flex;gap:6px;align-items:center">
            ${badge(dagTypeLabel, dagTypeCls)}
            ${badge(dag.total_tasks + ' tasks', 'badge-low')}
          </div>
        </div>
        <div class="dag-meta">
          <div class="dag-meta-row">
            <span class="dag-meta-label">Folder:</span>
            <span>${esc(dag.folder || '')}</span>
          </div>
          <div class="dag-meta-row">
            <span class="dag-meta-label">Schedule:</span>
            <span class="text-mono">${esc(dag.schedule || 'Not defined')}</span>
          </div>
          ${crossNote}
          <div class="dag-meta-row">
            <span class="dag-meta-label">Reason:</span>
            <span class="text-muted" style="font-size:0.8rem">${esc(dag.reason || '')}</span>
          </div>
          <div style="margin-top:8px">
            <div class="dag-meta-label" style="margin-bottom:4px">Jobs:</div>
            <div class="dag-jobs-list">${jobPills}${moreJobs}</div>
          </div>
        </div>
        <details>
          <summary style="padding:8px 16px;cursor:pointer;font-size:0.8rem;color:var(--color-primary);background:#f8f9fa;border-top:1px solid var(--color-border)">
            View Airflow DAG skeleton
          </summary>
          <pre class="dag-code">${esc(codeSnippet)}</pre>
        </details>
      </div>
    `;
  }).join('');
}

function generateDAGCode(dag) {
  const dagId = dag.dag_name;
  const schedule = dag.schedule && dag.schedule !== 'Not defined' ? `"${dag.schedule}"` : 'None';
  const tasks = (dag.jobs || []).slice(0, 6);
  const moreTasks = (dag.jobs || []).length > 6 ? `\n    # ... and ${(dag.jobs || []).length - 6} more tasks` : '';

  const taskDefs = tasks.map(j => {
    const taskId = j.replace(/[^a-zA-Z0-9_]/g, '_');
    return `    ${taskId} = BashOperator(
        task_id="${taskId}",
        bash_command="echo 'TODO: implement ${j}'",
    )`;
  }).join('\n\n');

  const crossNote = dag.has_cross_folder_deps
    ? `\n    # NOTE: Add ExternalTaskSensor for cross-folder dependencies` : '';

  return `from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.sensors.external_task import ExternalTaskSensor
from datetime import datetime, timedelta

default_args = {
    "owner": "airflow",
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}

with DAG(
    dag_id="${dagId}",
    default_args=default_args,
    schedule=${schedule},
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=["controlm-migration", "${dag.folder || ''}"],
) as dag:
${crossNote}
${taskDefs}${moreTasks}`;
}

// ---------------------------------------------------------------------------
// Variables Analysis
// ---------------------------------------------------------------------------
function renderVariablesAnalysis(vars) {
  const tbody = $('#variables-tbody');
  if (!tbody) return;

  const mapping = vars.airflow_mapping || {};
  const odateJobs = vars.odate_jobs || [];
  const orderidJobs = vars.orderid_jobs || [];
  const shiftleftJobs = vars.shiftleft_jobs || [];
  const shiftrightJobs = vars.shiftright_jobs || [];
  const manualJobs = vars.manual_schedule_jobs || [];
  const dynVars = vars.variable_frequency || {};

  const rows = [];

  // ODATE
  if (odateJobs.length) {
    rows.push({
      construct: '%%ODATE / ODATE',
      jobs: odateJobs,
      count: odateJobs.length,
      airflow: mapping['%%ODATE / ODATE'] || '{{ ds }}',
      notes: 'Use execution_date or ds template variable',
    });
  }

  // ORDERID
  if (orderidJobs.length) {
    rows.push({
      construct: '%%ORDERID',
      jobs: orderidJobs,
      count: orderidJobs.length,
      airflow: mapping['%%ORDERID'] || 'Custom Airflow Variable',
      notes: 'Implement as XCom or custom Airflow Variable',
    });
  }

  // ShiftLeft
  if (shiftleftJobs.length) {
    rows.push({
      construct: 'ShiftLeft',
      jobs: shiftleftJobs.map(j => j.job || j),
      count: shiftleftJobs.length,
      airflow: 'timedelta(days=-N)',
      notes: 'Adjust schedule start_date or use timedelta',
    });
  }

  // ShiftRight
  if (shiftrightJobs.length) {
    rows.push({
      construct: 'ShiftRight',
      jobs: shiftrightJobs.map(j => j.job || j),
      count: shiftrightJobs.length,
      airflow: 'timedelta(days=+N)',
      notes: 'Adjust schedule start_date or use timedelta',
    });
  }

  // Manual
  if (manualJobs.length) {
    rows.push({
      construct: 'OrderMethod=Manual',
      jobs: manualJobs,
      count: manualJobs.length,
      airflow: 'schedule=None',
      notes: 'Set DAG schedule to None for manual trigger',
    });
  }

  // Dynamic variables
  for (const [name, count] of Object.entries(dynVars)) {
    rows.push({
      construct: `%%${name}`,
      jobs: [],
      count: count,
      airflow: 'Airflow Variable / XCom / Jinja template',
      notes: 'Review and map to appropriate Airflow mechanism',
    });
  }

  if (!rows.length) {
    tbody.innerHTML = noDataRow(5, 'No variables or Control-M constructs found');
    return;
  }

  tbody.innerHTML = rows.map(r => `
    <tr>
      <td class="fw-bold text-mono">${esc(r.construct)}</td>
      <td style="font-size:0.78rem">${esc((r.jobs || []).slice(0, 5).join(', '))
        + ((r.jobs || []).length > 5 ? ` +${r.jobs.length - 5} more` : '')}</td>
      <td class="text-right">${r.count}</td>
      <td class="text-mono" style="font-size:0.8rem">${esc(r.airflow)}</td>
      <td class="text-muted" style="font-size:0.8rem">${esc(r.notes)}</td>
    </tr>
  `).join('');
}

// ---------------------------------------------------------------------------
// Calendar Analysis
// ---------------------------------------------------------------------------
function renderCalendarAnalysis(cals) {
  const tbody = $('#calendar-tbody');
  if (!tbody) return;

  const calNames = cals.calendars_used || [];
  const jobsByCal = cals.jobs_by_calendar || {};

  if (!calNames.length) {
    tbody.innerHTML = noDataRow(4, 'No calendars found');
    return;
  }

  tbody.innerHTML = calNames.map(cal => {
    const jobs = jobsByCal[cal] || [];
    return `
      <tr>
        <td class="fw-bold text-mono">${esc(cal)}</td>
        <td style="font-size:0.8rem">${esc(jobs.slice(0, 5).join(', '))
          + (jobs.length > 5 ? ` +${jobs.length - 5} more` : '')}</td>
        <td class="text-right">${jobs.length}</td>
        <td>${badge('Standard', 'badge-low')}</td>
      </tr>
    `;
  }).join('');
}

// ---------------------------------------------------------------------------
// Event Analysis
// ---------------------------------------------------------------------------
function renderEventAnalysis(events) {
  const tbody = $('#events-tbody');
  if (!tbody) return;

  const sensors = events.external_task_sensors_needed || [];
  const eventsToWait = events.events_to_wait || [];

  if (!sensors.length && !eventsToWait.length) {
    tbody.innerHTML = noDataRow(6, 'No cross-folder events or sensors needed');
    return;
  }

  const rows = [];

  sensors.forEach(s => {
    rows.push({
      source: s.source_job,
      sourceFolder: s.source_folder,
      eventName: s.event_name,
      type: 'Cross-Folder Condition',
      target: s.target_job,
      airflow: 'ExternalTaskSensor',
      cls: 'badge-partial',
    });
  });

  eventsToWait.forEach(e => {
    rows.push({
      source: e.job,
      sourceFolder: e.folder,
      eventName: e.event_name,
      type: 'EventToWaitFor',
      target: '—',
      airflow: 'ExternalTaskSensor / Custom Sensor',
      cls: 'badge-partial',
    });
  });

  tbody.innerHTML = rows.map(r => `
    <tr>
      <td class="fw-bold text-mono">${esc(r.source)}</td>
      <td>${esc(r.sourceFolder)}</td>
      <td class="text-mono">${esc(r.eventName)}</td>
      <td>${badge(r.type, 'badge-review')}</td>
      <td class="text-mono">${esc(r.target)}</td>
      <td>${badge(r.airflow, r.cls)}</td>
    </tr>
  `).join('');
}

// ---------------------------------------------------------------------------
// Hostgroup Analysis
// ---------------------------------------------------------------------------
function renderHostgroupAnalysis(hosts) {
  const tbody = $('#hostgroup-tbody');
  if (!tbody) return;

  const groups = hosts.hostgroups_used || [];
  const jobsByGroup = hosts.jobs_by_hostgroup || {};

  if (!groups.length) {
    tbody.innerHTML = noDataRow(4, 'No hostgroups found');
    return;
  }

  tbody.innerHTML = groups.map(g => {
    const jobs = jobsByGroup[g] || [];
    return `
      <tr>
        <td class="fw-bold text-mono">${esc(g)}</td>
        <td class="text-right">${jobs.length}</td>
        <td style="font-size:0.8rem">${esc(jobs.slice(0, 5).join(', '))
          + (jobs.length > 5 ? ` +${jobs.length - 5} more` : '')}</td>
        <td class="text-muted" style="font-size:0.8rem">Use pool/queue in Airflow</td>
      </tr>
    `;
  }).join('');
}

// ---------------------------------------------------------------------------
// Schedule Analysis
// ---------------------------------------------------------------------------
function renderScheduleAnalysis(schedule) {
  const withTbody = $('#schedule-with-tbody');
  const withoutTbody = $('#schedule-without-tbody');

  const withJobs = schedule.jobs_with_schedule || [];
  const withoutJobs = schedule.jobs_without_schedule || [];

  if (withTbody) {
    if (!withJobs.length) {
      withTbody.innerHTML = noDataRow(4, 'No scheduled jobs found');
    } else {
      withTbody.innerHTML = withJobs.map(j => `
        <tr>
          <td class="fw-bold text-mono">${esc(j.job_name)}</td>
          <td>${esc(j.folder)}</td>
          <td>${esc(j.schedule_details)}</td>
          <td class="text-mono">${esc(j.cron_equivalent || '')}</td>
        </tr>
      `).join('');
    }
  }

  if (withoutTbody) {
    if (!withoutJobs.length) {
      withoutTbody.innerHTML = noDataRow(4, 'All jobs have schedules defined');
    } else {
      withoutTbody.innerHTML = withoutJobs.map(j => `
        <tr>
          <td class="fw-bold text-mono">${esc(j.job_name)}</td>
          <td>${esc(j.folder)}</td>
          <td>${jobTypeBadge(j.type)}</td>
          <td class="text-muted">${esc(j.note || 'Manual trigger or dependency-only')}</td>
        </tr>
      `).join('');
    }
  }
}

// ---------------------------------------------------------------------------
// Dependency Graph (vis-network)
// ---------------------------------------------------------------------------
function renderDependencyGraph(graphData) {
  const container = $('#graph-container');
  if (!container) return;

  const nodes = graphData.nodes || [];
  const edges = graphData.edges || [];

  if (!nodes.length) {
    container.innerHTML = '<p style="color:#aaa;padding:40px;text-align:center;">No graph data available.</p>';
    return;
  }

  // Destroy previous instance
  if (networkGraph) {
    networkGraph.destroy();
    networkGraph = null;
  }

  if (typeof vis === 'undefined') {
    container.innerHTML = '<p style="color:#aaa;padding:40px;text-align:center;">vis-network library not loaded. Check your internet connection.</p>';
    return;
  }

  const visNodes = new vis.DataSet(nodes.map(n => ({
    id: n.id,
    label: n.label.length > 25 ? n.label.substring(0, 23) + '…' : n.label,
    title: `${n.label}\n${n.type}\nStatus: ${n.migration_status}`,
    color: {
      background: n.color || '#6c757d',
      border: '#333',
      highlight: { background: n.color || '#6c757d', border: '#ffeb3b' },
    },
    font: { color: '#fff', size: 11, face: 'Courier New' },
    shape: 'box',
    borderWidth: 2,
    margin: { top: 6, bottom: 6, left: 8, right: 8 },
  })));

  const visEdges = new vis.DataSet(edges.map(e => ({
    id: e.id,
    from: e.from,
    to: e.to,
    label: e.label && e.label.length > 25 ? e.label.substring(0, 23) + '…' : (e.label || ''),
    title: `Parent (${e.from}) → Child (${e.to})\nCondition: ${e.label || 'Unknown'}`,
    arrows: { to: { enabled: true, scaleFactor: 0.5 } },
    color: { 
      color: e.type === 'event' ? '#fd7e14' : (e.type === 'folder_completion' ? '#6c757d' : '#90caf9'),
      highlight: '#ffeb3b'
    },
    dashes: e.type === 'event' || e.type === 'folder_completion',
    font: { size: 9, color: '#666', align: 'horizontal', background: { enabled: true, color: 'rgba(255,255,255,0.8)' } },
    smooth: { type: 'curvedCW', roundness: 0.2 },
    width: 1.5,
  })));

  const options = {
    layout: { 
      improvedLayout: true,
      randomSeed: 42,
    },
    physics: {
      enabled: true,
      solver: 'hierarchicalRepulsion',
      hierarchicalRepulsion: {
        centralGravity: 0.0,
        springLength: 200,
        springConstant: 0.01,
        nodeDistance: 300,
        damping: 0.3,
      },
      maxVelocity: 50,
      stabilization: { 
        iterations: 400,
        fit: true,
        updateInterval: 25,
      },
      timestep: 0.5,
    },
    interaction: {
      hover: true,
      navigationButtons: true,
      keyboard: true,
      zoomView: true,
      dragNodes: true,
      dragView: true,
    },
    nodes: { 
      margin: { top: 8, bottom: 8, left: 10, right: 10 },
      widthConstraint: { maximum: 150 },
    },
    edges: { 
      width: 2,
      arrows: 'to',
      selectionWidth: 3,
    },
  };

  networkGraph = new vis.Network(container, { nodes: visNodes, edges: visEdges }, options);
}

// =========================================================
// New Rendering Functions for Professional Report Format
// =========================================================

// Render Executive Summary Table
function renderExecutiveSummaryTable(data) {
  const migration = data.migration_analysis || {};
  const tbody = document.getElementById('executive-summary-tbody');
  if (!tbody) return;
  
  const summary = data.summary || {};
  const rows = [
    { category: '🚀 Migrate to Airflow', folders: 1, jobs: migration.migratable?.length || 0, status: '✅' },
    { category: '⏰ Shift Left → Cron', folders: 0, jobs: migration.partially_migratable?.length || 0, status: '⚠️' },
    { category: '🗑️ Retire / Decommission', folders: 0, jobs: 0, status: '⏹️' },
    { category: '📦 Demo / Archive', folders: summary.total_folders || 1, jobs: migration.not_migratable?.length || 0, status: '❓' },
  ];
  
  tbody.innerHTML = rows.map(r => `
    <tr>
      <td>${r.category}</td>
      <td class="text-right">${r.folders}</td>
      <td class="text-right fw-bold">${r.jobs}</td>
      <td>${r.status}</td>
    </tr>
  `).join('');
}

// Render Complexity Metrics
function renderComplexityMetrics(data) {
  const summary = data.summary || {};
  const tbody = document.getElementById('complexity-metrics-tbody');
  if (!tbody) return;
  
  const metrics = [
    ['Cyclic (self-rescheduling) jobs', 0],
    ['Standalone jobs (no inbound deps)', summary.standalone_jobs || 0],
    ['Jobs targeting host groups', 0],
    ['Jobs with unresolved CTM dynamic variables', summary.jobs_with_variables || 0],
    ['Resource Pool / Lock references', 0],
    ['Action-based dependency edges (IfStatement)', 0],
    ['Nested sub-folders', 0],
  ];
  
  tbody.innerHTML = metrics.map(m => `
    <tr>
      <td>${m[0]}</td>
      <td class="text-right">${m[1]}</td>
    </tr>
  `).join('');
}

// Render Folder BAU Breakdown
function renderFolderBAUBreakdown(data) {
  const summary = data.summary || {};
  const tbody = document.getElementById('bau-breakdown-tbody');
  if (!tbody) return;
  
  const categories = [
    { label: '✅ BAU (business workload)', count: 0 },
    { label: '🔧 Technical / Ops', count: 0 },
    { label: '⚡ Mixed BAU + Technical', count: 0 },
    { label: '❓ Uncategorised', count: summary.total_folders || 0 },
  ];
  
  tbody.innerHTML = categories.map(c => `
    <tr>
      <td>${c.label}</td>
      <td class="text-right fw-bold">${c.count}</td>
    </tr>
  `).join('');
}

// Render Job Inventory Table
function renderJobInventoryTable(data) {
  const summary = data.summary || {};
  const tbody = document.getElementById('job-inventory-tbody');
  if (!tbody) return;
  
  if (!summary.folders || summary.folders.length === 0) {
    tbody.innerHTML = '<tr class="no-data-row"><td colspan="12">No folders found</td></tr>';
    return;
  }
  
  tbody.innerHTML = summary.folders.map((folder, idx) => `
    <tr>
      <td>${idx + 1}</td>
      <td><strong>${esc(folder.name)}</strong></td>
      <td>${esc(folder.server || '-')}</td>
      <td>${esc(folder.application || '-')}</td>
      <td class="text-right">${folder.job_count || 0}</td>
      <td class="text-right">${folder.cyclic_count || 0}</td>
      <td class="text-right">${folder.critical_count || 0}</td>
      <td class="text-right">${folder.dummy_count || 0}</td>
      <td class="text-right">${folder.external_deps || 0}</td>
      <td>❓ Unknown</td>
      <td>📦 DEMO / ARCHIVE</td>
      <td>P5 — Defer</td>
    </tr>
  `).join('');
}

// Render Detailed Folder Analysis
function renderDetailedFolderAnalysisTable(data) {
  const container = document.getElementById('folder-analysis-container');
  if (!container || !data.summary || !data.summary.folders) return;
  
  container.innerHTML = data.summary.folders.map((folder, idx) => `
    <div style="margin-bottom: 30px; padding: 20px; background: #f8f9fa; border-radius: 8px;">
      <h3 style="margin-bottom: 16px; font-size: 1.1rem; color: #333;">
        ${idx + 1}. <code>${esc(folder.name)}</code>
      </h3>
      <p style="color: #999; margin-bottom: 16px;">📦 DEMO / ARCHIVE</p>
      
      <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 0.9rem;">
        <tbody>
          <tr style="border-bottom: 1px solid #ddd;">
            <td style="padding: 8px; font-weight: bold;">CTM Server</td>
            <td style="padding: 8px;">${esc(folder.server || '-')}</td>
          </tr>
          <tr style="border-bottom: 1px solid #ddd;">
            <td style="padding: 8px; font-weight: bold;">Application</td>
            <td style="padding: 8px;">${esc(folder.application || '-')}</td>
          </tr>
          <tr style="border-bottom: 1px solid #ddd;">
            <td style="padding: 8px; font-weight: bold;"><strong>Total Jobs</strong></td>
            <td style="padding: 8px;"><strong>${folder.job_count || 0}</strong></td>
          </tr>
          <tr style="border-bottom: 1px solid #ddd;">
            <td style="padding: 8px;">Standalone Jobs</td>
            <td style="padding: 8px;">${folder.standalone_count || 0}</td>
          </tr>
          <tr style="border-bottom: 1px solid #ddd;">
            <td style="padding: 8px;">Cyclic Jobs</td>
            <td style="padding: 8px;">${folder.cyclic_count || 0}</td>
          </tr>
          <tr style="border-bottom: 1px solid #ddd;">
            <td style="padding: 8px;">Critical Jobs</td>
            <td style="padding: 8px;">${folder.critical_count || 0}</td>
          </tr>
          <tr style="border-bottom: 1px solid #ddd;">
            <td style="padding: 8px;">Dummy Jobs</td>
            <td style="padding: 8px;">${folder.dummy_count || 0}</td>
          </tr>
          <tr style="border-bottom: 1px solid #ddd;">
            <td style="padding: 8px;">Cross-folder Dependencies</td>
            <td style="padding: 8px;">${folder.external_deps || 0}</td>
          </tr>
          <tr style="border-bottom: 1px solid #ddd;">
            <td style="padding: 8px; font-weight: bold;"><strong>Priority</strong></td>
            <td style="padding: 8px;"><strong>P5 — Defer</strong></td>
          </tr>
          <tr>
            <td style="padding: 8px; font-weight: bold;"><strong>Effort</strong></td>
            <td style="padding: 8px;"><strong>XS (< 1 day)</strong></td>
          </tr>
        </tbody>
      </table>

      <h4 style="margin-top: 20px; margin-bottom: 10px; color: #333;">Job Type Breakdown</h4>
      <table style="width: 100%; border-collapse: collapse; font-size: 0.85rem; margin-bottom: 20px;">
        <thead>
          <tr style="background: #f0f0f0;">
            <th style="padding: 8px; text-align: left; border: 1px solid #ddd;">CTM Type</th>
            <th style="padding: 8px; text-align: right; border: 1px solid #ddd;">Count</th>
            <th style="padding: 8px; text-align: left; border: 1px solid #ddd;">Airflow Operator</th>
          </tr>
        </thead>
        <tbody>
          ${folder.job_types?.map(jt => `
            <tr style="border-bottom: 1px solid #eee;">
              <td style="padding: 8px;"><code>${esc(jt.type)}</code></td>
              <td style="padding: 8px; text-align: right;">${jt.count}</td>
              <td style="padding: 8px;">${esc(jt.airflow_operator || 'TBD')}</td>
            </tr>
          `).join('') || '<tr><td colspan="3" style="padding: 8px; text-align: center;">No data</td></tr>'}
        </tbody>
      </table>
    </div>
  `).join('');
}

// Render Effort Sizing Table
function renderEffortSizingTable(data) {
  const summary = data.summary || {};
  const tbody = document.getElementById('effort-tbody');
  if (!tbody || !summary.folders) return;
  
  tbody.innerHTML = summary.folders.map((folder) => `
    <tr>
      <td>${esc(folder.application || '-')}</td>
      <td>📦 DEMO / ARCHIVE</td>
      <td class="text-right">${folder.job_count || 0}</td>
      <td class="text-right">${folder.external_deps || 0}</td>
      <td>XS</td>
      <td>P5</td>
    </tr>
  `).join('');
}

// ---------------------------------------------------------------------------
// Section counts update
// ---------------------------------------------------------------------------
function updateSectionCounts(data) {
  const counters = {
    '#summary-count': (data.summary || {}).total_jobs || 0,
    '#job-types-count': (data.job_type_analysis || []).length,
    '#migration-count': ((data.migration_analysis || {}).migratable || []).length
      + ((data.migration_analysis || {}).partially_migratable || []).length
      + ((data.migration_analysis || {}).not_migratable || []).length,
    '#standalone-section-count': (data.standalone_jobs || []).length,
    '#dependency-count': ((data.dependency_analysis || {}).dependency_chains || []).length,
    '#dag-count': (data.dag_suggestions || []).length,
    '#variables-count': Object.keys((data.variables_analysis || {}).variable_frequency || {}).length,
    '#calendar-count': (data.calendar_analysis || {}).total_calendars || 0,
    '#event-count': ((data.event_analysis || {}).external_task_sensors_needed || []).length,
    '#hostgroup-count': ((data.hostgroup_analysis || {}).hostgroups_used || []).length,
    '#schedule-count': ((data.schedule_analysis || {}).jobs_with_schedule || []).length,
    '#graph-count': (data.dependency_graph || {}).nodes?.length || 0,
  };

  for (const [sel, val] of Object.entries(counters)) {
    const el = $(sel);
    if (el) el.textContent = val;
  }
}

// ---------------------------------------------------------------------------
// Collapsible sections
// ---------------------------------------------------------------------------
function initCollapsible() {
  $$('.section-header').forEach(header => {
    header.addEventListener('click', () => {
      const body = header.nextElementSibling;
      if (!body) return;
      const isCollapsed = body.classList.contains('collapsed');
      if (isCollapsed) {
        body.classList.remove('collapsed');
        header.classList.remove('collapsed');
      } else {
        body.classList.add('collapsed');
        header.classList.add('collapsed');
      }
    });
  });
}

function toggleSection(sectionId) {
  const body = $('#' + sectionId);
  if (!body) return;
  body.classList.toggle('collapsed');
  const header = body.previousElementSibling;
  if (header) header.classList.toggle('collapsed');
}

// ---------------------------------------------------------------------------
// CSV Download
// ---------------------------------------------------------------------------
async function downloadCSV(type) {
  if (!currentAnalysis) {
    showError('No analysis data available. Please analyze a file first.');
    return;
  }

  try {
    const resp = await fetch('/download-csv', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: type, analysis: currentAnalysis }),
    });

    if (!resp.ok) {
      const err = await resp.json();
      showError(err.error || 'Download failed');
      return;
    }

    const blob = await resp.blob();
    const disposition = resp.headers.get('Content-Disposition') || '';
    const match = disposition.match(/filename=(.+)/);
    const filename = match ? match[1] : `ctm_${type}.csv`;

    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  } catch (err) {
    showError('Download error: ' + err.message);
  }
}

// ---------------------------------------------------------------------------
// Scroll to section
// ---------------------------------------------------------------------------
function scrollToSection(id) {
  const el = document.getElementById(id);
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ---------------------------------------------------------------------------
// Init
// ---------------------------------------------------------------------------
document.addEventListener('DOMContentLoaded', () => {
  initUpload();
  initCollapsible();
});
