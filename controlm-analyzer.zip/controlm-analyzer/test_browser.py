#!/usr/bin/env python3
"""
Simple test to verify Flask and upload functionality
"""
import requests
import json

print("=" * 60)
print("🔍 Testing Flask Server")
print("=" * 60)

# Test 1: Check Flask is responding
print("\n1️⃣ Checking Flask debug endpoint...")
try:
    resp = requests.get('http://localhost:5000/debug', timeout=5)
    print(f"   Status: {resp.status_code}")
    print(f"   Response: {resp.json()}")
except Exception as e:
    print(f"   ❌ Error: {e}")
    exit(1)

# Test 2: Check if homepage loads
print("\n2️⃣ Checking homepage...")
try:
    resp = requests.get('http://localhost:5000/', timeout=5)
    print(f"   Status: {resp.status_code}")
    print(f"   Page length: {len(resp.text)} bytes")
    
    # Check if JavaScript is included
    if 'app.js' in resp.text:
        print("   ✅ app.js script tag found")
    else:
        print("   ❌ app.js script tag NOT found")
    
    # Check if upload-zone element exists
    if 'upload-zone' in resp.text:
        print("   ✅ upload-zone element found")
    else:
        print("   ❌ upload-zone element NOT found")
        
except Exception as e:
    print(f"   ❌ Error: {e}")

# Test 3: Check static files
print("\n3️⃣ Checking static files...")
try:
    resp = requests.get('http://localhost:5000/static/js/app.js', timeout=5)
    print(f"   Status: {resp.status_code}")
    print(f"   app.js size: {len(resp.text)} bytes")
    
    if 'initUpload' in resp.text:
        print("   ✅ initUpload function found in app.js")
    else:
        print("   ❌ initUpload function NOT found")
        
except Exception as e:
    print(f"   ❌ Error: {e}")

print("\n" + "=" * 60)
print("✅ Server is healthy!\n")
print("📋 Next steps:")
print("   1. Open http://localhost:5000 in your browser")
print("   2. Press F12 to open Developer Tools")
print("   3. Look for console messages starting with 📦, 🚀, ✅")
print("   4. Try dragging a JSON file onto the upload zone")
print("   5. Check console for: 🎯 Drag over zone detected")
print("=" * 60)
