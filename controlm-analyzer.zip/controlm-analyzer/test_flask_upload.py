#!/usr/bin/env python3
"""Test Flask upload endpoint"""

import json
import requests

try:
    # Test uploading a file to the Flask server
    with open('C:\\Users\\jagan\\Downloads\\HKOE_2._0.json', 'rb') as f:
        files = {'file': f}
        response = requests.post('http://localhost:5000/analyze', files=files)
    
    # Check response
    print(f'✅ Upload successful!')
    print(f'   - Status code: {response.status_code}')
    
    data = response.json()
    
    if 'error' in data:
        print(f'❌ Error: {data["error"]}')
    else:
        print(f'   - Total jobs: {data.get("summary", {}).get("total_jobs", 0)}')
        print(f'   - Folders: {data.get("summary", {}).get("total_folders", 0)}')
        folders = data.get("summary", {}).get("folders", [])
        if folders:
            print(f'   - First folder: {folders[0].get("name")}')
            print(f'   - Jobs in fold: {folders[0].get("job_count")}')
        
except Exception as e:
    print(f'❌ Error: {e}')
    import traceback
    traceback.print_exc()
