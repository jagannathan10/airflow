#!/usr/bin/env python3
"""Test the upload/analyze flow"""

import json
import sys
from analyzer.ctm_analyzer import ControlMAnalyzer

try:
    with open('C:\\Users\\jagan\\Downloads\\HKOE_2._0.json') as f:
        data = json.load(f)
    
    analyzer = ControlMAnalyzer(data)
    result = analyzer.analyze()
    
    # Check if result has the expected structure
    print('✅ Analyzer works correctly')
    print(f'   - Has summary: {"summary" in result}')
    print(f'   - Has migration_analysis: {"migration_analysis" in result}')
    print(f'   - Total jobs: {result.get("summary", {}).get("total_jobs", 0)}')
    print(f'   - Has dependency_graph: {"dependency_graph" in result}')
    
    # Check folders
    folders = result.get("summary", {}).get("folders", [])
    print(f'\n✅ Sample folder data:')
    if folders:
        f = folders[0]
        print(f'   - Folder name: {f.get("name")}')
        print(f'   - Job count: {f.get("job_count")}')
        print(f'   - Server: {f.get("server")}')
    
except Exception as e:
    print(f'❌ Error: {e}')
    import traceback
    traceback.print_exc()
    sys.exit(1)
