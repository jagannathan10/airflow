#!/usr/bin/env python
"""Test the Control-M analyzer with sample JSON files."""

import json
import sys
sys.path.insert(0, '.')

from analyzer.ctm_analyzer import ControlMAnalyzer

# Load sample JSON
print("Loading HKOE_2._0.json...")
with open('C:\\Users\\jagan\\Downloads\\HKOE_2._0.json', 'r') as f:
    data = json.load(f)

# Analyze
print("Analyzing...")
analyzer = ControlMAnalyzer(data)
result = analyzer.analyze()

# Print summary stats
summary = result.get('summary', {})
job_types = result.get('job_type_analysis', [])
dep_analysis = result.get('dependency_analysis', {})
graph = result.get('dependency_graph', {})

print("\n=== SUMMARY ===")
print(f"Total jobs: {summary.get('total_jobs', 0)}")
print(f"Total folders: {summary.get('total_folders', 0)}")
print(f"Migratable: {summary.get('migratable', 0)}")
print(f"Partially Migratable: {summary.get('partially_migratable', 0)}")
print(f"Not Migratable: {summary.get('not_migratable', 0)}")
print(f"Standalone jobs: {summary.get('standalone_jobs', 0)}")

print("\n=== JOB TYPES (Top 5) ===")
for jt in job_types[:5]:
    print(f"{jt['job_type']}: {jt['count']} jobs ({jt['percentage']}%)")
    if jt.get('schedules'):
        print(f"  Schedules: {jt['schedules'][:2]}")

print("\n=== DEPENDENCIES ===")
print(f"Jobs with in-conditions: {len(dep_analysis.get('jobs_with_in_conditions', []))}")
print(f"Jobs with out-conditions: {len(dep_analysis.get('jobs_with_out_conditions', []))}")
print(f"Cross-folder dependencies: {len(dep_analysis.get('cross_folder_dependencies', []))}")
print(f"Dependency chains: {len(dep_analysis.get('dependency_chains', []))}")

print("\n=== GRAPH ===")
print(f"Nodes: {len(graph.get('nodes', []))}")
print(f"Edges: {len(graph.get('edges', []))}")

if graph.get('edges'):
    print(f"\nFirst edge: {graph['edges'][0]}")

print("\n=== SAMPLE JOB ===")
if analyzer.jobs:
    job = analyzer.jobs[0]
    print(f"Job: {job['name']}")
    print(f"Type: {job['type']}")
    print(f"Folder: {job['folder']}")
    print(f"Schedule: {job['schedule_summary']}")
    print(f"From Time: {job.get('from_time', 'N/A')}")
    print(f"To Time: {job.get('to_time', 'N/A')}")
    print(f"Rerun Max: {job.get('rerun_max', 'N/A')}")
    print(f"Rerun Every: {job.get('rerun_every', 'N/A')}")

print("\n=== TEST COMPLETE ===")
