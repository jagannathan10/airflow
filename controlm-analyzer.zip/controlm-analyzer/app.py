"""
Control-M to Airflow Migration Analyzer - Flask Application
"""

import csv
import io
import json
import traceback

from flask import Flask, jsonify, render_template, request, Response

from analyzer import ControlMAnalyzer

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024  # 50 MB


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/debug")
def debug():
    """Debug endpoint to check if Flask is serving files."""
    return jsonify({
        "status": "Flask server is running",
        "static_folder": app.static_folder,
        "template_folder": app.template_folder
    })


@app.route("/analyze", methods=["POST"])
def analyze():
    """Accept a Control-M JSON file upload and return analysis as JSON."""
    try:
        if "file" not in request.files:
            return jsonify({"error": "No file provided"}), 400

        uploaded_file = request.files["file"]
        if uploaded_file.filename == "":
            return jsonify({"error": "No file selected"}), 400

        if not uploaded_file.filename.lower().endswith(".json"):
            return jsonify({"error": "Only JSON files are supported"}), 400

        raw_bytes = uploaded_file.read()
        try:
            data = json.loads(raw_bytes.decode("utf-8-sig"))  # handles BOM
        except json.JSONDecodeError as exc:
            return jsonify({"error": f"Invalid JSON: {exc}"}), 400

        analyzer = ControlMAnalyzer(data)
        result = analyzer.analyze()
        return jsonify(result)

    except Exception as exc:
        traceback.print_exc()
        return jsonify({"error": f"Analysis failed: {str(exc)}"}), 500


@app.route("/download-csv", methods=["POST"])
def download_csv():
    """Generate and return a CSV file from the analysis data."""
    try:
        payload = request.get_json(silent=True)
        if not payload:
            return jsonify({"error": "No data provided"}), 400

        csv_type = payload.get("type", "all_jobs")
        analysis = payload.get("analysis", {})

        output = io.StringIO()
        writer = csv.writer(output)

        if csv_type == "all_jobs":
            _write_all_jobs_csv(writer, analysis)
            filename = "all_jobs.csv"
        elif csv_type == "migratable":
            _write_migration_csv(writer, analysis, "migratable")
            filename = "migratable_jobs.csv"
        elif csv_type == "standalone":
            _write_standalone_csv(writer, analysis)
            filename = "standalone_jobs.csv"
        elif csv_type == "dependencies":
            _write_dependencies_csv(writer, analysis)
            filename = "dependencies.csv"
        elif csv_type == "dag_suggestions":
            _write_dag_suggestions_csv(writer, analysis)
            filename = "dag_suggestions.csv"
        elif csv_type == "full_report":
            _write_full_report_csv(writer, analysis)
            filename = "full_report.csv"
        else:
            _write_all_jobs_csv(writer, analysis)
            filename = "export.csv"

        csv_content = output.getvalue()
        return Response(
            csv_content,
            mimetype="text/csv",
            headers={"Content-Disposition": f"attachment; filename={filename}"},
        )

    except Exception as exc:
        traceback.print_exc()
        return jsonify({"error": f"CSV generation failed: {str(exc)}"}), 500


# ---------------------------------------------------------------------------
# CSV helpers
# ---------------------------------------------------------------------------

def _write_all_jobs_csv(writer, analysis: dict):
    migration = analysis.get("migration_analysis", {})
    writer.writerow([
        "Job Name", "Folder", "Type", "Migration Status", "Airflow Equivalent",
        "Effort", "Host", "Run As", "Schedule", "Notes",
    ])
    for status_key in ("migratable", "partially_migratable", "not_migratable"):
        for job in migration.get(status_key, []):
            writer.writerow([
                job.get("job_name", ""),
                job.get("folder", ""),
                job.get("type", ""),
                status_key.replace("_", " ").title(),
                job.get("airflow_equivalent", ""),
                job.get("effort", ""),
                job.get("host", ""),
                job.get("run_as", ""),
                job.get("schedule_summary", ""),
                job.get("notes", ""),
            ])


def _write_migration_csv(writer, analysis: dict, status_key: str):
    migration = analysis.get("migration_analysis", {})
    writer.writerow([
        "Job Name", "Folder", "Type", "Airflow Equivalent", "Effort",
        "Host", "Run As", "Schedule", "Notes",
    ])
    for job in migration.get(status_key, []):
        writer.writerow([
            job.get("job_name", ""),
            job.get("folder", ""),
            job.get("type", ""),
            job.get("airflow_equivalent", ""),
            job.get("effort", ""),
            job.get("host", ""),
            job.get("run_as", ""),
            job.get("schedule_summary", ""),
            job.get("notes", ""),
        ])


def _write_standalone_csv(writer, analysis: dict):
    writer.writerow([
        "Job Name", "Folder", "Type", "Host", "Schedule Summary",
        "Variables", "Recommendation",
    ])
    for job in analysis.get("standalone_jobs", []):
        writer.writerow([
            job.get("name", ""),
            job.get("folder", ""),
            job.get("type", ""),
            job.get("host", ""),
            job.get("schedule_summary", ""),
            ", ".join(job.get("variables", [])),
            job.get("airflow_recommendation", ""),
        ])


def _write_dependencies_csv(writer, analysis: dict):
    deps = analysis.get("dependency_analysis", {})
    writer.writerow([
        "Source Job", "Source Folder", "Target Job", "Target Folder",
        "Condition Name", "Airflow Construct",
    ])
    for dep in deps.get("cross_folder_dependencies", []):
        writer.writerow([
            dep.get("source_job", ""),
            dep.get("source_folder", ""),
            dep.get("target_job", ""),
            dep.get("target_folder", ""),
            dep.get("condition_name", ""),
            dep.get("airflow_construct", "ExternalTaskSensor"),
        ])
    writer.writerow([])
    writer.writerow(["# Dependency Chains"])
    writer.writerow(["Parent Job", "Child Job", "Via Condition"])
    for chain in deps.get("dependency_chains", []):
        writer.writerow([
            chain.get("parent", ""),
            chain.get("child", ""),
            chain.get("via", ""),
        ])


def _write_dag_suggestions_csv(writer, analysis: dict):
    writer.writerow([
        "DAG Name", "Folder", "DAG Type", "Total Tasks",
        "Has Cross-Folder Deps", "Schedule", "Jobs", "Reason",
    ])
    for dag in analysis.get("dag_suggestions", []):
        writer.writerow([
            dag.get("dag_name", ""),
            dag.get("folder", ""),
            dag.get("dag_type", ""),
            dag.get("total_tasks", 0),
            dag.get("has_cross_folder_deps", False),
            dag.get("schedule", ""),
            " | ".join(dag.get("jobs", [])),
            dag.get("reason", ""),
        ])


def _write_full_report_csv(writer, analysis: dict):
    summary = analysis.get("summary", {})
    writer.writerow(["=== SUMMARY ==="])
    for k, v in summary.items():
        writer.writerow([k.replace("_", " ").title(), v])
    writer.writerow([])

    writer.writerow(["=== JOB TYPE ANALYSIS ==="])
    writer.writerow([
        "Job Type", "Count", "%", "Airflow Equivalent", "Migration Status", "Effort",
    ])
    for jt in analysis.get("job_type_analysis", []):
        writer.writerow([
            jt.get("job_type", ""),
            jt.get("count", 0),
            jt.get("percentage", 0),
            jt.get("airflow_equivalent", ""),
            jt.get("migration_status", ""),
            jt.get("effort", ""),
        ])
    writer.writerow([])
    _write_all_jobs_csv(writer, analysis)


# ---------------------------------------------------------------------------
# Error handlers
# ---------------------------------------------------------------------------

@app.errorhandler(413)
def file_too_large(exc):
    return jsonify({"error": "File too large. Maximum size is 50 MB."}), 413


@app.errorhandler(404)
def not_found(exc):
    return jsonify({"error": "Endpoint not found"}), 404


@app.errorhandler(500)
def server_error(exc):
    return jsonify({"error": "Internal server error"}), 500


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
