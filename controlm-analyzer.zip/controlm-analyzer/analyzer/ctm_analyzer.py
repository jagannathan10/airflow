"""
Control-M to Airflow Migration Analyzer
Comprehensive analysis of Control-M JSON export files
"""

import re
from collections import defaultdict


# Job type mapping: Control-M type -> (airflow_equivalent, migration_status, effort, notes)
JOB_TYPE_MAPPING = {
    "Job:Script": {
        "airflow_equivalent": "BashOperator",
        "migration_status": "Migratable",
        "effort": "Low",
        "control_m_construct": "Script execution via agent",
        "airflow_equivalent_detail": "BashOperator with bash_command parameter",
        "notes": "Script path/content needs to be accessible from Airflow worker"
    },
    "Job:Command": {
        "airflow_equivalent": "BashOperator",
        "migration_status": "Migratable",
        "effort": "Low",
        "control_m_construct": "OS command execution",
        "airflow_equivalent_detail": "BashOperator with bash_command parameter",
        "notes": "Command must be available on Airflow worker node"
    },
    "Job:EmbeddedScript": {
        "airflow_equivalent": "PythonOperator/BashOperator",
        "migration_status": "Migratable",
        "effort": "Medium",
        "control_m_construct": "Inline script in job definition",
        "airflow_equivalent_detail": "PythonOperator or BashOperator with inline script",
        "notes": "Script logic needs to be extracted and converted to Python or stored as file"
    },
    "Job:FileWatcher": {
        "airflow_equivalent": "FileSensor/S3KeySensor",
        "migration_status": "Migratable",
        "effort": "Low",
        "control_m_construct": "File arrival trigger",
        "airflow_equivalent_detail": "FileSensor for local files, S3KeySensor for S3",
        "notes": "Configure poke_interval and timeout appropriately"
    },
    "Job:FileWatcher:Create": {
        "airflow_equivalent": "FileSensor",
        "migration_status": "Migratable",
        "effort": "Low",
        "control_m_construct": "Wait for file creation",
        "airflow_equivalent_detail": "FileSensor with mode='poke' or 'reschedule'",
        "notes": "Monitor file path for creation; configure timeout and poke_interval"
    },
    "Job:FileWatcher:Modify": {
        "airflow_equivalent": "FileSensor",
        "migration_status": "Migratable",
        "effort": "Low",
        "control_m_construct": "Wait for file modification",
        "airflow_equivalent_detail": "FileSensor with custom logic or polling",
        "notes": "May require custom sensor for modification detection"
    },
    "Job:Dummy": {
        "airflow_equivalent": "EmptyOperator",
        "migration_status": "Migratable",
        "effort": "Low",
        "control_m_construct": "Placeholder/checkpoint job",
        "airflow_equivalent_detail": "EmptyOperator (formerly DummyOperator)",
        "notes": "Direct 1:1 replacement available"
    },
    "Job:SLAManagement": {
        "airflow_equivalent": "SLA callbacks",
        "migration_status": "Partially Migratable",
        "effort": "High",
        "control_m_construct": "SLA monitoring and alerting",
        "airflow_equivalent_detail": "sla_miss_callback on DAG/task level",
        "notes": "Airflow SLA is time-based from DAG start; requires redesign of SLA logic"
    },
    "Job:Database": {
        "airflow_equivalent": "SQLOperator/PostgresOperator/OracleOperator",
        "migration_status": "Migratable",
        "effort": "Medium",
        "control_m_construct": "Database query/procedure execution",
        "airflow_equivalent_detail": "Use provider-specific operators (PostgresOperator, MsSqlOperator, OracleOperator)",
        "notes": "Database connection strings need to be configured as Airflow Connections"
    },
    "Job:Hadoop": {
        "airflow_equivalent": "HiveOperator/SparkSubmitOperator",
        "migration_status": "Migratable",
        "effort": "Medium",
        "control_m_construct": "Hadoop job submission",
        "airflow_equivalent_detail": "SparkSubmitOperator, HiveOperator, or HadoopOperator",
        "notes": "Requires apache-airflow-providers-apache-spark/hive package"
    },
    "Job:AWS S3": {
        "airflow_equivalent": "S3Operator",
        "migration_status": "Migratable",
        "effort": "Low",
        "control_m_construct": "AWS S3 file operations",
        "airflow_equivalent_detail": "S3FileTransformOperator, S3CopyObjectOperator, S3DeleteObjectsOperator",
        "notes": "Requires apache-airflow-providers-amazon package; configure AWS connection"
    },
    "Job:AWS EMR": {
        "airflow_equivalent": "EmrOperator",
        "migration_status": "Migratable",
        "effort": "Medium",
        "control_m_construct": "AWS EMR cluster/step management",
        "airflow_equivalent_detail": "EmrCreateJobFlowOperator, EmrAddStepsOperator, EmrTerminateJobFlowOperator",
        "notes": "Requires apache-airflow-providers-amazon; map EMR job configuration to Airflow format"
    },
    "Job:AWS Glue": {
        "airflow_equivalent": "GlueJobOperator",
        "migration_status": "Migratable",
        "effort": "Medium",
        "control_m_construct": "AWS Glue ETL job",
        "airflow_equivalent_detail": "GlueJobOperator from apache-airflow-providers-amazon",
        "notes": "Glue job name and script location must match; configure AWS credentials"
    },
    "Job:Azure": {
        "airflow_equivalent": "AzureOperators",
        "migration_status": "Migratable",
        "effort": "Medium",
        "control_m_construct": "Azure cloud operations",
        "airflow_equivalent_detail": "AzureDataFactoryRunPipelineOperator, AzureBlobStorageToGCSOperator, etc.",
        "notes": "Requires apache-airflow-providers-microsoft-azure; configure Azure connection"
    },
    "Job:Remote Execution": {
        "airflow_equivalent": "SSHOperator",
        "migration_status": "Migratable",
        "effort": "Medium",
        "control_m_construct": "Remote host command execution",
        "airflow_equivalent_detail": "SSHOperator from apache-airflow-providers-ssh",
        "notes": "Configure SSH connection in Airflow; ensure network connectivity from workers"
    },
    "Job:SOAP": {
        "airflow_equivalent": "SimpleHttpOperator",
        "migration_status": "Partially Migratable",
        "effort": "High",
        "control_m_construct": "SOAP web service call",
        "airflow_equivalent_detail": "SimpleHttpOperator with SOAP envelope in data parameter",
        "notes": "SOAP XML envelope must be manually constructed; consider Python zeep library via PythonOperator"
    },
    "Job:REST": {
        "airflow_equivalent": "SimpleHttpOperator",
        "migration_status": "Migratable",
        "effort": "Medium",
        "control_m_construct": "REST API call",
        "airflow_equivalent_detail": "SimpleHttpOperator from apache-airflow-providers-http",
        "notes": "Configure HTTP connection in Airflow; handle authentication separately"
    },
    "Job:MFT": {
        "airflow_equivalent": "Custom/SFTPOperator",
        "migration_status": "Partially Migratable",
        "effort": "High",
        "control_m_construct": "Managed File Transfer",
        "airflow_equivalent_detail": "SFTPOperator or custom operator for MFT protocols",
        "notes": "MFT-specific features (tracking, auditing) need custom implementation; requires apache-airflow-providers-sftp"
    },
    "Job:Informatica": {
        "airflow_equivalent": "Custom operator",
        "migration_status": "Partially Migratable",
        "effort": "High",
        "control_m_construct": "Informatica PowerCenter/IDMC workflow",
        "airflow_equivalent_detail": "Custom PythonOperator using Informatica REST API",
        "notes": "Use Informatica REST API to trigger workflows; custom operator development required"
    },
    "Job:SAP": {
        "airflow_equivalent": "Custom operator",
        "migration_status": "Partially Migratable",
        "effort": "High",
        "control_m_construct": "SAP job execution",
        "airflow_equivalent_detail": "Custom PythonOperator using pyrfc or SAP REST API",
        "notes": "SAP connectivity requires RFC library; complex job chains may need redesign"
    },
    "Job:BIM": {
        "airflow_equivalent": "No direct equivalent",
        "migration_status": "Not Migratable",
        "effort": "High",
        "control_m_construct": "Business Intelligence Migration",
        "airflow_equivalent_detail": "N/A - No direct Airflow equivalent",
        "notes": "Control-M BIM is platform-specific; requires custom solution or alternative tool"
    },
    "Job:Agent Utilities": {
        "airflow_equivalent": "No direct equivalent",
        "migration_status": "Not Migratable",
        "effort": "High",
        "control_m_construct": "Control-M agent utility operations",
        "airflow_equivalent_detail": "N/A - Platform-specific utility",
        "notes": "Agent utilities are Control-M infrastructure specific; evaluate if functionality is still needed"
    },
}

DEFAULT_JOB_TYPE = {
    "airflow_equivalent": "Review Required",
    "migration_status": "Review Required",
    "effort": "High",
    "control_m_construct": "Unknown job type",
    "airflow_equivalent_detail": "Manual review and custom implementation needed",
    "notes": "Unknown or uncommon job type; manual assessment required"
}


class ControlMAnalyzer:
    """Analyze Control-M JSON exports and generate Airflow migration analysis."""

    def __init__(self, data: dict):
        self.raw_data = data
        self.jobs = []          # list of job dicts with metadata
        self.folders = {}       # folder_name -> list of job names
        self.job_map = {}       # job_name -> job dict (for cross-reference)
        self._parse_data()

    # -------------------------------------------------------------------------
    # Parsing
    # -------------------------------------------------------------------------

    def _parse_data(self):
        """Parse Control-M JSON – handles nested folder format and array format."""
        try:
            data = self.raw_data

            # Some exports wrap everything under a top-level key
            if isinstance(data, list):
                for item in data:
                    if isinstance(item, dict):
                        self._parse_object(item)
                return

            # Dict format – iterate top-level keys
            for key, value in data.items():
                if key.startswith("_") or key in ("Version", "version"):
                    continue
                if isinstance(value, dict):
                    obj_type = value.get("Type", "")
                    if obj_type.startswith("Job:"):
                        # Top-level job (no folder wrapper)
                        self._add_job(key, value, folder="(No Folder)")
                    elif obj_type in ("SimpleFolder", "Folder", "") or "Type" not in value:
                        # Treat as folder
                        self._parse_folder(key, value)
                    else:
                        self._parse_object(value)
        except Exception as exc:
            # Swallow top-level parse errors; analysis will return empty results
            pass

    def _parse_object(self, obj: dict):
        """Recursively parse an arbitrary dict object."""
        if not isinstance(obj, dict):
            return
        obj_type = obj.get("Type", "")
        if obj_type.startswith("Job:"):
            job_name = obj.get("Name", obj.get("JobName", "Unknown"))
            folder = obj.get("Folder", obj.get("FolderName", "(No Folder)"))
            self._add_job(job_name, obj, folder=folder)
        elif obj_type in ("SimpleFolder", "Folder"):
            folder_name = obj.get("Name", obj.get("FolderName", "Unknown"))
            self._parse_folder(folder_name, obj)
        else:
            for v in obj.values():
                if isinstance(v, dict):
                    self._parse_object(v)
                elif isinstance(v, list):
                    for item in v:
                        if isinstance(item, dict):
                            self._parse_object(item)

    def _parse_folder(self, folder_name: str, folder_obj: dict):
        """Extract all jobs from a folder object."""
        if folder_name not in self.folders:
            self.folders[folder_name] = []

        # Handle "Jobs" key containing array of job objects (Control-M export format)
        if "Jobs" in folder_obj and isinstance(folder_obj["Jobs"], list):
            for idx, job_obj in enumerate(folder_obj["Jobs"]):
                if isinstance(job_obj, dict) and job_obj:  # Skip empty objects
                    job_name = job_obj.get("Name", job_obj.get("JobName", f"Job_{idx}"))
                    obj_type = job_obj.get("Type", "")
                    # Even if Type is missing initially, try to add it as a job
                    if obj_type.startswith("Job:") or obj_type == "" or not obj_type:
                        self._add_job(job_name, job_obj, folder=folder_name)

        # Handle legacy nested format (job objects as folder properties)
        for key, value in folder_obj.items():
            if key == "Jobs" or not isinstance(value, dict):
                continue
            obj_type = value.get("Type", "")
            if obj_type.startswith("Job:"):
                self._add_job(key, value, folder=folder_name)
            elif obj_type in ("SimpleFolder", "Folder"):
                # Sub-folder
                self._parse_folder(key, value)

    def _add_job(self, job_name: str, job_obj: dict, folder: str):
        """Add a normalised job record."""
        try:
            # Parse conditions from both old and new formats
            in_conditions = self._parse_conditions(job_obj.get("InConditions", []))
            out_conditions = self._parse_conditions(job_obj.get("OutConditions", []))
            
            # Parse events from Control-M format
            event_to_wait_for = self._parse_events(job_obj.get("EventToWaitFor", []))
            event_to_add = self._parse_events(job_obj.get("EventToAdd", []))
            
            # Also check for Control-M's "eventsToWaitFor" and "eventsToAdd" keys
            if "eventsToWaitFor" in job_obj and not event_to_wait_for:
                event_to_wait_for = self._parse_events(job_obj.get("eventsToWaitFor", []))
            if "eventsToAdd" in job_obj and not event_to_add:
                event_to_add = self._parse_events(job_obj.get("eventsToAdd", []))
            
            # Parse folder completion status (Control-M dependency indicator)
            folder_completion_deps = []
            for key in job_obj.keys():
                if key.startswith("IfBase:Folder:CompletionStatus"):
                    folder_completion_deps.append({
                        "Name": key,
                        "Type": "FolderCompletion"
                    })
                    in_conditions.append({
                        "Name": key,
                        "Date": "ODAT",
                        "AND_OR": "AND",
                        "Sign": "+"
                    })
            
            # Extract When object for schedule timing
            when_obj = job_obj.get("When", {})
            from_time = when_obj.get("FromTime", "")
            to_time = when_obj.get("ToTime", "")
            
            # Extract RerunLimit for retry information
            rerun_limit = job_obj.get("RerunLimit", {})
            rerun_max = rerun_limit.get("Max", "") if isinstance(rerun_limit, dict) else ""
            rerun_every = rerun_limit.get("Every", "") if isinstance(rerun_limit, dict) else ""
            rerun_units = rerun_limit.get("Every", {}).get("Units", "") if isinstance(rerun_limit.get("Every"), dict) else ""
            
            job = {
                "name": job_name,
                "folder": folder,
                "type": job_obj.get("Type", "Unknown"),
                "host": job_obj.get("Host", job_obj.get("NodeId", "")),
                "run_as": job_obj.get("RunAs", job_obj.get("Owner", "")),
                "description": job_obj.get("Description", ""),
                "path_to_script": job_obj.get("PathToScript", job_obj.get("ScriptName", job_obj.get("FileName", ""))),
                "command": job_obj.get("Command", ""),
                "arguments": job_obj.get("Arguments", ""),
                # Schedule - check both top-level and "When" nested format
                "days": job_obj.get("Days") or when_obj.get("DaysRelation", ""),
                "week_days": job_obj.get("WeekDays") or (when_obj.get("WeekDays") or ""),
                "months": job_obj.get("Months") or (when_obj.get("MonthDays") or ""),
                "times": job_obj.get("Times") or from_time,
                "from_time": from_time,
                "to_time": to_time,
                "shift_left": job_obj.get("ShiftLeft", ""),
                "shift_right": job_obj.get("ShiftRight", ""),
                "order_method": job_obj.get("OrderMethod", ""),
                # Retry/Rerun information
                "rerun_max": rerun_max,
                "rerun_every": rerun_every,
                "rerun_units": rerun_units,
                # Conditions / Events
                "in_conditions": in_conditions,
                "out_conditions": out_conditions,
                "event_to_wait_for": event_to_wait_for,
                "event_to_add": event_to_add,
                # Variables
                "variables": self._parse_variables(job_obj.get("Variables", [])),
                # Calendars
                "calendars": self._parse_calendars(job_obj.get("Calendars", {})),
                # Actions
                "actions": job_obj.get("Actions", []),
                # Raw
                "_raw": job_obj,
            }
            job["schedule_summary"] = self._build_schedule_summary(job)
            self.jobs.append(job)
            self.job_map[job_name] = job
            if folder not in self.folders:
                self.folders[folder] = []
            if job_name not in self.folders[folder]:
                self.folders[folder].append(job_name)
        except Exception:
            pass

    # -------------------------------------------------------------------------
    # Sub-parsers
    # -------------------------------------------------------------------------

    def _parse_conditions(self, raw) -> list:
        result = []
        if not raw:
            return result
        if isinstance(raw, list):
            for item in raw:
                if isinstance(item, dict):
                    result.append({
                        "Name": item.get("Name", item.get("name", "")),
                        "Date": item.get("Date", item.get("date", "ODAT")),
                        "AND_OR": item.get("AND_OR", item.get("and_or", "AND")),
                        "Sign": item.get("Sign", item.get("sign", "+")),
                    })
                elif isinstance(item, str):
                    result.append({"Name": item, "Date": "ODAT", "AND_OR": "AND", "Sign": "+"})
        elif isinstance(raw, dict):
            for name, details in raw.items():
                if isinstance(details, dict):
                    result.append({
                        "Name": name,
                        "Date": details.get("Date", "ODAT"),
                        "AND_OR": details.get("AND_OR", "AND"),
                        "Sign": details.get("Sign", "+"),
                    })
        return result

    def _parse_events(self, raw) -> list:
        result = []
        if not raw:
            return result
        if isinstance(raw, list):
            for item in raw:
                if isinstance(item, dict):
                    result.append({
                        "Name": item.get("Name", item.get("Event", item.get("name", ""))),
                        "Date": item.get("Date", "ODAT"),
                        "Type": item.get("Type", ""),
                    })
                elif isinstance(item, str):
                    result.append({"Name": item, "Date": "ODAT", "Type": ""})
        elif isinstance(raw, dict):
            result.append({
                "Name": raw.get("Name", raw.get("Event", "")),
                "Date": raw.get("Date", "ODAT"),
                "Type": raw.get("Type", ""),
            })
        return result

    def _parse_variables(self, raw) -> list:
        result = []
        if not raw:
            return result
        if isinstance(raw, list):
            for item in raw:
                if isinstance(item, dict):
                    result.append({
                        "Name": item.get("Name", item.get("name", "")),
                        "Value": item.get("Value", item.get("value", "")),
                    })
        elif isinstance(raw, dict):
            for k, v in raw.items():
                result.append({"Name": k, "Value": str(v)})
        return result

    def _parse_calendars(self, raw) -> dict:
        if not raw:
            return {}
        if isinstance(raw, dict):
            return {
                "ExceptionPolicy": raw.get("ExceptionPolicy", ""),
                "CalendarNames": raw.get("CalendarNames", []),
            }
        return {}

    # -------------------------------------------------------------------------
    # Schedule summary
    # -------------------------------------------------------------------------

    def _build_schedule_summary(self, job: dict) -> str:
        parts = []
        days = job.get("days", "")
        week_days = job.get("week_days", "")
        months = job.get("months", "")
        times = job.get("times", [])
        from_time = job.get("from_time", "")
        to_time = job.get("to_time", "")
        shift_left = job.get("shift_left", "")
        shift_right = job.get("shift_right", "")
        order_method = job.get("order_method", "")
        rerun_max = job.get("rerun_max", "")
        rerun_every = job.get("rerun_every", "")

        if order_method and order_method.lower() == "manual":
            return "Manual trigger"

        if days:
            if str(days).lower() in ("all", "*", "everyday"):
                parts.append("Daily")
            elif str(days).lower() == "or":
                parts.append("Days: Rule-based (OR)")
            else:
                parts.append(f"Days: {days}")

        if week_days:
            wd_map = {
                "1": "Mon", "2": "Tue", "3": "Wed", "4": "Thu",
                "5": "Fri", "6": "Sat", "7": "Sun",
                "MON": "Mon", "TUE": "Tue", "WED": "Wed", "THU": "Thu",
                "FRI": "Fri", "SAT": "Sat", "SUN": "Sun",
            }
            week_days_str = str(week_days) if not isinstance(week_days, list) else ", ".join(str(d) for d in week_days)
            if week_days_str.upper() in ("ALL", "*", "['ALL']"):
                parts.append("Every weekday")
            elif week_days_str.upper() in ("WEEKDAYS", "1-5", "MON-FRI"):
                parts.append("Mon-Fri")
            else:
                parts.append(f"Weekdays: {week_days_str}")

        if months:
            months_str = str(months) if not isinstance(months, list) else ", ".join(str(m) for m in months)
            if months_str.upper() in ("ALL", "*", "['NONE']", "NONE"):
                pass  # don't add noise
            else:
                parts.append(f"Months: {months_str}")

        # Add time window information
        if from_time and to_time:
            parts.append(f"Time window: {from_time}-{to_time}")
        elif from_time:
            parts.append(f"Time: {from_time}")
        elif times:
            if isinstance(times, list):
                time_strs = []
                for t in times:
                    if isinstance(t, dict):
                        time_strs.append(t.get("From", t.get("Time", str(t))))
                    else:
                        time_strs.append(str(t))
                parts.append("at " + ", ".join(time_strs))
            else:
                parts.append(f"at {times}")

        # Add retry information
        if rerun_max or rerun_every:
            if rerun_max and rerun_every:
                parts.append(f"Retries: max={rerun_max}, every={rerun_every}")
            elif rerun_max:
                parts.append(f"Retries: max={rerun_max}")
            elif rerun_every:
                parts.append(f"Retries: every={rerun_every}")

        if shift_left:
            parts.append(f"ShiftLeft {shift_left}d")
        if shift_right:
            parts.append(f"ShiftRight {shift_right}d")

        return ", ".join(parts) if parts else "Not defined"

    # -------------------------------------------------------------------------
    # Helper lookups
    # -------------------------------------------------------------------------

    def _get_type_info(self, job_type: str) -> dict:
        return JOB_TYPE_MAPPING.get(job_type, DEFAULT_JOB_TYPE)

    def _is_hostgroup(self, host: str) -> bool:
        if not host:
            return False
        if "*" in host:
            return True
        # All-uppercase, no dots/numbers – looks like a logical group name
        if host.isupper() and "." not in host and not any(c.isdigit() for c in host):
            return True
        # Contains common group indicators
        if re.search(r"(group|pool|cluster|farm|grid)", host, re.IGNORECASE):
            return True
        return False

    def _detect_odate(self, job: dict) -> bool:
        targets = [
            job.get("command", ""),
            job.get("path_to_script", ""),
            job.get("arguments", ""),
        ]
        for var in job.get("variables", []):
            targets.append(var.get("Name", ""))
            targets.append(var.get("Value", ""))
        for t in targets:
            if "ODATE" in str(t).upper():
                return True
        return False

    def _detect_orderid(self, job: dict) -> bool:
        targets = [job.get("command", ""), job.get("arguments", "")]
        for var in job.get("variables", []):
            targets.append(var.get("Name", ""))
            targets.append(var.get("Value", ""))
        for t in targets:
            if "ORDERID" in str(t).upper():
                return True
        return False

    # -------------------------------------------------------------------------
    # Public
    # -------------------------------------------------------------------------

    def analyze(self) -> dict:
        return {
            "summary": self._get_summary(),
            "job_type_analysis": self._get_job_type_analysis(),
            "migration_analysis": self._get_migration_analysis(),
            "standalone_jobs": self._get_standalone_jobs(),
            "dependency_analysis": self._get_dependency_analysis(),
            "dag_suggestions": self._get_dag_suggestions(),
            "variables_analysis": self._get_variables_analysis(),
            "calendar_analysis": self._get_calendar_analysis(),
            "event_analysis": self._get_event_analysis(),
            "hostgroup_analysis": self._get_hostgroup_analysis(),
            "schedule_analysis": self._get_schedule_analysis(),
            "dependency_graph": self._get_dependency_graph(),
        }

    # -------------------------------------------------------------------------
    # Analysis sections
    # -------------------------------------------------------------------------

    def _get_summary(self) -> dict:
        total_jobs = len(self.jobs)
        total_folders = len(self.folders)

        migratable = partially = not_migratable = 0
        standalone = with_deps = 0
        jobs_with_odate = jobs_with_variables = 0
        jobs_without_schedule = 0
        calendars_set = set()
        hostgroups_set = set()

        for job in self.jobs:
            info = self._get_type_info(job["type"])
            status = info["migration_status"]
            if status == "Migratable":
                migratable += 1
            elif status == "Partially Migratable":
                partially += 1
            elif status == "Not Migratable":
                not_migratable += 1

            has_in = bool(job["in_conditions"])
            has_out = bool(job["out_conditions"])
            has_event = bool(job["event_to_wait_for"])
            if not has_in and not has_out and not has_event:
                standalone += 1
            else:
                with_deps += 1

            if self._detect_odate(job):
                jobs_with_odate += 1
            if job["variables"]:
                jobs_with_variables += 1
            if job["schedule_summary"] == "Not defined":
                jobs_without_schedule += 1

            for cal_name in job["calendars"].get("CalendarNames", []):
                calendars_set.add(cal_name)

            if self._is_hostgroup(job["host"]):
                hostgroups_set.add(job["host"])

        return {
            "total_jobs": total_jobs,
            "total_folders": total_folders,
            "migratable": migratable,
            "partially_migratable": partially,
            "not_migratable": not_migratable,
            "review_required": total_jobs - migratable - partially - not_migratable,
            "standalone_jobs": standalone,
            "jobs_with_dependencies": with_deps,
            "total_calendars": len(calendars_set),
            "total_hostgroups": len(hostgroups_set),
            "jobs_with_odate": jobs_with_odate,
            "jobs_with_variables": jobs_with_variables,
            "jobs_without_schedule": jobs_without_schedule,
            "folders": self._get_folder_summaries(),
        }

    def _get_job_type_analysis(self) -> list:
        type_map = defaultdict(list)
        for job in self.jobs:
            type_map[job["type"]].append(job)

        total = len(self.jobs) or 1
        result = []
        for job_type, jobs in sorted(type_map.items(), key=lambda x: -len(x[1])):
            info = self._get_type_info(job_type)
            
            # Collect schedules for this job type
            schedules = defaultdict(int)
            for job in jobs:
                sched = job.get("schedule_summary", "Not defined")
                if sched:
                    schedules[sched] += 1
            
            # Get most common schedule
            most_common_schedule = "Not defined"
            if schedules:
                most_common_schedule = max(schedules.items(), key=lambda x: x[1])[0]
            
            # Get sample schedules (up to 3 most common)
            sample_schedules = sorted(schedules.items(), key=lambda x: -x[1])[:3]
            schedules_list = [s[0] for s in sample_schedules]
            
            result.append({
                "job_type": job_type,
                "count": len(jobs),
                "percentage": round(len(jobs) / total * 100, 1),
                "job_names": [j["name"] for j in jobs],
                "airflow_equivalent": info["airflow_equivalent"],
                "migration_status": info["migration_status"],
                "effort": info["effort"],
                "control_m_construct": info["control_m_construct"],
                "airflow_equivalent_detail": info["airflow_equivalent_detail"],
                "notes": info["notes"],
                "most_common_schedule": most_common_schedule,
                "schedules": schedules_list,
            })
        return result

    def _get_migration_analysis(self) -> dict:
        migratable = []
        partially = []
        not_migratable = []

        for job in self.jobs:
            info = self._get_type_info(job["type"])
            record = {
                "job_name": job["name"],
                "folder": job["folder"],
                "type": job["type"],
                "airflow_equivalent": info["airflow_equivalent"],
                "effort": info["effort"],
                "notes": info["notes"],
                "host": job["host"],
                "run_as": job["run_as"],
                "schedule_summary": job["schedule_summary"],
            }
            if info["migration_status"] == "Migratable":
                migratable.append(record)
            elif info["migration_status"] == "Partially Migratable":
                partially.append(record)
            elif info["migration_status"] == "Not Migratable":
                not_migratable.append(record)

        return {
            "migratable": migratable,
            "partially_migratable": partially,
            "not_migratable": not_migratable,
        }

    def _get_standalone_jobs(self) -> list:
        result = []
        for job in self.jobs:
            if job["in_conditions"] or job["out_conditions"] or job["event_to_wait_for"]:
                continue
            var_names = [v["Name"] for v in job["variables"]]
            result.append({
                "name": job["name"],
                "folder": job["folder"],
                "type": job["type"],
                "host": job["host"],
                "schedule_summary": job["schedule_summary"],
                "variables": var_names,
                "airflow_recommendation": "Create as standalone DAG",
            })
        return result

    def _get_dependency_analysis(self) -> dict:
        jobs_with_in = []
        jobs_with_out = []
        cross_folder = []
        event_driven = []

        # Build a condition-name → (job, folder) map for OutConditions
        out_cond_map = {}  # condition_name -> (job_name, folder)
        for job in self.jobs:
            for cond in job["out_conditions"]:
                out_cond_map[cond["Name"]] = (job["name"], job["folder"])

        for job in self.jobs:
            if job["in_conditions"]:
                jobs_with_in.append({
                    "job_name": job["name"],
                    "folder": job["folder"],
                    "conditions": [c["Name"] for c in job["in_conditions"]],
                    "condition_count": len(job["in_conditions"]),
                })
            if job["out_conditions"]:
                jobs_with_out.append({
                    "job_name": job["name"],
                    "folder": job["folder"],
                    "conditions": [c["Name"] for c in job["out_conditions"]],
                    "condition_count": len(job["out_conditions"]),
                })
            if job["event_to_wait_for"]:
                event_driven.append({
                    "job_name": job["name"],
                    "folder": job["folder"],
                    "events": [e["Name"] for e in job["event_to_wait_for"]],
                })

            # Cross-folder: InCondition matches an OutCondition in a different folder
            for cond in job["in_conditions"]:
                cond_name = cond["Name"]
                if cond_name in out_cond_map:
                    source_job, source_folder = out_cond_map[cond_name]
                    if source_folder != job["folder"]:
                        cross_folder.append({
                            "source_job": source_job,
                            "source_folder": source_folder,
                            "target_job": job["name"],
                            "target_folder": job["folder"],
                            "condition_name": cond_name,
                            "airflow_construct": "ExternalTaskSensor",
                        })

        # Dependency chains (simple: direct parent-child)
        chains = []
        for job in self.jobs:
            for cond in job["in_conditions"]:
                if cond["Name"] in out_cond_map:
                    parent, _ = out_cond_map[cond["Name"]]
                    chains.append({"parent": parent, "child": job["name"], "via": cond["Name"]})

        return {
            "jobs_with_in_conditions": jobs_with_in,
            "jobs_with_out_conditions": jobs_with_out,
            "cross_folder_dependencies": cross_folder,
            "event_driven_jobs": event_driven,
            "dependency_chains": chains,
        }

    def _get_dag_suggestions(self) -> list:
        """Group jobs into suggested Airflow DAGs."""
        # Build adjacency for same-folder jobs connected via conditions
        # 1. Group by folder
        folder_jobs = defaultdict(list)
        for job in self.jobs:
            folder_jobs[job["folder"]].append(job)

        # 2. Cross-folder edges
        out_cond_map = {}
        for job in self.jobs:
            for cond in job["out_conditions"]:
                out_cond_map[cond["Name"]] = (job["name"], job["folder"])

        cross_folder_pairs = set()
        for job in self.jobs:
            for cond in job["in_conditions"]:
                if cond["Name"] in out_cond_map:
                    src_job, src_folder = out_cond_map[cond["Name"]]
                    if src_folder != job["folder"]:
                        cross_folder_pairs.add((src_folder, job["folder"]))

        suggestions = []
        processed_folders = set()

        for folder_name, jobs in folder_jobs.items():
            if folder_name in processed_folders:
                continue

            # Determine schedule from first job with a schedule
            schedule = next(
                (j["schedule_summary"] for j in jobs if j["schedule_summary"] != "Not defined"),
                "Not defined"
            )

            # Check if this folder has cross-folder deps
            has_cross = any(
                folder_name in pair for pair in cross_folder_pairs
            )

            dag_name = re.sub(r"[^a-zA-Z0-9_]", "_", folder_name) + "_DAG"

            suggestions.append({
                "dag_name": dag_name,
                "jobs": [j["name"] for j in jobs],
                "dag_type": "multi_folder" if has_cross else "single_folder",
                "total_tasks": len(jobs),
                "has_cross_folder_deps": has_cross,
                "schedule": schedule,
                "folder": folder_name,
                "reason": (
                    "Jobs from same folder with interconnected conditions; "
                    "cross-folder deps use ExternalTaskSensor"
                    if has_cross else
                    "Jobs from same folder grouped into single DAG"
                ),
            })
            processed_folders.add(folder_name)

        # Standalone jobs get their own DAG suggestion
        for job in self.jobs:
            if not job["in_conditions"] and not job["out_conditions"] and not job["event_to_wait_for"]:
                dag_name = re.sub(r"[^a-zA-Z0-9_]", "_", job["name"]) + "_DAG"
                # Check if already covered by folder suggestion (avoid duplicate)
                # (standalone jobs are already in folder groups above)

        return sorted(suggestions, key=lambda x: -x["total_tasks"])

    def _get_variables_analysis(self) -> dict:
        odate_jobs = []
        orderid_jobs = []
        shiftleft_jobs = []
        shiftright_jobs = []
        manual_jobs = []
        all_vars = defaultdict(int)  # var_name -> count

        for job in self.jobs:
            if self._detect_odate(job):
                odate_jobs.append(job["name"])
            if self._detect_orderid(job):
                orderid_jobs.append(job["name"])
            if job["shift_left"]:
                shiftleft_jobs.append({"job": job["name"], "value": job["shift_left"]})
            if job["shift_right"]:
                shiftright_jobs.append({"job": job["name"], "value": job["shift_right"]})
            if str(job["order_method"]).lower() == "manual":
                manual_jobs.append(job["name"])
            for var in job["variables"]:
                name = var.get("Name", "")
                if name:
                    all_vars[name] += 1

        airflow_mapping = {
            "%%ODATE / ODATE": "{{ ds }} or {{ execution_date.strftime('%Y%m%d') }}",
            "%%ORDERID": "Custom Airflow Variable or XCom",
            "ShiftLeft": "timedelta(days=-N) on schedule_interval",
            "ShiftRight": "timedelta(days=+N) on schedule_interval",
            "OrderMethod=Manual": "DAG with schedule=None (manual trigger)",
            "%%JOBNAME": "{{ task.task_id }}",
            "%%FOLDER": "{{ dag.dag_id }}",
            "%%RUNCOUNT": "{{ ti.try_number }}",
        }

        return {
            "odate_jobs": odate_jobs,
            "orderid_jobs": orderid_jobs,
            "shiftleft_jobs": shiftleft_jobs,
            "shiftright_jobs": shiftright_jobs,
            "manual_schedule_jobs": manual_jobs,
            "dynamic_variables": list(all_vars.keys()),
            "variable_frequency": dict(all_vars),
            "airflow_mapping": airflow_mapping,
        }

    def _get_calendar_analysis(self) -> dict:
        calendars_used = set()
        jobs_by_calendar = defaultdict(list)
        jobs_with_exceptions = []
        calendar_types = {}

        for job in self.jobs:
            cal_data = job["calendars"]
            cal_names = cal_data.get("CalendarNames", [])
            exception_policy = cal_data.get("ExceptionPolicy", "")

            for cal_name in cal_names:
                calendars_used.add(cal_name)
                jobs_by_calendar[cal_name].append(job["name"])
                if cal_name not in calendar_types:
                    calendar_types[cal_name] = "Standard"

            if exception_policy:
                jobs_with_exceptions.append({
                    "job": job["name"],
                    "folder": job["folder"],
                    "exception_policy": exception_policy,
                })

        return {
            "calendars_used": list(calendars_used),
            "jobs_by_calendar": dict(jobs_by_calendar),
            "jobs_with_exceptions": jobs_with_exceptions,
            "calendar_types": calendar_types,
            "total_calendars": len(calendars_used),
        }

    def _get_event_analysis(self) -> dict:
        events_to_wait = []
        event_adds = []
        cross_folder_events = []
        external_sensors = []

        # Map: condition_name -> (job, folder) for OutConditions
        out_cond_map = {}
        for job in self.jobs:
            for cond in job["out_conditions"]:
                out_cond_map[cond["Name"]] = (job["name"], job["folder"])

        for job in self.jobs:
            for event in job["event_to_wait_for"]:
                events_to_wait.append({
                    "job": job["name"],
                    "folder": job["folder"],
                    "event_name": event["Name"],
                    "date": event.get("Date", "ODAT"),
                })

            for event in job["event_to_add"]:
                event_adds.append({
                    "job": job["name"],
                    "folder": job["folder"],
                    "event_name": event["Name"],
                })

            # Treat InConditions that are cross-folder as events too
            for cond in job["in_conditions"]:
                if cond["Name"] in out_cond_map:
                    src_job, src_folder = out_cond_map[cond["Name"]]
                    if src_folder != job["folder"]:
                        cross_folder_events.append({
                            "source_job": src_job,
                            "source_folder": src_folder,
                            "target_job": job["name"],
                            "target_folder": job["folder"],
                            "condition_name": cond["Name"],
                        })
                        external_sensors.append({
                            "source_job": src_job,
                            "source_folder": src_folder,
                            "target_job": job["name"],
                            "target_folder": job["folder"],
                            "event_name": cond["Name"],
                            "airflow_construct": "ExternalTaskSensor",
                        })

        return {
            "events_to_wait": events_to_wait,
            "cross_folder_events": cross_folder_events,
            "external_task_sensors_needed": external_sensors,
            "event_adds": event_adds,
            "total_events": len(events_to_wait) + len(event_adds),
        }

    def _get_folder_summaries(self) -> list:
        """Build folder-level summary data for the web interface."""
        folder_data = {}
        
        # Group jobs by folder
        for job in self.jobs:
            folder_name = job.get("folder", "Unknown")
            if folder_name not in folder_data:
                folder_data[folder_name] = {
                    "name": folder_name,
                    "server": job.get("host", "").split('.')[0] if job.get("host") else "",
                    "application": "",
                    "job_count": 0,
                    "cyclic_count": 0,
                    "critical_count": 0,
                    "dummy_count": 0,
                    "standalone_count": 0,
                    "external_deps": 0,
                    "job_types": {},
                    "jobs": [],
                }
            
            folder_data[folder_name]["job_count"] += 1
            folder_data[folder_name]["jobs"].append(job["name"])
            
            # Count job types
            job_type = job.get("type", "Unknown")
            if job_type not in folder_data[folder_name]["job_types"]:
                folder_data[folder_name]["job_types"][job_type] = 0
            folder_data[folder_name]["job_types"][job_type] += 1
            
            # Count dummy jobs
            if "Dummy" in job_type:
                folder_data[folder_name]["dummy_count"] += 1
            
            # Check for dependencies
            if not job["in_conditions"] and not job["out_conditions"] and not job["event_to_wait_for"]:
                folder_data[folder_name]["standalone_count"] += 1
            else:
                folder_data[folder_name]["external_deps"] += 1
        
        # Convert job_types dict to list of dicts with airflow operator info
        result = []
        for folder_name, data in sorted(folder_data.items()):
            job_types_list = []
            for jtype, count in sorted(data["job_types"].items()):
                type_info = self._get_type_info(jtype)
                job_types_list.append({
                    "type": jtype,
                    "count": count,
                    "airflow_operator": type_info.get("airflow_equivalent", "TBD"),
                })
            
            data["job_types"] = job_types_list
            result.append(data)
        
        return result

    def _get_hostgroup_analysis(self) -> dict:
        hostgroups = defaultdict(list)
        regular_hosts = defaultdict(list)

        for job in self.jobs:
            host = job["host"]
            if not host:
                continue
            if self._is_hostgroup(host):
                hostgroups[host].append(job["name"])
            else:
                regular_hosts[host].append(job["name"])

        return {
            "hostgroups_used": list(hostgroups.keys()),
            "jobs_by_hostgroup": dict(hostgroups),
            "total_jobs_on_hostgroups": sum(len(v) for v in hostgroups.values()),
            "regular_hosts": list(regular_hosts.keys()),
            "jobs_by_host": dict(regular_hosts),
            "airflow_note": "Use pool/queue in Airflow for hostgroup behavior; set worker_queue on operators",
        }

    def _get_schedule_analysis(self) -> dict:
        with_schedule = []
        without_schedule = []
        pattern_counts = defaultdict(int)
        cron_equivalents = {}
        time_based = []

        for job in self.jobs:
            summary = job["schedule_summary"]
            if summary in ("Not defined", "Manual trigger"):
                without_schedule.append({
                    "job_name": job["name"],
                    "folder": job["folder"],
                    "type": job["type"],
                    "note": "Manual trigger or dependency-only" if summary == "Manual trigger" else "No schedule defined",
                })
            else:
                cron = self._estimate_cron(job)
                with_schedule.append({
                    "job_name": job["name"],
                    "folder": job["folder"],
                    "schedule_details": summary,
                    "cron_equivalent": cron,
                    "days": job["days"],
                    "week_days": job["week_days"],
                    "months": job["months"],
                    "times": str(job["times"]),
                })
                cron_equivalents[job["name"]] = cron

                # Pattern detection
                if "Daily" in summary or str(job["days"]).lower() in ("all", "*"):
                    pattern_counts["daily"] += 1
                elif "Mon-Fri" in summary or "Weekdays" in summary:
                    pattern_counts["weekdays"] += 1
                elif job["months"] and str(job["months"]).upper() not in ("ALL", "*", ""):
                    pattern_counts["monthly"] += 1
                else:
                    pattern_counts["other"] += 1

                if job["times"]:
                    time_based.append({
                        "job_name": job["name"],
                        "times": str(job["times"]),
                    })

        return {
            "jobs_with_schedule": with_schedule,
            "jobs_without_schedule": without_schedule,
            "schedule_patterns": dict(pattern_counts),
            "cron_equivalents": cron_equivalents,
            "time_based_jobs": time_based,
        }

    def _estimate_cron(self, job: dict) -> str:
        """Best-effort cron expression from CTM schedule fields."""
        times = job.get("times", [])
        minute = "0"
        hour = "*"

        if times:
            t = times[0] if isinstance(times, list) else times
            if isinstance(t, dict):
                t = t.get("From", t.get("Time", "00:00"))
            t = str(t)
            if ":" in t:
                parts = t.split(":")
                hour = parts[0].lstrip("0") or "0"
                minute = parts[1][:2].lstrip("0") or "0"

        days = str(job.get("days", "*")).lower()
        week_days = str(job.get("week_days", "*")).upper()
        months = str(job.get("months", "*")).upper()

        dom = "*"
        dow = "*"
        mon = "*"

        if days not in ("all", "*", "", "everyday"):
            dom = days
        if week_days not in ("ALL", "*", ""):
            dow_map = {"MON": "1", "TUE": "2", "WED": "3", "THU": "4",
                       "FRI": "5", "SAT": "6", "SUN": "0"}
            dow = dow_map.get(week_days, week_days)
        if months not in ("ALL", "*", ""):
            mon_map = {"JAN": "1", "FEB": "2", "MAR": "3", "APR": "4",
                       "MAY": "5", "JUN": "6", "JUL": "7", "AUG": "8",
                       "SEP": "9", "OCT": "10", "NOV": "11", "DEC": "12"}
            mon = mon_map.get(months, months)

        return f"{minute} {hour} {dom} {mon} {dow}"

    def _get_dependency_graph(self) -> dict:
        nodes = []
        edges = []
        seen_nodes = set()

        # Colour map by migration status
        color_map = {
            "Migratable": "#28a745",
            "Partially Migratable": "#fd7e14",
            "Not Migratable": "#dc3545",
            "Review Required": "#6c757d",
        }

        for job in self.jobs:
            if job["name"] not in seen_nodes:
                info = self._get_type_info(job["type"])
                nodes.append({
                    "id": job["name"],
                    "label": job["name"],
                    "group": job["folder"],
                    "type": job["type"],
                    "migration_status": info["migration_status"],
                    "color": color_map.get(info["migration_status"], "#6c757d"),
                    "title": f"{job['type']} | {job['folder']} | {info['airflow_equivalent']}",
                    "shape": "box",
                    "font": {"size": 12},
                })
                seen_nodes.add(job["name"])

        # Build maps for dependencies
        out_cond_map = {}  # condition_name -> source_job_name
        for job in self.jobs:
            for cond in job["out_conditions"]:
                out_cond_map[cond["Name"]] = job["name"]
        
        # Map for folder level dependencies
        folder_completion_map = {}  # folder_name -> jobs_in_folder
        for job in self.jobs:
            if job["folder"] not in folder_completion_map:
                folder_completion_map[job["folder"]] = []
            folder_completion_map[job["folder"]].append(job["name"])

        edge_id = 0
        for job in self.jobs:
            # Edges from InConditions to OutConditions (parent -> child)
            for cond in job["in_conditions"]:
                src = out_cond_map.get(cond["Name"])
                if src and src != job["name"]:
                    edges.append({
                        "id": edge_id,
                        "from": src,  # Parent (source)
                        "to": job["name"],  # Child (target)
                        "label": cond["Name"],
                        "type": "in_condition",
                        "arrows": "to",
                        "smooth": {"type": "curvedCW"},
                    })
                    edge_id += 1

            # Edges from events
            for event in job["event_to_wait_for"]:
                # Try to find source from out_cond_map
                src = out_cond_map.get(event["Name"])
                if src and src != job["name"]:
                    edges.append({
                        "id": edge_id,
                        "from": src,  # Parent
                        "to": job["name"],  # Child
                        "label": event["Name"],
                        "type": "event",
                        "arrows": "to",
                        "dashes": {"enabled": True},
                    })
                    edge_id += 1
            
            # Handle folder completion dependencies
            for key in job.get("_raw", {}).keys():
                if key.startswith("IfBase:Folder:CompletionStatus"):
                    # This job waits for all jobs in a previous folder to complete
                    # Extract folder name if possible from the key
                    edges.append({
                        "id": edge_id,
                        "from": key,  # Folder reference
                        "to": job["name"],
                        "label": "Folder Completion",
                        "type": "folder_completion",
                        "arrows": "to",
                        "color": {"color": "#6c757d", "highlight": "#495057"},
                    })
                    edge_id += 1

        return {"nodes": nodes, "edges": edges}
