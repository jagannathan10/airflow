"""
HTML Report Generator for Control-M to Airflow Migration Analysis
Generates professional HTML reports matching the markdown sample format provided.
"""

import json
from datetime import datetime
from typing import Dict, List, Any


class HTMLReportGenerator:
    """Generate professional HTML reports from Control-M analyzer results."""

    def __init__(self, analysis_data: dict, source_file: str = "control_m.json"):
        self.data = analysis_data
        self.source_file = source_file
        self.generated_time = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")

    def generate(self) -> str:
        """Generate complete HTML report."""
        return f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Control-M to Airflow Migration Report</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; background: #f5f5f5; }}
        .container {{ max-width: 1200px; margin: 0 auto; padding: 20px; background: white; }}
        .header {{ border-bottom: 3px solid #0066cc; padding-bottom: 20px; margin-bottom: 30px; }}
        .title {{ font-size: 28px; font-weight: bold; color: #0066cc; margin-bottom: 5px; }}
        .subtitle {{ font-size: 14px; color: #666; }}
        .meta {{ display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin: 20px 0; font-size: 14px; }}
        .meta-item {{ background: #f9f9f9; padding: 10px; border-left: 3px solid #0066cc; }}
        .meta-label {{ font-weight: bold; color: #0066cc; }}
        .summary-grid {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin: 20px 0; }}
        .summary-card {{ background: linear-gradient(135deg, #0066cc, #0099ff); color: white; padding: 20px; border-radius: 8px; text-align: center; }}
        .summary-value {{ font-size: 24px; font-weight: bold; }}
        .summary-label {{ font-size: 12px; margin-top: 5px; opacity: 0.9; }}
        .section {{ margin: 30px 0; page-break-inside: avoid; }}
        .section-title {{ font-size: 20px; font-weight: bold; color: #0066cc; border-bottom: 2px solid #0066cc; padding-bottom: 10px; margin-bottom: 15px; display: flex; align-items: center; gap: 10px; }}
        .section-icon {{ font-size: 24px; }}
        table {{ width: 100%; border-collapse: collapse; margin: 15px 0; }}
        th, td {{ padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }}
        th {{ background: #f0f0f0; font-weight: bold; color: #333; }}
        tr:hover {{ background: #f9f9f9; }}
        .badge {{ display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: bold; }}
        .badge-green {{ background: #d4edda; color: #155724; }}
        .badge-orange {{ background: #fff3cd; color: #856404; }}
        .badge-red {{ background: #f8d7da; color: #721c24; }}
        .badge-blue {{ background: #d1ecf1; color: #0c5460; }}
        .chart-row {{ display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin: 20px 0; }}
        .chart {{ background: #f9f9f9; padding: 15px; border-radius: 8px; border: 1px solid #ddd; }}
        .chart-title {{ font-weight: bold; margin-bottom: 10px; color: #333; }}
        .bar {{ display: flex; align-items: center; margin: 8px 0; }}
        .bar-label {{ width: 180px; font-size: 12px; }}
        .bar-fill {{ background: linear-gradient(90deg, #0066cc, #0099ff); height: 25px; border-radius: 4px; display: flex; align-items: center; padding-left: 8px; color: white; font-size: 12px; font-weight: bold; }}
        .bar-value {{ margin-left: 10px; font-weight: bold; min-width: 50px; }}
        .no-data {{ color: #999; font-style: italic; text-align: center; padding: 20px; }}
        .notes {{ background: #e7f3ff; border-left: 4px solid #0066cc; padding: 12px; margin: 15px 0; font-size: 13px; }}
        .footer {{ margin-top: 40px; padding-top: 20px; border-top: 1px solid #ddd; text-align: center; color: #666; font-size: 12px; }}
        @media print {{ body {{ background: white; }} .container {{ box-shadow: none; }} }}
    </style>
</head>
<body>
    <div class="container">
        {self._generate_header()}
        {self._generate_summary()}
        {self._generate_job_types()}
        {self._generate_migration()}
        {self._generate_dependencies()}
        {self._generate_schedules()}
        {self._generate_footer()}
    </div>
</body>
</html>
"""

    def _generate_header(self) -> str:
        return f"""
        <div class="header">
            <div class="title">✈️ Control-M → Apache Airflow Migration Analysis Report</div>
            <div class="subtitle">Comprehensive job classification and Airflow migration assessment</div>
            <div class="meta">
                <div class="meta-item">
                    <span class="meta-label">Generated:</span><br>{self.generated_time}
                </div>
                <div class="meta-item">
                    <span class="meta-label">Source File:</span><br>{self.source_file}
                </div>
            </div>
        </div>
"""

    def _generate_summary(self) -> str:
        summary = self.data.get('summary', {})
        
        cards_html = ""
        cards = [
            ("Total Jobs", summary.get('total_jobs', 0), "📋"),
            ("Migratable", summary.get('migratable', 0), "✅"),
            ("Partially Migratable", summary.get('partially_migratable', 0), "⚠️"),
            ("Not Migratable", summary.get('not_migratable', 0), "❌"),
        ]
        
        for label, value, icon in cards:
            cards_html += f"""
            <div class="summary-card">
                <div style="font-size: 20px; margin-bottom: 5px;">{icon}</div>
                <div class="summary-value">{value}</div>
                <div class="summary-label">{label}</div>
            </div>
"""
        
        return f"""
        <div class="section">
            <div class="section-title"><span class="section-icon">📊</span> Executive Summary</div>
            <div class="summary-grid">
                {cards_html}
            </div>
            <div class="notes">
                ℹ️ Analysis covers {summary.get('total_jobs', 0)} jobs across {summary.get('total_folders', 0)} folders.
                {summary.get('standalone_jobs', 0)} standalone jobs detected (no dependencies).
                {summary.get('jobs_with_dependencies', 0)} jobs have dependency chains.
            </div>
        </div>
"""

    def _generate_job_types(self) -> str:
        job_types = self.data.get('job_type_analysis', [])
        
        if not job_types:
            return '<div class="section"><div class="section-title"><span class="section-icon">🏷️</span> Job Type Breakdown</div><div class="no-data">No job type data available</div></div>'
        
        table_rows = ""
        for jt in job_types[:15]:
            status_color = {
                'Migratable': 'badge-green',
                'Partially Migratable': 'badge-orange',
                'Not Migratable': 'badge-red',
            }.get(jt['migration_status'], 'badge-blue')
            
            effort_color = {
                'Low': 'badge-green',
                'Medium': 'badge-orange',
                'High': 'badge-red',
            }.get(jt['effort'], 'badge-blue')
            
            schedules = ', '.join(jt.get('schedules', [])[:2]) if jt.get('schedules') else 'Not defined'
            
            table_rows += f"""
            <tr>
                <td><strong>{jt['job_type']}</strong></td>
                <td style="text-align: right; font-weight: bold;">{jt['count']}</td>
                <td style="text-align: right;">{jt['percentage']}%</td>
                <td>{jt['airflow_equivalent']}</td>
                <td><span class="badge {status_color}">{jt['migration_status']}</span></td>
                <td><span class="badge {effort_color}">{jt['effort']}</span></td>
                <td style="font-size: 12px; color: #666;">{schedules}</td>
            </tr>
"""
        
        return f"""
        <div class="section">
            <div class="section-title"><span class="section-icon">🏷️</span> Job Type Breakdown</div>
            <table>
                <thead>
                    <tr>
                        <th>Job Type</th>
                        <th style="text-align: right;">Count</th>
                        <th style="text-align: right;">%</th>
                        <th>Airflow Equivalent</th>
                        <th>Migration Status</th>
                        <th>Effort</th>
                        <th>Schedule Examples</th>
                    </tr>
                </thead>
                <tbody>
                    {table_rows}
                </tbody>
            </table>
        </div>
"""

    def _generate_migration(self) -> str:
        migration = self.data.get('migration_analysis', {})
        migratable = migration.get('migratable', [])
        partial = migration.get('partially_migratable', [])
        not_mig = migration.get('not_migratable', [])
        
        sections = ""
        
        # Migratable
        if migratable:
            rows = '\n'.join([
                f"<tr><td><strong>{j['job_name']}</strong></td><td>{j['folder']}</td><td>{j['type']}</td><td>{j.get('schedule_summary', 'N/A')}</td></tr>"
                for j in migratable[:10]
            ])
            sections += f"""
            <div style="margin-bottom: 20px;">
                <strong style="color: #28a745;">✅ Migratable ({len(migratable)} jobs)</strong>
                <table>
                    <thead><tr><th>Job Name</th><th>Folder</th><th>Type</th><th>Schedule</th></tr></thead>
                    <tbody>{rows}</tbody>
                </table>
            </div>
"""
        
        # Partially Migratable
        if partial:
            rows = '\n'.join([
                f"<tr><td><strong>{j['job_name']}</strong></td><td>{j['folder']}</td><td>{j['type']}</td><td>{j.get('schedule_summary', 'N/A')}</td></tr>"
                for j in partial[:10]
            ])
            sections += f"""
            <div style="margin-bottom: 20px;">
                <strong style="color: #fd7e14;">⚠️ Partially Migratable ({len(partial)} jobs)</strong>
                <table>
                    <thead><tr><th>Job Name</th><th>Folder</th><th>Type</th><th>Schedule</th></tr></thead>
                    <tbody>{rows}</tbody>
                </table>
            </div>
"""
        
        # Not Migratable
        if not_mig:
            rows = '\n'.join([
                f"<tr><td><strong>{j['job_name']}</strong></td><td>{j['folder']}</td><td>{j['type']}</td><td>{j.get('schedule_summary', 'N/A')}</td></tr>"
                for j in not_mig[:10]
            ])
            sections += f"""
            <div style="margin-bottom: 20px;">
                <strong style="color: #dc3545;">❌ Not Migratable ({len(not_mig)} jobs)</strong>
                <table>
                    <thead><tr><th>Job Name</th><th>Folder</th><th>Type</th><th>Schedule</th></tr></thead>
                    <tbody>{rows}</tbody>
                </table>
            </div>
"""
        
        return f"""
        <div class="section">
            <div class="section-title"><span class="section-icon">🔄</span> Migration Analysis</div>
            {sections}
        </div>
"""

    def _generate_dependencies(self) -> str:
        deps = self.data.get('dependency_analysis', {})
        chains = deps.get('dependency_chains', [])
        cross = deps.get('cross_folder_dependencies', [])
        
        sections = ""
        
        if chains:
            rows = '\n'.join([
                f"<tr><td><strong>{c['parent']}</strong></td><td>→</td><td><strong>{c['child']}</strong></td><td style=\"font-size: 12px;\">{c['via']}</td></tr>"
                for c in chains[:15]
            ])
            sections += f"""
            <div style="margin-bottom: 20px;">
                <strong>📦 Dependency Chains ({len(chains)} total)</strong>
                <table>
                    <thead><tr><th>Parent Job</th><th></th><th>Child Job</th><th>Via Condition</th></tr></thead>
                    <tbody>{rows}</tbody>
                </table>
            </div>
"""
        
        if cross:
            rows = '\n'.join([
                f"<tr><td><strong>{c['source_job']}</strong></td><td>{c['source_folder']}</td><td><strong>{c['target_job']}</strong></td><td>{c['target_folder']}</td></tr>"
                for c in cross[:10]
            ])
            sections += f"""
            <div style="margin-bottom: 20px;">
                <strong>🌍 Cross-Folder Dependencies ({len(cross)} total)</strong>
                <table>
                    <thead><tr><th>Source Job</th><th>Source Folder</th><th>Target Job</th><th>Target Folder</th></tr></thead>
                    <tbody>{rows}</tbody>
                </table>
            </div>
"""
        
        if not sections:
            sections = '<div class="no-data">No dependency chains found</div>'
        
        return f"""
        <div class="section">
            <div class="section-title"><span class="section-icon">🔗</span> Dependency Analysis</div>
            {sections}
        </div>
"""

    def _generate_schedules(self) -> str:
        schedule = self.data.get('schedule_analysis', {})
        with_sched = schedule.get('jobs_with_schedule', [])
        patterns = schedule.get('schedule_patterns', {})
        
        pattern_bars = ""
        total_with = len(with_sched)
        if total_with > 0:
            for pattern, count in sorted(patterns.items(), key=lambda x: -x[1])[:5]:
                pct = (count / total_with * 100) if total_with else 0
                pattern_bars += f"""
                <div class="bar">
                    <div class="bar-label">{pattern.capitalize()}</div>
                    <div class="bar-fill" style="width: {pct}%">{pct:.0f}%</div>
                    <div class="bar-value">{count}</div>
                </div>
"""
        
        return f"""
        <div class="section">
            <div class="section-title"><span class="section-icon">⏰</span> Schedule Analysis</div>
            <div class="chart">
                <div class="chart-title">Schedule Patterns Distribution ({total_with} jobs)</div>
                {pattern_bars}
            </div>
            <div class="notes">
                ℹ️ {len(schedule.get('jobs_without_schedule', []))} jobs have no schedule defined (manual/dependency-driven).
                Time-based scheduling detected on {len(schedule.get('time_based_jobs', []))} jobs.
            </div>
        </div>
"""

    def _generate_footer(self) -> str:
        return f"""
        <div class="footer">
            <p>Report generated on {self.generated_time}</p>
            <p>Control-M to Airflow Migration Analyzer v2.1</p>
            <p>This report contains a comprehensive analysis of your Control-M job definitions and recommendations for Airflow migration.</p>
        </div>
"""
