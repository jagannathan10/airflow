#!/usr/bin/env bash
# Control-M to Airflow Analyzer - Start Script

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# Create venv if it doesn't exist
if [ ! -d "venv" ]; then
  echo "Creating virtual environment..."
  python3 -m venv venv
fi

# Install/upgrade dependencies using venv pip directly
echo "Installing dependencies..."
venv/bin/pip install -q -r requirements.txt

# Start gunicorn using venv binary
echo "Starting Control-M Analyzer on http://127.0.0.1:5000"
venv/bin/gunicorn -w 4 -b 127.0.0.1:5000 wsgi:app
