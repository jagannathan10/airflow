#!/bin/bash

# ══════════════════════════════════════════════════════════════
# setup_test_env.sh — Creates Test Environment for Cron Testing
# ══════════════════════════════════════════════════════════════
# Run this ONCE to set up the directory structure and generate
# dummy files so you can test all the cron scripts immediately.
#
# Usage: sudo ./setup_test_env.sh
# ══════════════════════════════════════════════════════════════

set -euo pipefail

log() {
    echo "[SETUP] $1"
}

log "══════════════════════════════════════════════"
log " Setting up test environment..."
log "══════════════════════════════════════════════"

# ── 1. Create directory structure ──
log "Creating directories..."

DIRS=(
    /apps/cron/logs
    /apps/scripts
    /apps/test_env/logs
    /apps/test_env/tmp
    /apps/test_env/cache
    /apps/test_env/cache/thumbnails
    /apps/test_env/cache/api_responses
    /apps/test_env/data
    /apps/test_env/reports
    /apps/test_env/archives
)

for DIR in "${DIRS[@]}"; do
    mkdir -p "$DIR"
    log "  Created: ${DIR}"
done

# ── 2. Generate dummy log files (various ages) ──
log "Generating dummy log files..."

generate_log() {
    local FILE="$1"
    local LINES="${2:-100}"
    local AGE_DAYS="${3:-0}"

    for i in $(seq 1 "$LINES"); do
        echo "[$(date -d "${AGE_DAYS} days ago" '+%Y-%m-%d %H:%M:%S')] [INFO] Log entry #${i} — Processing request id=$(shuf -i 1000-9999 -n 1) status=$(shuf -e 200 201 301 404 500 -n 1)" >> "$FILE"
    done

    # Set the file modification time to simulate age
    if [ "$AGE_DAYS" -gt 0 ]; then
        touch -d "${AGE_DAYS} days ago" "$FILE"
    fi
}

# Recent logs (should NOT be cleaned)
generate_log "/apps/test_env/logs/app.log"       200  0
generate_log "/apps/test_env/logs/access.log"     150  1
generate_log "/apps/test_env/logs/error.log"      50   2

# Old logs (should be cleaned by housekeeping)
generate_log "/apps/test_env/logs/app_old.log"    500  10
generate_log "/apps/test_env/logs/access_old.log" 300  15
generate_log "/apps/test_env/logs/error_old.log"  100  20
generate_log "/apps/test_env/logs/debug.log"      800  25

# Rotated logs
generate_log "/apps/test_env/logs/app.log.1"      100  3
generate_log "/apps/test_env/logs/app.log.2"       80  8
generate_log "/apps/test_env/logs/app.log.3"       80  12

log "  Created $(find /apps/test_env/logs -type f | wc -l) log files"

# ── 3. Generate dummy temp files ──
log "Generating dummy temp files..."

for i in $(seq 1 15); do
    AGE=$(shuf -i 0-10 -n 1)
    TMPFILE="/apps/test_env/tmp/temp_process_${i}_$(date -d "${AGE} days ago" +%Y%m%d).dat"
    dd if=/dev/urandom of="$TMPFILE" bs=1K count=$(shuf -i 10-500 -n 1) 2>/dev/null
    touch -d "${AGE} days ago" "$TMPFILE"
done

log "  Created $(find /apps/test_env/tmp -type f | wc -l) temp files"

# ── 4. Generate dummy cache files ──
log "Generating dummy cache files..."

for i in $(seq 1 20); do
    AGE=$(shuf -i 0-14 -n 1)
    SUBDIR=$(shuf -e "thumbnails" "api_responses" "" -n 1)
    CACHEFILE="/apps/test_env/cache/${SUBDIR}/cache_$(printf '%05d' $i).json"
    mkdir -p "$(dirname "$CACHEFILE")"
    echo "{\"cached_at\": \"$(date -d "${AGE} days ago" -Iseconds)\", \"key\": \"item_${i}\", \"data\": \"$(head -c 200 /dev/urandom | base64 | head -c 200)\"}" > "$CACHEFILE"
    touch -d "${AGE} days ago" "$CACHEFILE"
done

log "  Created $(find /apps/test_env/cache -type f | wc -l) cache files"

# ── 5. Generate dummy data files (for archiver) ──
log "Generating dummy data files..."

for i in $(seq 1 10); do
    AGE=$(shuf -i 0-8 -n 1)
    DATAFILE="/apps/test_env/data/export_$(date -d "${AGE} days ago" +%Y%m%d)_${i}.csv"
    echo "id,name,value,timestamp" > "$DATAFILE"
    for j in $(seq 1 50); do
        echo "${j},item_${j},$(shuf -i 100-9999 -n 1).$(shuf -i 10-99 -n 1),$(date -d "${AGE} days ago" -Iseconds)" >> "$DATAFILE"
    done
    touch -d "${AGE} days ago" "$DATAFILE"
done

log "  Created $(find /apps/test_env/data -type f | wc -l) data files"

# ── 6. Generate dummy report files ──
log "Generating dummy report files..."

for i in $(seq 1 5); do
    AGE=$(shuf -i 1-20 -n 1)
    REPORT="/apps/test_env/reports/daily_report_$(date -d "${AGE} days ago" +%Y%m%d).txt"
    echo "Daily Report — $(date -d "${AGE} days ago" '+%Y-%m-%d')" > "$REPORT"
    echo "Status: OK | Uptime: 99.9% | Errors: $(shuf -i 0-5 -n 1)" >> "$REPORT"
    touch -d "${AGE} days ago" "$REPORT"
done

log "  Created $(find /apps/test_env/reports -type f | wc -l) report files"

# ── 7. Generate sample cron metric logs ──
log "Generating sample cron metric JSON logs..."

for i in $(seq 1 8); do
    AGE=$(shuf -i 0-45 -n 1)
    STATUS=$(shuf -e "completed" "completed" "completed" "FAILED" -n 1)
    TS=$(date -d "${AGE} days ago" +"%Y%m%d_%H%M%S")
    DURATION=$(shuf -i 2-120 -n 1)
    RETRIES=$([ "$STATUS" = "FAILED" ] && shuf -i 1-3 -n 1 || echo 0)

    cat > "/apps/cron/logs/cron_status_metrics_${TS}.json" <<JSONEOF
{
    "module": "cron",
    "metrics.name": "cron scheduler",
    "host.name": "$(hostname)",
    "cron.command": "/apps/scripts/sample_job_${i}.sh",
    "cron.status": "${STATUS}",
    "cron.final_exit_code": $([ "$STATUS" = "completed" ] && echo 0 || echo 1),
    "cron.start_time": "$(date -d "${AGE} days ago" '+%Y-%m-%d %H:%M:%S')",
    "cron.end_time": "$(date -d "${AGE} days ago +${DURATION} seconds" '+%Y-%m-%d %H:%M:%S')",
    "cron.total_duration_seconds": ${DURATION},
    "retry.max_retries": 3,
    "retry.retried_failed_job": ${RETRIES},
    "retry.total_attempts": $(( RETRIES + 1 ))
}
JSONEOF

    touch -d "${AGE} days ago" "/apps/cron/logs/cron_status_metrics_${TS}.json"
done

log "  Created $(find /apps/cron/logs -type f | wc -l) cron log files"

# ── 8. Summary ──
log ""
log "══════════════════════════════════════════════"
log " TEST ENVIRONMENT READY"
log "══════════════════════════════════════════════"
log ""
log " Directory structure:"
echo ""
find /apps -type d | sort | head -30 | while read -r D; do
    FCOUNT=$(find "$D" -maxdepth 1 -type f 2>/dev/null | wc -l)
    echo "   ${D}/ (${FCOUNT} files)"
done
echo ""

TOTAL_FILES=$(find /apps -type f | wc -l)
TOTAL_SIZE=$(du -sh /apps | awk '{print $1}')
log " Total files: ${TOTAL_FILES}"
log " Total size : ${TOTAL_SIZE}"
log ""
log "══════════════════════════════════════════════"
log " READY TO TEST — Try these commands:"
log "══════════════════════════════════════════════"
echo ""
echo "  # --- Test scripts directly ---"
echo "  /apps/scripts/housekeeping.sh"
echo "  /apps/scripts/health_check.sh"
echo "  /apps/scripts/file_archiver.sh"
echo "  /apps/scripts/log_rotate.sh"
echo "  /apps/scripts/flaky_job.sh 70           # 70% fail rate"
echo ""
echo "  # --- Test with cron_wrapper.sh (retry logic) ---"
echo "  /apps/cron/cron_wrapper.sh -r 0 -- /apps/scripts/housekeeping.sh"
echo "  /apps/cron/cron_wrapper.sh -r 0 -- /apps/scripts/health_check.sh"
echo "  /apps/cron/cron_wrapper.sh -r 2 -d 5 -- /apps/scripts/file_archiver.sh"
echo "  /apps/cron/cron_wrapper.sh -r 3 -d 3 -e -- /apps/scripts/flaky_job.sh 70"
echo ""
echo "  # --- Check JSON output ---"
echo "  ls -lt /apps/cron/logs/"
echo "  cat /apps/cron/logs/cron_status_metrics_*.json | python3 -m json.tool"
echo ""

exit 0
