# Apache Airflow with Custom Plugins & Utils - Complete Guide

## 🚀 Overview

This enhanced installation provides a production-ready Apache Airflow setup with:

- ✅ **Custom Utility Modules** - Reusable helpers, validators, and transformers
- ✅ **Custom Plugins** - Extended operators, sensors, and hooks
- ✅ **Sample DAGs** - Real-world examples organized by category
- ✅ **Full Volume Mounts** - DAGs, plugins, utils, logs, and config
- ✅ **Environment Configuration** - Comprehensive .env setup
- ✅ **Management Scripts** - Easy start/stop/status/cleanup

## 📋 What's Included

### Custom Utils (`utils/` directory)

#### Helpers
- **DataHelper** - JSON/CSV read/write, file operations, list chunking
- **DateHelper** - Date range generation, date arithmetic, formatting
- **NotificationHelper** - Structured logging, Slack message formatting

#### Validators
- **DataValidator** - Field validation, email validation, type checking
- **SchemaValidator** - Schema validation against defined structures

#### Transformers
- **DataTransformer** - Key normalization, field renaming, data flattening

### Custom Plugins (`plugins/` directory)

#### Operators
- **CustomBashOperator** - Enhanced BashOperator with detailed logging
- **DataQualityOperator** - Run multiple data quality checks with configurable failure handling

#### Sensors
- **CustomFileSensor** - Wait for files with optional size validation

#### Hooks
- **CustomHttpHook** - HTTP requests with retry logic and error handling

### Sample DAGs (`dags/` directory)

#### Examples
1. **01_basic_example.py** - Basic Airflow concepts and task dependencies
2. **02_custom_utils_example.py** - Demonstrates using custom utility modules
3. **03_custom_plugins_example.py** - Demonstrates using custom plugins

#### Production
- **etl_pipeline_example.py** - Complete ETL pipeline with extract, transform, validate, load

#### Testing
- **test_dag_example.py** - Validation tests for custom modules

## ⚙️ Installation

### One-Command Install

```bash
chmod +x install-airflow-enhanced.sh
./install-airflow-enhanced.sh
```

### What the Installation Does

1. ✓ Detects RHEL version (8 or 9)
2. ✓ Installs Podman and podman-compose
3. ✓ Creates directory structure with proper organization
4. ✓ Generates comprehensive .env configuration
5. ✓ Creates podman-compose.yml with all volume mounts
6. ✓ Creates all custom utility modules
7. ✓ Creates all custom plugins
8. ✓ Creates sample DAGs in organized folders
9. ✓ Creates management scripts (start/stop/status/logs/cleanup/restart)
10. ✓ Configures SELinux and firewall
11. ✓ Sets proper permissions

### Directory Structure Created

```
~/airflow-podman/
├── dags/
│   ├── examples/              # Example DAGs
│   │   ├── 01_basic_example.py
│   │   ├── 02_custom_utils_example.py
│   │   └── 03_custom_plugins_example.py
│   ├── production/            # Production DAGs
│   │   └── etl_pipeline_example.py
│   └── testing/               # Test DAGs
│       └── test_dag_example.py
├── plugins/
│   ├── __init__.py
│   ├── operators/
│   │   ├── __init__.py
│   │   ├── custom_bash_operator.py
│   │   └── data_quality_operator.py
│   ├── sensors/
│   │   ├── __init__.py
│   │   └── file_sensor.py
│   └── hooks/
│       ├── __init__.py
│       └── custom_http_hook.py
├── utils/
│   ├── __init__.py
│   ├── helpers/
│   │   ├── __init__.py
│   │   ├── data_helper.py
│   │   ├── date_helper.py
│   │   └── notification_helper.py
│   ├── validators/
│   │   ├── __init__.py
│   │   ├── data_validator.py
│   │   └── schema_validator.py
│   └── transformers/
│       ├── __init__.py
│       └── data_transformer.py
├── logs/                      # Airflow execution logs
├── config/                    # Configuration files
├── scripts/                   # Management scripts
│   ├── start.sh
│   ├── stop.sh
│   ├── restart.sh
│   ├── status.sh
│   ├── logs.sh
│   └── cleanup.sh
├── .env                       # Environment configuration
├── podman-compose.yml         # Container orchestration
└── README.md                  # Documentation
```

## 🎯 Quick Start

### 1. Start Airflow

```bash
cd ~/airflow-podman
./scripts/start.sh
```

### 2. Access Web UI

- **URL**: http://localhost:8080
- **Username**: admin
- **Password**: admin

### 3. Explore Sample DAGs

In the Airflow UI, you'll find:
- **01_basic_example** - Start here to understand basics
- **02_custom_utils_example** - See custom utilities in action
- **03_custom_plugins_example** - See custom plugins in action
- **etl_pipeline_example** - Production-ready ETL pattern
- **test_dag_example** - Run to verify all modules work

## 📚 Usage Examples

### Using Custom Utils

```python
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator

# Import custom utilities
from utils.helpers.data_helper import DataHelper
from utils.validators.data_validator import DataValidator
from utils.transformers.data_transformer import DataTransformer

def my_etl_task(**context):
    # Read data using DataHelper
    data = DataHelper.read_json('/path/to/source.json')
    
    # Validate data
    is_valid, missing = DataValidator.validate_required_fields(
        data,
        required_fields=['id', 'name', 'email']
    )
    
    if not is_valid:
        raise ValueError(f"Missing fields: {missing}")
    
    # Transform data
    transformed = DataTransformer.normalize_keys(data)
    
    # Write output
    DataHelper.write_json(transformed, '/path/to/output.json')
    
    return f"Processed {len(data)} records"

with DAG(
    'my_dag',
    start_date=datetime(2024, 1, 1),
    schedule_interval='@daily',
    catchup=False
) as dag:
    
    etl = PythonOperator(
        task_id='etl_task',
        python_callable=my_etl_task
    )
```

### Using Custom Plugins

```python
from datetime import datetime, timedelta
from airflow import DAG

# Import custom plugins
from plugins.operators.custom_bash_operator import CustomBashOperator
from plugins.operators.data_quality_operator import DataQualityOperator
from plugins.sensors.file_sensor import CustomFileSensor

# Data quality check functions
def check_not_empty(data):
    return len(data) > 0

def check_has_required_fields(data):
    return all('id' in item and 'value' in item for item in data)

def get_data():
    return [{'id': 1, 'value': 100}, {'id': 2, 'value': 200}]

with DAG(
    'quality_check_dag',
    start_date=datetime(2024, 1, 1),
    schedule_interval='@daily',
    catchup=False
) as dag:
    
    # Wait for file
    wait_for_file = CustomFileSensor(
        task_id='wait_for_data_file',
        filepath='/tmp/data.csv',
        check_size=True,
        min_size=100,
        poke_interval=30,
        timeout=600
    )
    
    # Process with enhanced logging
    process = CustomBashOperator(
        task_id='process_data',
        bash_command='python /path/to/process.py'
    )
    
    # Run quality checks
    quality_check = DataQualityOperator(
        task_id='data_quality_check',
        data_source=get_data,
        quality_checks=[
            {
                'check': check_not_empty,
                'description': 'Data should not be empty',
                'fail_on_error': True
            },
            {
                'check': check_has_required_fields,
                'description': 'All records should have required fields',
                'fail_on_error': True
            }
        ]
    )
    
    wait_for_file >> process >> quality_check
```

## 🔧 Configuration

### Environment Variables (.env)

The `.env` file contains all configuration:

```bash
# Airflow Core
AIRFLOW__CORE__EXECUTOR=LocalExecutor
AIRFLOW__CORE__PARALLELISM=32
AIRFLOW__CORE__DAG_CONCURRENCY=16

# Database
POSTGRES_USER=airflow
POSTGRES_PASSWORD=airflow
POSTGRES_DB=airflow

# Admin User
AIRFLOW_ADMIN_USERNAME=admin
AIRFLOW_ADMIN_PASSWORD=admin
AIRFLOW_ADMIN_EMAIL=admin@example.com

# Custom Python Path
PYTHONPATH=/opt/airflow:/opt/airflow/utils:/opt/airflow/plugins
```

### Volume Mounts

All directories are mounted for persistence:

```yaml
volumes:
  - ./dags:/opt/airflow/dags          # DAG files
  - ./logs:/opt/airflow/logs          # Execution logs
  - ./plugins:/opt/airflow/plugins    # Custom plugins
  - ./config:/opt/airflow/config      # Configuration
  - ./utils:/opt/airflow/utils        # Utility modules
```

## 📊 Management Commands

### Start/Stop/Status

```bash
# Start all services
./scripts/start.sh

# Check status and health
./scripts/status.sh

# Stop all services
./scripts/stop.sh

# Restart services
./scripts/restart.sh
```

### Logs

```bash
# View all logs (live)
./scripts/logs.sh

# View specific service
./scripts/logs.sh airflow-webserver
./scripts/logs.sh airflow-scheduler
./scripts/logs.sh postgres
```

### Cleanup

```bash
# Remove logs and database (preserves DAGs, plugins, utils)
./scripts/cleanup.sh
```

## 🧪 Testing Your Setup

### Run the Test DAG

1. Start Airflow: `./scripts/start.sh`
2. Go to http://localhost:8080
3. Find **test_dag_example** in the DAG list
4. Click "Trigger DAG"
5. Watch it test all custom modules

### Manual Testing

```bash
# Test imports in container
cd ~/airflow-podman
podman-compose exec airflow-webserver python << 'EOF'
from utils.helpers.data_helper import DataHelper
from utils.validators.data_validator import DataValidator
from plugins.operators.custom_bash_operator import CustomBashOperator
print("✓ All imports successful!")
EOF
```

## 🔍 Debugging

### Check Container Logs

```bash
# All services
podman-compose logs

# Specific service
podman logs airflow-webserver
podman logs airflow-scheduler
```

### Verify Python Path

```bash
podman-compose exec airflow-webserver env | grep PYTHONPATH
```

### Test Module Imports

```bash
podman-compose exec airflow-webserver python -c "
from utils.helpers.data_helper import DataHelper
print('DataHelper imported successfully')
"
```

### Check DAG Parsing Errors

```bash
podman-compose exec airflow-webserver airflow dags list-import-errors
```

## 📝 Creating New DAGs with Custom Modules

### Step 1: Create DAG File

```bash
cd ~/airflow-podman/dags/production
nano my_new_dag.py
```

### Step 2: Import Custom Modules

```python
from utils.helpers.data_helper import DataHelper
from utils.validators.data_validator import DataValidator
from plugins.operators.data_quality_operator import DataQualityOperator
```

### Step 3: Use in Tasks

```python
def my_task():
    data = DataHelper.read_csv('/path/to/data.csv')
    is_valid, errors = DataValidator.validate_required_fields(
        data[0], 
        ['id', 'name']
    )
    return is_valid
```

### Step 4: File appears in UI automatically

No restart needed - Airflow picks up new DAGs automatically!

## 🎓 Best Practices

### 1. Organize DAGs by Purpose

```
dags/
├── examples/    # Learning and testing
├── production/  # Live workflows
└── testing/     # Validation and tests
```

### 2. Use Utils for Reusable Logic

Instead of duplicating code across DAGs, create util functions:

```python
# In utils/helpers/my_helper.py
def common_transformation(data):
    # Shared logic here
    return transformed_data

# In multiple DAGs
from utils.helpers.my_helper import common_transformation
```

### 3. Create Custom Operators for Patterns

If you do the same thing often, make an operator:

```python
# In plugins/operators/my_operator.py
class MyCustomOperator(BaseOperator):
    def execute(self, context):
        # Your repeated pattern here
        pass
```

### 4. Add Quality Checks

Always validate data:

```python
quality_check = DataQualityOperator(
    task_id='validate',
    data_source=get_data,
    quality_checks=[
        {'check': lambda d: len(d) > 0, 'description': 'Not empty'},
        {'check': lambda d: all('id' in x for x in d), 'description': 'Has ID'},
    ]
)
```

## 🐛 Troubleshooting

### Import Errors

**Problem**: `ModuleNotFoundError: No module named 'utils'`

**Solution**: Check PYTHONPATH is set correctly in .env:
```bash
PYTHONPATH=/opt/airflow:/opt/airflow/utils:/opt/airflow/plugins
```

### Permission Errors

**Problem**: Permission denied errors in logs

**Solution**: Fix permissions:
```bash
cd ~/airflow-podman
sudo chown -R 50000:0 dags/ logs/ plugins/ utils/ config/
```

### DAG Not Appearing

**Problem**: New DAG doesn't show in UI

**Solution**: 
1. Check for syntax errors: `python dags/your_dag.py`
2. Check DAG parsing errors in UI or logs
3. Wait 30 seconds for DAG scan interval

### SELinux Issues

**Problem**: Containers can't read files

**Solution**:
```bash
sudo chcon -R -t container_file_t ~/airflow-podman/
sudo setsebool -P container_manage_cgroup on
```

## 📦 Volume Mount Persistence

All data is persisted through volume mounts:

| Directory | Purpose | Persisted |
|-----------|---------|-----------|
| dags/ | Your DAG files | ✅ Yes |
| plugins/ | Custom plugins | ✅ Yes |
| utils/ | Utility modules | ✅ Yes |
| logs/ | Execution logs | ✅ Yes |
| config/ | Configuration | ✅ Yes |
| postgres-db-volume | Database | ✅ Yes |

When you run `./scripts/cleanup.sh`, it removes logs and database but preserves your DAGs, plugins, and utils.

## 🔐 Security Notes

### Production Recommendations

1. **Change default password** immediately
2. **Use strong credentials** in `.env`
3. **Enable HTTPS** for web access
4. **Restrict network access** with firewall
5. **Use secrets management** for sensitive data
6. **Keep Airflow updated** regularly

### Change Admin Password

Edit `.env`:
```bash
AIRFLOW_ADMIN_PASSWORD=your-strong-password-here
```

Then restart:
```bash
./scripts/restart.sh
```

## 📚 Additional Resources

- **Airflow Documentation**: https://airflow.apache.org/docs/
- **Podman Documentation**: https://docs.podman.io/
- **Custom Modules**: See files in `utils/` and `plugins/` directories
- **Sample DAGs**: See files in `dags/examples/` directory

## 🆘 Support

For issues or questions:
1. Check logs: `./scripts/logs.sh`
2. Check status: `./scripts/status.sh`
3. Review sample DAGs for working examples
4. Check Airflow documentation

## 📄 License

This installation script is provided as-is for Apache Airflow deployment on RHEL systems.
