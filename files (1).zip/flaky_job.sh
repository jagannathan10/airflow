#!/bin/bash

# ══════════════════════════════════════════════════════════════
# flaky_job.sh — Simulates a Flaky Job (FOR TESTING RETRIES)
# ══════════════════════════════════════════════════════════════
# This script randomly succeeds or fails to test the retry
# logic in cron_wrapper.sh. 
#
# Usage:
#   ./flaky_job.sh              # 50% chance of failure
#   ./flaky_job.sh 80           # 80% chance of failure
#   ./flaky_job.sh 0            # always succeeds
#   ./flaky_job.sh 100          # always fails
# ══════════════════════════════════════════════════════════════

FAIL_PERCENT=${1:-50}       # Default: 50% chance to fail
WORK_SECONDS=${2:-3}        # Default: simulate 3 seconds of work

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [FLAKY_JOB] $1"
}

log "Starting flaky job (fail_rate=${FAIL_PERCENT}%)..."
log "Simulating work for ${WORK_SECONDS} seconds..."

# Simulate doing some work
sleep "$WORK_SECONDS"

# Generate random number 1-100
ROLL=$(( RANDOM % 100 + 1 ))

log "Random roll: ${ROLL} (need > ${FAIL_PERCENT} to succeed)"

if [ "$ROLL" -le "$FAIL_PERCENT" ]; then
    log "BOOM! Simulated failure (rolled ${ROLL} ≤ ${FAIL_PERCENT})"
    log "Error: Connection refused to imaginary-service.local:9999"
    exit 1
else
    log "Job completed successfully (rolled ${ROLL} > ${FAIL_PERCENT})"
    log "Processed 42 records in ${WORK_SECONDS}s"
    exit 0
fi
