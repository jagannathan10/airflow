#!/bin/bash

################################################################################
# Apache Airflow Installation Script for RHEL 8/9 with Podman Compose
# Enhanced with Custom Plugins, Utils, and Sample DAGs
################################################################################

set -e

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration variables
INSTALL_DIR="${HOME}/airflow-podman"
AIRFLOW_VERSION="2.8.1"
AIRFLOW_UID=50000
AIRFLOW_GID=0
POSTGRES_VERSION="13"

# Functions
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_rhel_version() {
    print_info "Checking RHEL version..."
    if [ -f /etc/redhat-release ]; then
        RHEL_VERSION=$(grep -oE '[0-9]+' /etc/redhat-release | head -1)
        if [ "$RHEL_VERSION" -eq 8 ] || [ "$RHEL_VERSION" -eq 9 ]; then
            print_success "RHEL $RHEL_VERSION detected"
        else
            print_error "This script supports RHEL 8 and 9 only"
            exit 1
        fi
    else
        print_error "This does not appear to be a RHEL system"
        exit 1
    fi
}

install_dependencies() {
    print_info "Installing Podman and dependencies..."
    
    sudo dnf install -y podman python3-pip curl
    
    # Install podman-compose
    print_info "Installing podman-compose..."
    pip3 install --user podman-compose
    
    # Add to PATH if not already there
    if ! command -v podman-compose &> /dev/null; then
        export PATH="$HOME/.local/bin:$PATH"
        echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
    fi
    
    print_success "Dependencies installed successfully"
}

verify_installations() {
    print_info "Verifying installations..."
    
    if ! command -v podman &> /dev/null; then
        print_error "Podman installation failed"
        exit 1
    fi
    
    if ! command -v podman-compose &> /dev/null; then
        print_error "Podman-compose installation failed"
        exit 1
    fi
    
    print_success "Podman version: $(podman --version)"
    print_success "Podman-compose version: $(podman-compose --version)"
}

create_directory_structure() {
    print_info "Creating directory structure at $INSTALL_DIR..."
    
    mkdir -p "$INSTALL_DIR"/{dags,logs,plugins,config,scripts,utils}
    mkdir -p "$INSTALL_DIR/plugins"/{operators,sensors,hooks}
    mkdir -p "$INSTALL_DIR/utils"/{helpers,validators,transformers}
    mkdir -p "$INSTALL_DIR/dags"/{examples,production,testing}
    
    cd "$INSTALL_DIR"
    
    print_success "Directory structure created"
}

create_env_file() {
    print_info "Creating environment file..."
    
    cat > "$INSTALL_DIR/.env" << EOF
# ==============================================================================
# AIRFLOW CONFIGURATION
# ==============================================================================

# Airflow Core Settings
AIRFLOW_UID=$AIRFLOW_UID
AIRFLOW_GID=$AIRFLOW_GID
AIRFLOW_IMAGE_NAME=apache/airflow:$AIRFLOW_VERSION
AIRFLOW_HOME=/opt/airflow

# Airflow Executor
AIRFLOW__CORE__EXECUTOR=LocalExecutor

# Airflow Webserver
AIRFLOW__WEBSERVER__EXPOSE_CONFIG=true
AIRFLOW__WEBSERVER__RBAC=true
AIRFLOW__WEBSERVER__SECRET_KEY=your-secret-key-change-this-in-production

# DAG Settings
AIRFLOW__CORE__DAGS_ARE_PAUSED_AT_CREATION=true
AIRFLOW__CORE__LOAD_EXAMPLES=false
AIRFLOW__CORE__DAGS_FOLDER=/opt/airflow/dags
AIRFLOW__CORE__PLUGINS_FOLDER=/opt/airflow/plugins

# Scheduler Settings
AIRFLOW__SCHEDULER__ENABLE_HEALTH_CHECK=true
AIRFLOW__SCHEDULER__DAG_DIR_LIST_INTERVAL=30
AIRFLOW__SCHEDULER__MIN_FILE_PROCESS_INTERVAL=30

# Logging
AIRFLOW__LOGGING__BASE_LOG_FOLDER=/opt/airflow/logs
AIRFLOW__LOGGING__DAG_PROCESSOR_MANAGER_LOG_LOCATION=/opt/airflow/logs/dag_processor_manager/dag_processor_manager.log

# API Settings
AIRFLOW__API__AUTH_BACKENDS=airflow.api.auth.backend.basic_auth,airflow.api.auth.backend.session

# ==============================================================================
# DATABASE CONFIGURATION
# ==============================================================================

POSTGRES_USER=airflow
POSTGRES_PASSWORD=airflow
POSTGRES_DB=airflow
POSTGRES_VERSION=$POSTGRES_VERSION
AIRFLOW__DATABASE__SQL_ALCHEMY_CONN=postgresql+psycopg2://airflow:airflow@postgres/airflow
AIRFLOW__CORE__SQL_ALCHEMY_CONN=postgresql+psycopg2://airflow:airflow@postgres/airflow

# ==============================================================================
# ADMIN USER CONFIGURATION
# ==============================================================================

AIRFLOW_ADMIN_USERNAME=admin
AIRFLOW_ADMIN_PASSWORD=admin
AIRFLOW_ADMIN_EMAIL=admin@example.com
AIRFLOW_ADMIN_FIRSTNAME=Admin
AIRFLOW_ADMIN_LASTNAME=User

# ==============================================================================
# CUSTOM SETTINGS
# ==============================================================================

# Timezone
AIRFLOW__CORE__DEFAULT_TIMEZONE=UTC

# Email Settings (Configure for production)
AIRFLOW__EMAIL__EMAIL_BACKEND=airflow.utils.email.send_email_smtp
AIRFLOW__SMTP__SMTP_HOST=localhost
AIRFLOW__SMTP__SMTP_PORT=25
AIRFLOW__SMTP__SMTP_USER=
AIRFLOW__SMTP__SMTP_PASSWORD=
AIRFLOW__SMTP__SMTP_MAIL_FROM=airflow@example.com

# Security
AIRFLOW__CORE__FERNET_KEY=

# Parallelism
AIRFLOW__CORE__PARALLELISM=32
AIRFLOW__CORE__DAG_CONCURRENCY=16
AIRFLOW__CORE__MAX_ACTIVE_RUNS_PER_DAG=16

# Custom Python Path (for utils)
PYTHONPATH=/opt/airflow:/opt/airflow/utils:/opt/airflow/plugins

# ==============================================================================
# DEVELOPMENT/PRODUCTION TOGGLE
# ==============================================================================

AIRFLOW_ENV=development
# Set to 'production' for production deployments
EOF
    
    print_success "Environment file created"
}

create_compose_file() {
    print_info "Creating podman-compose.yml..."
    
    cat > "$INSTALL_DIR/podman-compose.yml" << 'EOF'
version: '3.8'

x-airflow-common:
  &airflow-common
  image: ${AIRFLOW_IMAGE_NAME:-apache/airflow:2.8.1}
  environment:
    &airflow-common-env
    # Core
    AIRFLOW__CORE__EXECUTOR: ${AIRFLOW__CORE__EXECUTOR:-LocalExecutor}
    AIRFLOW__DATABASE__SQL_ALCHEMY_CONN: ${AIRFLOW__DATABASE__SQL_ALCHEMY_CONN}
    AIRFLOW__CORE__SQL_ALCHEMY_CONN: ${AIRFLOW__CORE__SQL_ALCHEMY_CONN}
    AIRFLOW__CORE__FERNET_KEY: ${AIRFLOW__CORE__FERNET_KEY:-}
    AIRFLOW__CORE__DAGS_ARE_PAUSED_AT_CREATION: ${AIRFLOW__CORE__DAGS_ARE_PAUSED_AT_CREATION:-true}
    AIRFLOW__CORE__LOAD_EXAMPLES: ${AIRFLOW__CORE__LOAD_EXAMPLES:-false}
    
    # API
    AIRFLOW__API__AUTH_BACKENDS: ${AIRFLOW__API__AUTH_BACKENDS}
    
    # Scheduler
    AIRFLOW__SCHEDULER__ENABLE_HEALTH_CHECK: ${AIRFLOW__SCHEDULER__ENABLE_HEALTH_CHECK:-true}
    AIRFLOW__SCHEDULER__DAG_DIR_LIST_INTERVAL: ${AIRFLOW__SCHEDULER__DAG_DIR_LIST_INTERVAL:-30}
    AIRFLOW__SCHEDULER__MIN_FILE_PROCESS_INTERVAL: ${AIRFLOW__SCHEDULER__MIN_FILE_PROCESS_INTERVAL:-30}
    
    # Webserver
    AIRFLOW__WEBSERVER__EXPOSE_CONFIG: ${AIRFLOW__WEBSERVER__EXPOSE_CONFIG:-true}
    AIRFLOW__WEBSERVER__RBAC: ${AIRFLOW__WEBSERVER__RBAC:-true}
    AIRFLOW__WEBSERVER__SECRET_KEY: ${AIRFLOW__WEBSERVER__SECRET_KEY}
    
    # Paths
    AIRFLOW__CORE__DAGS_FOLDER: ${AIRFLOW__CORE__DAGS_FOLDER:-/opt/airflow/dags}
    AIRFLOW__CORE__PLUGINS_FOLDER: ${AIRFLOW__CORE__PLUGINS_FOLDER:-/opt/airflow/plugins}
    AIRFLOW__LOGGING__BASE_LOG_FOLDER: ${AIRFLOW__LOGGING__BASE_LOG_FOLDER:-/opt/airflow/logs}
    
    # Parallelism
    AIRFLOW__CORE__PARALLELISM: ${AIRFLOW__CORE__PARALLELISM:-32}
    AIRFLOW__CORE__DAG_CONCURRENCY: ${AIRFLOW__CORE__DAG_CONCURRENCY:-16}
    AIRFLOW__CORE__MAX_ACTIVE_RUNS_PER_DAG: ${AIRFLOW__CORE__MAX_ACTIVE_RUNS_PER_DAG:-16}
    
    # Python Path for custom utils
    PYTHONPATH: ${PYTHONPATH:-/opt/airflow:/opt/airflow/utils:/opt/airflow/plugins}
    
    # Environment
    AIRFLOW_ENV: ${AIRFLOW_ENV:-development}
    
  volumes:
    - ./dags:/opt/airflow/dags
    - ./logs:/opt/airflow/logs
    - ./plugins:/opt/airflow/plugins
    - ./config:/opt/airflow/config
    - ./utils:/opt/airflow/utils
  user: "${AIRFLOW_UID:-50000}:${AIRFLOW_GID:-0}"
  depends_on:
    postgres:
      condition: service_healthy

services:
  postgres:
    image: postgres:${POSTGRES_VERSION:-13}
    container_name: airflow-postgres
    environment:
      POSTGRES_USER: ${POSTGRES_USER:-airflow}
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD:-airflow}
      POSTGRES_DB: ${POSTGRES_DB:-airflow}
      PGDATA: /var/lib/postgresql/data/pgdata
    volumes:
      - postgres-db-volume:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD", "pg_isready", "-U", "${POSTGRES_USER:-airflow}"]
      interval: 10s
      retries: 5
      start_period: 5s
    restart: always
    ports:
      - "5432:5432"

  airflow-webserver:
    <<: *airflow-common
    container_name: airflow-webserver
    command: webserver
    ports:
      - "8080:8080"
    healthcheck:
      test: ["CMD", "curl", "--fail", "http://localhost:8080/health"]
      interval: 30s
      timeout: 10s
      retries: 5
      start_period: 30s
    restart: always
    depends_on:
      airflow-init:
        condition: service_completed_successfully

  airflow-scheduler:
    <<: *airflow-common
    container_name: airflow-scheduler
    command: scheduler
    healthcheck:
      test: ["CMD", "curl", "--fail", "http://localhost:8974/health"]
      interval: 30s
      timeout: 10s
      retries: 5
      start_period: 30s
    restart: always
    depends_on:
      airflow-init:
        condition: service_completed_successfully

  airflow-init:
    <<: *airflow-common
    container_name: airflow-init
    entrypoint: /bin/bash
    command:
      - -c
      - |
        echo "==========================================="
        echo "Initializing Airflow..."
        echo "==========================================="
        
        echo "Creating directories..."
        mkdir -p /sources/logs /sources/dags /sources/plugins /sources/config /sources/utils
        chown -R "${AIRFLOW_UID}:${AIRFLOW_GID}" /sources/{logs,dags,plugins,config,utils}
        
        echo "Checking database connection..."
        airflow db check || exit 1
        
        echo "Running database migrations..."
        airflow db migrate
        
        echo "Creating admin user..."
        airflow users create \
          --username ${AIRFLOW_ADMIN_USERNAME:-admin} \
          --firstname ${AIRFLOW_ADMIN_FIRSTNAME:-Admin} \
          --lastname ${AIRFLOW_ADMIN_LASTNAME:-User} \
          --role Admin \
          --email ${AIRFLOW_ADMIN_EMAIL:-admin@example.com} \
          --password ${AIRFLOW_ADMIN_PASSWORD:-admin} 2>/dev/null || echo "User already exists"
        
        echo "==========================================="
        echo "Initialization complete!"
        echo "==========================================="
    environment:
      <<: *airflow-common-env
      _AIRFLOW_DB_MIGRATE: 'true'
      _AIRFLOW_WWW_USER_CREATE: 'true'
    user: "0:0"
    volumes:
      - .:/sources

volumes:
  postgres-db-volume:
EOF
    
    print_success "Compose file created"
}

create_custom_utils() {
    print_info "Creating custom utility modules..."
    
    # Create __init__.py files
    cat > "$INSTALL_DIR/utils/__init__.py" << 'EOF'
"""
Custom Utility Modules for Airflow
"""
__version__ = "1.0.0"
EOF

    cat > "$INSTALL_DIR/utils/helpers/__init__.py" << 'EOF'
"""Helper utilities"""
from .data_helper import DataHelper
from .date_helper import DateHelper
from .notification_helper import NotificationHelper

__all__ = ['DataHelper', 'DateHelper', 'NotificationHelper']
EOF

    cat > "$INSTALL_DIR/utils/validators/__init__.py" << 'EOF'
"""Data validators"""
from .data_validator import DataValidator
from .schema_validator import SchemaValidator

__all__ = ['DataValidator', 'SchemaValidator']
EOF

    cat > "$INSTALL_DIR/utils/transformers/__init__.py" << 'EOF'
"""Data transformers"""
from .data_transformer import DataTransformer

__all__ = ['DataTransformer']
EOF

    # Create data_helper.py
    cat > "$INSTALL_DIR/utils/helpers/data_helper.py" << 'EOF'
"""
Data Helper Utilities
"""
import json
import csv
from typing import List, Dict, Any
from pathlib import Path


class DataHelper:
    """Helper class for common data operations"""
    
    @staticmethod
    def read_json(file_path: str) -> Dict[str, Any]:
        """Read JSON file"""
        with open(file_path, 'r') as f:
            return json.load(f)
    
    @staticmethod
    def write_json(data: Dict[str, Any], file_path: str) -> None:
        """Write JSON file"""
        with open(file_path, 'w') as f:
            json.dump(data, f, indent=2)
    
    @staticmethod
    def read_csv(file_path: str) -> List[Dict[str, Any]]:
        """Read CSV file and return list of dictionaries"""
        with open(file_path, 'r') as f:
            reader = csv.DictReader(f)
            return list(reader)
    
    @staticmethod
    def write_csv(data: List[Dict[str, Any]], file_path: str) -> None:
        """Write list of dictionaries to CSV file"""
        if not data:
            return
        
        with open(file_path, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=data[0].keys())
            writer.writeheader()
            writer.writerows(data)
    
    @staticmethod
    def ensure_directory(path: str) -> None:
        """Ensure directory exists"""
        Path(path).mkdir(parents=True, exist_ok=True)
    
    @staticmethod
    def chunk_list(lst: List[Any], chunk_size: int) -> List[List[Any]]:
        """Split list into chunks"""
        return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]
EOF

    # Create date_helper.py
    cat > "$INSTALL_DIR/utils/helpers/date_helper.py" << 'EOF'
"""
Date Helper Utilities
"""
from datetime import datetime, timedelta
from typing import Optional


class DateHelper:
    """Helper class for date operations"""
    
    @staticmethod
    def get_date_range(start_date: str, end_date: str, format: str = "%Y-%m-%d") -> list:
        """Get list of dates between start and end"""
        start = datetime.strptime(start_date, format)
        end = datetime.strptime(end_date, format)
        
        dates = []
        current = start
        while current <= end:
            dates.append(current.strftime(format))
            current += timedelta(days=1)
        
        return dates
    
    @staticmethod
    def add_days(date_str: str, days: int, format: str = "%Y-%m-%d") -> str:
        """Add days to a date string"""
        date = datetime.strptime(date_str, format)
        new_date = date + timedelta(days=days)
        return new_date.strftime(format)
    
    @staticmethod
    def get_current_timestamp(format: str = "%Y-%m-%d %H:%M:%S") -> str:
        """Get current timestamp"""
        return datetime.now().strftime(format)
    
    @staticmethod
    def parse_date(date_str: str, input_format: str, output_format: str) -> str:
        """Parse date from one format to another"""
        date = datetime.strptime(date_str, input_format)
        return date.strftime(output_format)
    
    @staticmethod
    def is_weekend(date_str: str, format: str = "%Y-%m-%d") -> bool:
        """Check if date is weekend"""
        date = datetime.strptime(date_str, format)
        return date.weekday() >= 5  # Saturday = 5, Sunday = 6
EOF

    # Create notification_helper.py
    cat > "$INSTALL_DIR/utils/helpers/notification_helper.py" << 'EOF'
"""
Notification Helper Utilities
"""
import logging
from typing import Optional, Dict, Any

logger = logging.getLogger(__name__)


class NotificationHelper:
    """Helper class for sending notifications"""
    
    @staticmethod
    def log_success(message: str, context: Optional[Dict[str, Any]] = None) -> None:
        """Log success message"""
        if context:
            logger.info(f"SUCCESS: {message} | Context: {context}")
        else:
            logger.info(f"SUCCESS: {message}")
    
    @staticmethod
    def log_error(message: str, error: Optional[Exception] = None, context: Optional[Dict[str, Any]] = None) -> None:
        """Log error message"""
        error_msg = f"ERROR: {message}"
        if error:
            error_msg += f" | Error: {str(error)}"
        if context:
            error_msg += f" | Context: {context}"
        logger.error(error_msg)
    
    @staticmethod
    def log_warning(message: str, context: Optional[Dict[str, Any]] = None) -> None:
        """Log warning message"""
        if context:
            logger.warning(f"WARNING: {message} | Context: {context}")
        else:
            logger.warning(f"WARNING: {message}")
    
    @staticmethod
    def format_slack_message(title: str, message: str, status: str = "info") -> Dict[str, Any]:
        """Format message for Slack (example structure)"""
        emoji_map = {
            "success": ":white_check_mark:",
            "error": ":x:",
            "warning": ":warning:",
            "info": ":information_source:"
        }
        
        return {
            "text": f"{emoji_map.get(status, ':information_source:')} *{title}*",
            "blocks": [
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": f"{emoji_map.get(status, ':information_source:')} *{title}*\n{message}"
                    }
                }
            ]
        }
EOF

    # Create data_validator.py
    cat > "$INSTALL_DIR/utils/validators/data_validator.py" << 'EOF'
"""
Data Validation Utilities
"""
from typing import Any, List, Dict, Optional
import re


class DataValidator:
    """Class for data validation"""
    
    @staticmethod
    def is_not_empty(value: Any) -> bool:
        """Check if value is not empty"""
        if value is None:
            return False
        if isinstance(value, str):
            return bool(value.strip())
        if isinstance(value, (list, dict)):
            return len(value) > 0
        return True
    
    @staticmethod
    def is_valid_email(email: str) -> bool:
        """Validate email format"""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(pattern, email))
    
    @staticmethod
    def is_in_range(value: float, min_val: float, max_val: float) -> bool:
        """Check if value is in range"""
        return min_val <= value <= max_val
    
    @staticmethod
    def validate_required_fields(data: Dict[str, Any], required_fields: List[str]) -> tuple[bool, List[str]]:
        """
        Validate that all required fields are present and not empty
        Returns: (is_valid, missing_fields)
        """
        missing = []
        for field in required_fields:
            if field not in data or not DataValidator.is_not_empty(data[field]):
                missing.append(field)
        
        return len(missing) == 0, missing
    
    @staticmethod
    def validate_data_types(data: Dict[str, Any], type_map: Dict[str, type]) -> tuple[bool, List[str]]:
        """
        Validate data types
        Returns: (is_valid, invalid_fields)
        """
        invalid = []
        for field, expected_type in type_map.items():
            if field in data and not isinstance(data[field], expected_type):
                invalid.append(f"{field} (expected {expected_type.__name__}, got {type(data[field]).__name__})")
        
        return len(invalid) == 0, invalid
EOF

    # Create schema_validator.py
    cat > "$INSTALL_DIR/utils/validators/schema_validator.py" << 'EOF'
"""
Schema Validation Utilities
"""
from typing import Dict, Any, List


class SchemaValidator:
    """Validate data against schemas"""
    
    @staticmethod
    def validate_schema(data: Dict[str, Any], schema: Dict[str, Any]) -> tuple[bool, List[str]]:
        """
        Validate data against a simple schema
        Schema format: {'field_name': {'type': type, 'required': bool}}
        """
        errors = []
        
        for field, rules in schema.items():
            # Check required
            if rules.get('required', False) and field not in data:
                errors.append(f"Missing required field: {field}")
                continue
            
            # Check type if field exists
            if field in data:
                expected_type = rules.get('type')
                if expected_type and not isinstance(data[field], expected_type):
                    errors.append(
                        f"Invalid type for {field}: expected {expected_type.__name__}, "
                        f"got {type(data[field]).__name__}"
                    )
        
        return len(errors) == 0, errors
    
    @staticmethod
    def create_simple_schema(fields: Dict[str, type], required: List[str] = None) -> Dict[str, Any]:
        """Helper to create a simple schema"""
        schema = {}
        required = required or []
        
        for field, field_type in fields.items():
            schema[field] = {
                'type': field_type,
                'required': field in required
            }
        
        return schema
EOF

    # Create data_transformer.py
    cat > "$INSTALL_DIR/utils/transformers/data_transformer.py" << 'EOF'
"""
Data Transformation Utilities
"""
from typing import List, Dict, Any, Callable


class DataTransformer:
    """Class for data transformations"""
    
    @staticmethod
    def normalize_keys(data: Dict[str, Any], key_transform: Callable[[str], str] = None) -> Dict[str, Any]:
        """Normalize dictionary keys"""
        if key_transform is None:
            key_transform = lambda k: k.lower().replace(' ', '_')
        
        return {key_transform(k): v for k, v in data.items()}
    
    @staticmethod
    def filter_fields(data: Dict[str, Any], fields: List[str]) -> Dict[str, Any]:
        """Filter dictionary to only include specified fields"""
        return {k: v for k, v in data.items() if k in fields}
    
    @staticmethod
    def rename_fields(data: Dict[str, Any], field_map: Dict[str, str]) -> Dict[str, Any]:
        """Rename fields in dictionary"""
        result = data.copy()
        for old_name, new_name in field_map.items():
            if old_name in result:
                result[new_name] = result.pop(old_name)
        return result
    
    @staticmethod
    def flatten_dict(data: Dict[str, Any], parent_key: str = '', sep: str = '_') -> Dict[str, Any]:
        """Flatten nested dictionary"""
        items = []
        for k, v in data.items():
            new_key = f"{parent_key}{sep}{k}" if parent_key else k
            if isinstance(v, dict):
                items.extend(DataTransformer.flatten_dict(v, new_key, sep=sep).items())
            else:
                items.append((new_key, v))
        return dict(items)
    
    @staticmethod
    def apply_transformation(data: List[Dict[str, Any]], transform_func: Callable) -> List[Dict[str, Any]]:
        """Apply transformation function to list of dictionaries"""
        return [transform_func(item) for item in data]
EOF

    print_success "Custom utility modules created"
}

create_custom_plugins() {
    print_info "Creating custom plugins..."
    
    # Create __init__.py files
    cat > "$INSTALL_DIR/plugins/__init__.py" << 'EOF'
"""
Custom Airflow Plugins
"""
from airflow.plugins_manager import AirflowPlugin

__version__ = "1.0.0"
EOF

    cat > "$INSTALL_DIR/plugins/operators/__init__.py" << 'EOF'
"""Custom Operators"""
from .custom_bash_operator import CustomBashOperator
from .data_quality_operator import DataQualityOperator

__all__ = ['CustomBashOperator', 'DataQualityOperator']
EOF

    cat > "$INSTALL_DIR/plugins/sensors/__init__.py" << 'EOF'
"""Custom Sensors"""
from .file_sensor import CustomFileSensor

__all__ = ['CustomFileSensor']
EOF

    cat > "$INSTALL_DIR/plugins/hooks/__init__.py" << 'EOF'
"""Custom Hooks"""
from .custom_http_hook import CustomHttpHook

__all__ = ['CustomHttpHook']
EOF

    # Create CustomBashOperator
    cat > "$INSTALL_DIR/plugins/operators/custom_bash_operator.py" << 'EOF'
"""
Custom Bash Operator with enhanced logging
"""
from airflow.operators.bash import BashOperator
from airflow.utils.decorators import apply_defaults
import logging

logger = logging.getLogger(__name__)


class CustomBashOperator(BashOperator):
    """
    Enhanced BashOperator with additional logging and error handling
    """
    
    @apply_defaults
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
    
    def execute(self, context):
        """Execute with enhanced logging"""
        logger.info(f"Executing CustomBashOperator: {self.task_id}")
        logger.info(f"Command: {self.bash_command}")
        
        try:
            result = super().execute(context)
            logger.info(f"Command executed successfully: {self.task_id}")
            return result
        except Exception as e:
            logger.error(f"Command failed: {self.task_id} | Error: {str(e)}")
            raise
EOF

    # Create DataQualityOperator
    cat > "$INSTALL_DIR/plugins/operators/data_quality_operator.py" << 'EOF'
"""
Data Quality Operator
"""
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults
from typing import List, Callable, Any
import logging

logger = logging.getLogger(__name__)


class DataQualityOperator(BaseOperator):
    """
    Operator to perform data quality checks
    """
    
    @apply_defaults
    def __init__(
        self,
        data_source: Callable,
        quality_checks: List[dict],
        *args,
        **kwargs
    ):
        """
        Args:
            data_source: Callable that returns data to check
            quality_checks: List of quality check definitions
                Format: [{'check': callable, 'description': str, 'fail_on_error': bool}]
        """
        super().__init__(*args, **kwargs)
        self.data_source = data_source
        self.quality_checks = quality_checks
    
    def execute(self, context):
        """Execute quality checks"""
        logger.info(f"Starting data quality checks for {self.task_id}")
        
        # Get data
        data = self.data_source()
        logger.info(f"Retrieved data for quality checks")
        
        # Run checks
        failed_checks = []
        for check in self.quality_checks:
            check_func = check['check']
            description = check.get('description', 'Unnamed check')
            fail_on_error = check.get('fail_on_error', True)
            
            logger.info(f"Running check: {description}")
            
            try:
                result = check_func(data)
                if result:
                    logger.info(f"✓ Check passed: {description}")
                else:
                    logger.warning(f"✗ Check failed: {description}")
                    if fail_on_error:
                        failed_checks.append(description)
            except Exception as e:
                logger.error(f"✗ Check error: {description} | Error: {str(e)}")
                if fail_on_error:
                    failed_checks.append(description)
        
        # Report results
        if failed_checks:
            error_msg = f"Data quality checks failed: {', '.join(failed_checks)}"
            logger.error(error_msg)
            raise ValueError(error_msg)
        
        logger.info(f"All data quality checks passed for {self.task_id}")
        return True
EOF

    # Create CustomFileSensor
    cat > "$INSTALL_DIR/plugins/sensors/file_sensor.py" << 'EOF'
"""
Custom File Sensor
"""
from airflow.sensors.base import BaseSensorOperator
from airflow.utils.decorators import apply_defaults
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class CustomFileSensor(BaseSensorOperator):
    """
    Sensor that waits for a file to exist
    """
    
    @apply_defaults
    def __init__(
        self,
        filepath: str,
        check_size: bool = False,
        min_size: int = 0,
        *args,
        **kwargs
    ):
        """
        Args:
            filepath: Path to file to check
            check_size: Whether to check file size
            min_size: Minimum file size in bytes
        """
        super().__init__(*args, **kwargs)
        self.filepath = filepath
        self.check_size = check_size
        self.min_size = min_size
    
    def poke(self, context):
        """Check if file exists and meets criteria"""
        path = Path(self.filepath)
        
        if not path.exists():
            logger.info(f"File does not exist: {self.filepath}")
            return False
        
        if self.check_size:
            size = path.stat().st_size
            if size < self.min_size:
                logger.info(f"File exists but too small: {size} bytes < {self.min_size} bytes")
                return False
        
        logger.info(f"File found: {self.filepath}")
        return True
EOF

    # Create CustomHttpHook
    cat > "$INSTALL_DIR/plugins/hooks/custom_http_hook.py" << 'EOF'
"""
Custom HTTP Hook
"""
from airflow.hooks.base import BaseHook
from typing import Dict, Any, Optional
import requests
import logging

logger = logging.getLogger(__name__)


class CustomHttpHook(BaseHook):
    """
    Custom HTTP Hook with retry logic
    """
    
    def __init__(
        self,
        base_url: str,
        headers: Optional[Dict[str, str]] = None,
        timeout: int = 30
    ):
        """
        Args:
            base_url: Base URL for API
            headers: Default headers
            timeout: Request timeout in seconds
        """
        self.base_url = base_url.rstrip('/')
        self.headers = headers or {}
        self.timeout = timeout
    
    def get(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Make GET request"""
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        logger.info(f"GET request to: {url}")
        
        response = requests.get(
            url,
            params=params,
            headers=self.headers,
            timeout=self.timeout
        )
        response.raise_for_status()
        
        return response.json()
    
    def post(self, endpoint: str, data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Make POST request"""
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        logger.info(f"POST request to: {url}")
        
        response = requests.post(
            url,
            json=data,
            headers=self.headers,
            timeout=self.timeout
        )
        response.raise_for_status()
        
        return response.json()
EOF

    print_success "Custom plugins created"
}

create_sample_dags() {
    print_info "Creating sample DAGs..."
    
    # Example 1: Basic DAG
    cat > "$INSTALL_DIR/dags/examples/01_basic_example.py" << 'EOF'
"""
Basic Airflow DAG Example
Demonstrates: Basic operators and task dependencies
"""
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator

def print_hello():
    """Simple Python function"""
    print("Hello from Airflow!")
    return "Hello World"

def print_context(**context):
    """Print context information"""
    print(f"Execution date: {context['execution_date']}")
    print(f"DAG: {context['dag']}")
    print(f"Task: {context['task']}")
    return "Context printed"

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    '01_basic_example',
    default_args=default_args,
    description='Basic Airflow DAG example',
    schedule_interval=timedelta(days=1),
    catchup=False,
    tags=['example', 'basic'],
) as dag:

    start = BashOperator(
        task_id='start',
        bash_command='echo "Starting DAG execution"',
    )

    hello = PythonOperator(
        task_id='hello',
        python_callable=print_hello,
    )

    context = PythonOperator(
        task_id='print_context',
        python_callable=print_context,
    )

    end = BashOperator(
        task_id='end',
        bash_command='echo "DAG execution complete"',
    )

    start >> [hello, context] >> end
EOF

    # Example 2: Using Custom Utils
    cat > "$INSTALL_DIR/dags/examples/02_custom_utils_example.py" << 'EOF'
"""
Custom Utils Example
Demonstrates: Using custom utility modules
"""
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator

# Import custom utils
from utils.helpers.data_helper import DataHelper
from utils.helpers.date_helper import DateHelper
from utils.validators.data_validator import DataValidator

def use_data_helper(**context):
    """Demonstrate DataHelper usage"""
    print("Using DataHelper...")
    
    # Create sample data
    data = {'name': 'Test', 'value': 123}
    
    # Write JSON
    DataHelper.write_json(data, '/tmp/test.json')
    
    # Read JSON
    loaded_data = DataHelper.read_json('/tmp/test.json')
    print(f"Loaded data: {loaded_data}")
    
    return "DataHelper demo complete"

def use_date_helper(**context):
    """Demonstrate DateHelper usage"""
    print("Using DateHelper...")
    
    # Get date range
    dates = DateHelper.get_date_range('2024-01-01', '2024-01-05')
    print(f"Date range: {dates}")
    
    # Add days
    new_date = DateHelper.add_days('2024-01-01', 10)
    print(f"Date + 10 days: {new_date}")
    
    # Check weekend
    is_weekend = DateHelper.is_weekend('2024-01-06')
    print(f"Is weekend: {is_weekend}")
    
    return "DateHelper demo complete"

def use_validator(**context):
    """Demonstrate DataValidator usage"""
    print("Using DataValidator...")
    
    # Test data
    test_data = {
        'email': 'test@example.com',
        'name': 'John Doe',
        'age': 25
    }
    
    # Validate email
    is_valid = DataValidator.is_valid_email(test_data['email'])
    print(f"Email valid: {is_valid}")
    
    # Validate required fields
    required = ['email', 'name', 'age']
    is_valid, missing = DataValidator.validate_required_fields(test_data, required)
    print(f"All fields present: {is_valid}")
    
    return "Validator demo complete"

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    '02_custom_utils_example',
    default_args=default_args,
    description='Demonstrates custom utility usage',
    schedule_interval=timedelta(days=1),
    catchup=False,
    tags=['example', 'utils'],
) as dag:

    data_task = PythonOperator(
        task_id='use_data_helper',
        python_callable=use_data_helper,
    )

    date_task = PythonOperator(
        task_id='use_date_helper',
        python_callable=use_date_helper,
    )

    validator_task = PythonOperator(
        task_id='use_validator',
        python_callable=use_validator,
    )

    data_task >> date_task >> validator_task
EOF

    # Example 3: Using Custom Plugins
    cat > "$INSTALL_DIR/dags/examples/03_custom_plugins_example.py" << 'EOF'
"""
Custom Plugins Example
Demonstrates: Using custom operators, sensors, and hooks
"""
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator

# Import custom plugins
from plugins.operators.custom_bash_operator import CustomBashOperator
from plugins.operators.data_quality_operator import DataQualityOperator

def get_sample_data():
    """Return sample data for quality checks"""
    return [
        {'id': 1, 'value': 100, 'name': 'Item 1'},
        {'id': 2, 'value': 200, 'name': 'Item 2'},
        {'id': 3, 'value': 300, 'name': 'Item 3'},
    ]

def check_not_empty(data):
    """Check if data is not empty"""
    return len(data) > 0

def check_all_have_id(data):
    """Check if all items have id field"""
    return all('id' in item for item in data)

def check_values_positive(data):
    """Check if all values are positive"""
    return all(item.get('value', 0) > 0 for item in data)

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    '03_custom_plugins_example',
    default_args=default_args,
    description='Demonstrates custom plugin usage',
    schedule_interval=timedelta(days=1),
    catchup=False,
    tags=['example', 'plugins'],
) as dag:

    # Use CustomBashOperator
    custom_bash = CustomBashOperator(
        task_id='custom_bash',
        bash_command='echo "Using CustomBashOperator with enhanced logging"',
    )

    # Use DataQualityOperator
    quality_check = DataQualityOperator(
        task_id='data_quality_check',
        data_source=get_sample_data,
        quality_checks=[
            {
                'check': check_not_empty,
                'description': 'Data should not be empty',
                'fail_on_error': True
            },
            {
                'check': check_all_have_id,
                'description': 'All items should have id',
                'fail_on_error': True
            },
            {
                'check': check_values_positive,
                'description': 'All values should be positive',
                'fail_on_error': True
            },
        ],
    )

    custom_bash >> quality_check
EOF

    # Production Example: ETL Pipeline
    cat > "$INSTALL_DIR/dags/production/etl_pipeline_example.py" << 'EOF'
"""
Production ETL Pipeline Example
Demonstrates: Complete ETL workflow with error handling
"""
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator

from utils.helpers.data_helper import DataHelper
from utils.helpers.notification_helper import NotificationHelper
from utils.validators.data_validator import DataValidator
from utils.transformers.data_transformer import DataTransformer

def extract_data(**context):
    """Extract data from source"""
    try:
        # Simulate data extraction
        data = [
            {'ID': 1, 'First Name': 'John', 'Last Name': 'Doe', 'email': 'john@example.com'},
            {'ID': 2, 'First Name': 'Jane', 'Last Name': 'Smith', 'email': 'jane@example.com'},
        ]
        
        # Save extracted data
        DataHelper.write_json(data, '/tmp/extracted_data.json')
        
        NotificationHelper.log_success(
            "Data extracted successfully",
            context={'record_count': len(data)}
        )
        
        return len(data)
    except Exception as e:
        NotificationHelper.log_error("Data extraction failed", error=e)
        raise

def transform_data(**context):
    """Transform extracted data"""
    try:
        # Load extracted data
        data = DataHelper.read_json('/tmp/extracted_data.json')
        
        # Transform: normalize keys
        transformed = []
        for item in data:
            normalized = DataTransformer.normalize_keys(item)
            # Rename fields
            renamed = DataTransformer.rename_fields(
                normalized,
                {'first_name': 'fname', 'last_name': 'lname'}
            )
            transformed.append(renamed)
        
        # Save transformed data
        DataHelper.write_json(transformed, '/tmp/transformed_data.json')
        
        NotificationHelper.log_success(
            "Data transformed successfully",
            context={'record_count': len(transformed)}
        )
        
        return len(transformed)
    except Exception as e:
        NotificationHelper.log_error("Data transformation failed", error=e)
        raise

def validate_data(**context):
    """Validate transformed data"""
    try:
        # Load transformed data
        data = DataHelper.read_json('/tmp/transformed_data.json')
        
        # Validate each record
        errors = []
        for idx, record in enumerate(data):
            # Check required fields
            is_valid, missing = DataValidator.validate_required_fields(
                record,
                ['id', 'fname', 'lname', 'email']
            )
            
            if not is_valid:
                errors.append(f"Record {idx}: Missing fields {missing}")
            
            # Validate email
            if 'email' in record and not DataValidator.is_valid_email(record['email']):
                errors.append(f"Record {idx}: Invalid email")
        
        if errors:
            raise ValueError(f"Validation failed: {'; '.join(errors)}")
        
        NotificationHelper.log_success(
            "Data validation passed",
            context={'record_count': len(data)}
        )
        
        return True
    except Exception as e:
        NotificationHelper.log_error("Data validation failed", error=e)
        raise

def load_data(**context):
    """Load validated data to destination"""
    try:
        # Load transformed data
        data = DataHelper.read_json('/tmp/transformed_data.json')
        
        # Simulate loading to database/warehouse
        # In production, this would write to actual destination
        DataHelper.write_csv(data, '/tmp/final_data.csv')
        
        NotificationHelper.log_success(
            "Data loaded successfully",
            context={'record_count': len(data), 'destination': '/tmp/final_data.csv'}
        )
        
        return len(data)
    except Exception as e:
        NotificationHelper.log_error("Data loading failed", error=e)
        raise

default_args = {
    'owner': 'data-team',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 2,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    'etl_pipeline_example',
    default_args=default_args,
    description='Production ETL pipeline with error handling',
    schedule_interval='0 2 * * *',  # Run daily at 2 AM
    catchup=False,
    tags=['production', 'etl'],
) as dag:

    start = BashOperator(
        task_id='start_pipeline',
        bash_command='echo "Starting ETL pipeline at $(date)"',
    )

    extract = PythonOperator(
        task_id='extract_data',
        python_callable=extract_data,
    )

    transform = PythonOperator(
        task_id='transform_data',
        python_callable=transform_data,
    )

    validate = PythonOperator(
        task_id='validate_data',
        python_callable=validate_data,
    )

    load = PythonOperator(
        task_id='load_data',
        python_callable=load_data,
    )

    end = BashOperator(
        task_id='end_pipeline',
        bash_command='echo "ETL pipeline completed at $(date)"',
    )

    start >> extract >> transform >> validate >> load >> end
EOF

    # Testing Example
    cat > "$INSTALL_DIR/dags/testing/test_dag_example.py" << 'EOF'
"""
Test DAG Example
Demonstrates: Testing patterns and best practices
"""
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator

def test_imports():
    """Test that all custom modules can be imported"""
    try:
        from utils.helpers.data_helper import DataHelper
        from utils.helpers.date_helper import DateHelper
        from utils.validators.data_validator import DataValidator
        from utils.transformers.data_transformer import DataTransformer
        print("✓ All utils imported successfully")
        
        from plugins.operators.custom_bash_operator import CustomBashOperator
        from plugins.operators.data_quality_operator import DataQualityOperator
        print("✓ All plugins imported successfully")
        
        return True
    except Exception as e:
        print(f"✗ Import failed: {str(e)}")
        raise

def test_utils():
    """Test utility functions"""
    from utils.helpers.date_helper import DateHelper
    from utils.validators.data_validator import DataValidator
    
    # Test DateHelper
    dates = DateHelper.get_date_range('2024-01-01', '2024-01-03')
    assert len(dates) == 3, "DateHelper.get_date_range failed"
    print("✓ DateHelper.get_date_range passed")
    
    # Test DataValidator
    assert DataValidator.is_valid_email('test@example.com'), "Email validation failed"
    assert not DataValidator.is_valid_email('invalid-email'), "Email validation failed"
    print("✓ DataValidator.is_valid_email passed")
    
    return True

def test_transformers():
    """Test data transformers"""
    from utils.transformers.data_transformer import DataTransformer
    
    # Test normalize_keys
    data = {'First Name': 'John', 'Last Name': 'Doe'}
    normalized = DataTransformer.normalize_keys(data)
    assert 'first_name' in normalized, "normalize_keys failed"
    print("✓ DataTransformer.normalize_keys passed")
    
    # Test rename_fields
    renamed = DataTransformer.rename_fields(
        {'name': 'John', 'age': 30},
        {'name': 'full_name'}
    )
    assert 'full_name' in renamed, "rename_fields failed"
    print("✓ DataTransformer.rename_fields passed")
    
    return True

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    'test_dag_example',
    default_args=default_args,
    description='Test DAG for custom modules',
    schedule_interval=None,  # Manual trigger only
    catchup=False,
    tags=['testing', 'validation'],
) as dag:

    test_imports_task = PythonOperator(
        task_id='test_imports',
        python_callable=test_imports,
    )

    test_utils_task = PythonOperator(
        task_id='test_utils',
        python_callable=test_utils,
    )

    test_transformers_task = PythonOperator(
        task_id='test_transformers',
        python_callable=test_transformers,
    )

    test_imports_task >> test_utils_task >> test_transformers_task
EOF

    print_success "Sample DAGs created"
}

create_start_script() {
    print_info "Creating start script..."
    
    cat > "$INSTALL_DIR/scripts/start.sh" << 'EOF'
#!/bin/bash

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}Starting Apache Airflow with Custom Plugins & Utils...${NC}"

cd "$PROJECT_DIR"

# Check if containers are already running
if podman-compose ps | grep -q "Up"; then
    echo -e "${GREEN}Airflow is already running${NC}"
    podman-compose ps
    exit 0
fi

# Start services
echo "Starting all services..."
podman-compose up -d

# Wait for services to be healthy
echo "Waiting for services to be ready..."
sleep 15

# Check status
echo ""
echo -e "${GREEN}Container Status:${NC}"
podman-compose ps

echo ""
echo -e "${GREEN}Airflow is starting up!${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Web UI: http://localhost:8080"
echo "Username: admin"
echo "Password: admin"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Custom Features Enabled:"
echo "  ✓ Custom Utils (helpers, validators, transformers)"
echo "  ✓ Custom Plugins (operators, sensors, hooks)"
echo "  ✓ Sample DAGs (examples, production, testing)"
echo ""
echo "Directory Structure:"
echo "  dags/       - Your DAG files"
echo "  utils/      - Custom utility modules"
echo "  plugins/    - Custom Airflow plugins"
echo "  logs/       - Execution logs"
echo ""
echo "Available Commands:"
echo "  ./scripts/logs.sh     - View logs"
echo "  ./scripts/status.sh   - Check status"
echo "  ./scripts/stop.sh     - Stop services"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
EOF
    
    chmod +x "$INSTALL_DIR/scripts/start.sh"
    print_success "Start script created"
}

create_stop_script() {
    print_info "Creating stop script..."
    
    cat > "$INSTALL_DIR/scripts/stop.sh" << 'EOF'
#!/bin/bash

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}Stopping Apache Airflow...${NC}"

cd "$PROJECT_DIR"

# Stop all services
podman-compose down

echo -e "${RED}All services stopped${NC}"
echo ""
echo "To start again: ./scripts/start.sh"
echo "To cleanup data: ./scripts/cleanup.sh"
EOF
    
    chmod +x "$INSTALL_DIR/scripts/stop.sh"
    print_success "Stop script created"
}

create_cleanup_script() {
    print_info "Creating cleanup script..."
    
    cat > "$INSTALL_DIR/scripts/cleanup.sh" << 'EOF'
#!/bin/bash

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${RED}WARNING: This will remove all Airflow data!${NC}"
echo ""
echo "This will delete:"
echo "  - All execution logs"
echo "  - Database data"
echo "  - Temporary files"
echo ""
echo "This will NOT delete:"
echo "  - DAG files"
echo "  - Plugin files"
echo "  - Utility modules"
echo "  - Configuration files"
echo ""
read -p "Are you sure you want to continue? (yes/no): " confirm

if [ "$confirm" != "yes" ]; then
    echo "Cleanup cancelled"
    exit 0
fi

cd "$PROJECT_DIR"

echo -e "${YELLOW}Stopping all services...${NC}"
podman-compose down -v

echo -e "${YELLOW}Removing containers and volumes...${NC}"
podman-compose rm -f 2>/dev/null || true

echo -e "${YELLOW}Cleaning up directories...${NC}"
rm -rf logs/*
find dags/ -name "*.pyc" -delete
find dags/ -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null || true
find plugins/ -name "*.pyc" -delete
find plugins/ -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null || true
find utils/ -name "*.pyc" -delete
find utils/ -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null || true

echo -e "${YELLOW}Removing unused volumes...${NC}"
podman volume prune -f

echo ""
echo -e "${RED}Cleanup complete!${NC}"
echo "Logs and database data have been removed."
echo "DAGs, plugins, and utils are preserved."
echo ""
echo "To start fresh: ./scripts/start.sh"
EOF
    
    chmod +x "$INSTALL_DIR/scripts/cleanup.sh"
    print_success "Cleanup script created"
}

create_logs_script() {
    print_info "Creating logs script..."
    
    cat > "$INSTALL_DIR/scripts/logs.sh" << 'EOF'
#!/bin/bash

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_DIR"

SERVICE=${1:-}

if [ -z "$SERVICE" ]; then
    echo "Following logs for all services (Ctrl+C to exit)..."
    echo ""
    podman-compose logs -f
else
    echo "Following logs for $SERVICE (Ctrl+C to exit)..."
    echo ""
    podman-compose logs -f "$SERVICE"
fi
EOF
    
    chmod +x "$INSTALL_DIR/scripts/logs.sh"
    print_success "Logs script created"
}

create_status_script() {
    print_info "Creating status script..."
    
    cat > "$INSTALL_DIR/scripts/status.sh" << 'EOF'
#!/bin/bash

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

cd "$PROJECT_DIR"

echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}Airflow Container Status${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
podman-compose ps
echo ""

echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}Health Checks${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# Check webserver
if curl -s http://localhost:8080/health > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Webserver is healthy${NC}"
else
    echo -e "${YELLOW}✗ Webserver is not responding${NC}"
fi

# Check scheduler
SCHEDULER_ID=$(podman ps -q -f name=airflow-scheduler)
if [ -n "$SCHEDULER_ID" ]; then
    echo -e "${GREEN}✓ Scheduler is running${NC}"
else
    echo -e "${YELLOW}✗ Scheduler is not running${NC}"
fi

# Check postgres
POSTGRES_ID=$(podman ps -q -f name=airflow-postgres)
if [ -n "$POSTGRES_ID" ]; then
    echo -e "${GREEN}✓ PostgreSQL is running${NC}"
else
    echo -e "${YELLOW}✗ PostgreSQL is not running${NC}"
fi

echo ""
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}Access Information${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo "Web UI:   http://localhost:8080"
echo "Username: admin"
echo "Password: admin"
echo ""
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}Custom Features${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo "Utils Directory:   $PROJECT_DIR/utils"
echo "Plugins Directory: $PROJECT_DIR/plugins"
echo "DAGs Directory:    $PROJECT_DIR/dags"
echo ""

# Count DAGs
DAG_COUNT=$(find "$PROJECT_DIR/dags" -name "*.py" -type f | wc -l)
echo "Total DAG files: $DAG_COUNT"
EOF
    
    chmod +x "$INSTALL_DIR/scripts/status.sh"
    print_success "Status script created"
}

create_restart_script() {
    print_info "Creating restart script..."
    
    cat > "$INSTALL_DIR/scripts/restart.sh" << 'EOF'
#!/bin/bash

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

YELLOW='\033[1;33m'
GREEN='\033[0;32m'
NC='\033[0m'

echo -e "${YELLOW}Restarting Apache Airflow...${NC}"

"$SCRIPT_DIR/stop.sh"
sleep 3
"$SCRIPT_DIR/start.sh"

echo ""
echo -e "${GREEN}Restart complete!${NC}"
EOF
    
    chmod +x "$INSTALL_DIR/scripts/restart.sh"
    print_success "Restart script created"
}

configure_selinux() {
    if command -v getenforce &> /dev/null; then
        SELINUX_STATUS=$(getenforce)
        if [ "$SELINUX_STATUS" = "Enforcing" ]; then
            print_info "Configuring SELinux..."
            
            sudo chcon -R -t container_file_t "$INSTALL_DIR/dags" "$INSTALL_DIR/logs" "$INSTALL_DIR/plugins" "$INSTALL_DIR/config" "$INSTALL_DIR/utils" 2>/dev/null || true
            sudo setsebool -P container_manage_cgroup on 2>/dev/null || true
            
            print_success "SELinux configured"
        fi
    fi
}

set_permissions() {
    print_info "Setting directory permissions..."
    
    sudo chown -R $AIRFLOW_UID:$AIRFLOW_GID "$INSTALL_DIR/dags" "$INSTALL_DIR/logs" "$INSTALL_DIR/plugins" "$INSTALL_DIR/config" "$INSTALL_DIR/utils"
    
    print_success "Permissions set"
}

configure_firewall() {
    print_info "Configuring firewall..."
    
    if command -v firewall-cmd &> /dev/null; then
        if sudo firewall-cmd --state &> /dev/null; then
            sudo firewall-cmd --add-port=8080/tcp --permanent 2>/dev/null || true
            sudo firewall-cmd --reload 2>/dev/null || true
            print_success "Firewall configured to allow port 8080"
        fi
    fi
}

create_readme() {
    print_info "Creating README..."
    
    cat > "$INSTALL_DIR/README.md" << 'EOF'
# Apache Airflow with Custom Plugins & Utils

This installation provides Apache Airflow with custom plugins, utilities, and sample DAGs.

## Quick Start

```bash
# Start Airflow
./scripts/start.sh

# Check status
./scripts/status.sh

# View logs
./scripts/logs.sh

# Stop Airflow
./scripts/stop.sh
```

## Access

- **Web UI**: http://localhost:8080
- **Username**: admin
- **Password**: admin

## Directory Structure

```
.
├── dags/                      # Your DAG files
│   ├── examples/             # Example DAGs
│   ├── production/           # Production DAGs
│   └── testing/              # Test DAGs
├── plugins/                   # Custom Airflow plugins
│   ├── operators/            # Custom operators
│   ├── sensors/              # Custom sensors
│   └── hooks/                # Custom hooks
├── utils/                     # Custom utility modules
│   ├── helpers/              # Helper utilities
│   ├── validators/           # Data validators
│   └── transformers/         # Data transformers
├── logs/                      # Airflow logs
├── config/                    # Configuration files
└── scripts/                   # Management scripts
```

## Custom Features

### Utils
- **DataHelper**: JSON/CSV operations, file handling
- **DateHelper**: Date operations and formatting
- **NotificationHelper**: Logging and notifications
- **DataValidator**: Data validation utilities
- **SchemaValidator**: Schema validation
- **DataTransformer**: Data transformation utilities

### Plugins
- **CustomBashOperator**: Enhanced BashOperator with logging
- **DataQualityOperator**: Data quality checks
- **CustomFileSensor**: File existence sensor
- **CustomHttpHook**: HTTP requests with retry logic

## Sample DAGs

### Examples
- `01_basic_example.py` - Basic Airflow concepts
- `02_custom_utils_example.py` - Using custom utilities
- `03_custom_plugins_example.py` - Using custom plugins

### Production
- `etl_pipeline_example.py` - Complete ETL pipeline

### Testing
- `test_dag_example.py` - Test DAG for validation

## Usage Examples

### Using Custom Utils in DAGs

```python
from utils.helpers.data_helper import DataHelper
from utils.validators.data_validator import DataValidator

def my_task():
    # Use DataHelper
    data = DataHelper.read_json('/path/to/file.json')
    
    # Validate data
    is_valid, missing = DataValidator.validate_required_fields(
        data, ['field1', 'field2']
    )
```

### Using Custom Plugins

```python
from plugins.operators.data_quality_operator import DataQualityOperator

quality_check = DataQualityOperator(
    task_id='check_data',
    data_source=get_data_function,
    quality_checks=[...]
)
```

## Management

```bash
# Start services
./scripts/start.sh

# Stop services
./scripts/stop.sh

# Restart services
./scripts/restart.sh

# Check status
./scripts/status.sh

# View logs (all services)
./scripts/logs.sh

# View specific service logs
./scripts/logs.sh airflow-webserver
./scripts/logs.sh airflow-scheduler

# Cleanup data (preserves DAGs/plugins/utils)
./scripts/cleanup.sh
```

## Environment Variables

Edit `.env` to customize configuration:

```bash
# Airflow version
AIRFLOW_IMAGE_NAME=apache/airflow:2.8.1

# Admin credentials
AIRFLOW_ADMIN_USERNAME=admin
AIRFLOW_ADMIN_PASSWORD=admin

# Performance
AIRFLOW__CORE__PARALLELISM=32
AIRFLOW__CORE__DAG_CONCURRENCY=16
```

## Development Workflow

1. **Create DAG**: Add to `dags/` directory
2. **Add Utils**: Create modules in `utils/`
3. **Add Plugins**: Create in `plugins/`
4. **Test**: Run test DAG
5. **Deploy**: Move to production directory

## Troubleshooting

### Import Errors

```bash
# Check PYTHONPATH in container
podman-compose exec airflow-webserver env | grep PYTHONPATH

# Verify file permissions
ls -la dags/ utils/ plugins/
```

### DAG Not Appearing

```bash
# Check DAG parsing errors
./scripts/logs.sh airflow-scheduler

# Test DAG import
podman-compose exec airflow-webserver python -c "from dags.examples.01_basic_example import *"
```

### Permission Issues

```bash
sudo chown -R 50000:0 dags/ logs/ plugins/ utils/
```

## Best Practices

1. **Organize DAGs** by environment (examples, production, testing)
2. **Use utils** for reusable code
3. **Create custom operators** for repeated patterns
4. **Add tests** in testing directory
5. **Document** your DAGs and utilities

## Support

- Airflow Docs: https://airflow.apache.org/docs/
- Custom Utils: `utils/` directory
- Custom Plugins: `plugins/` directory
EOF
    
    print_success "README created"
}

print_completion_message() {
    echo ""
    echo "=========================================================================="
    print_success "Apache Airflow with Custom Plugins & Utils - Installation Complete!"
    echo "=========================================================================="
    echo ""
    echo "Installation directory: $INSTALL_DIR"
    echo ""
    echo -e "${GREEN}✓ Custom Utils Created:${NC}"
    echo "  - DataHelper (JSON/CSV operations)"
    echo "  - DateHelper (Date operations)"
    echo "  - NotificationHelper (Logging)"
    echo "  - DataValidator (Validation)"
    echo "  - SchemaValidator (Schema validation)"
    echo "  - DataTransformer (Data transformation)"
    echo ""
    echo -e "${GREEN}✓ Custom Plugins Created:${NC}"
    echo "  - CustomBashOperator"
    echo "  - DataQualityOperator"
    echo "  - CustomFileSensor"
    echo "  - CustomHttpHook"
    echo ""
    echo -e "${GREEN}✓ Sample DAGs Created:${NC}"
    echo "  - Basic examples (3 DAGs)"
    echo "  - Production ETL pipeline"
    echo "  - Test DAG"
    echo ""
    echo "To start Airflow:"
    echo "  cd $INSTALL_DIR"
    echo "  ./scripts/start.sh"
    echo ""
    echo "After starting, access at:"
    echo "  URL: http://localhost:8080"
    echo "  Username: admin"
    echo "  Password: admin"
    echo ""
    echo "Directory structure:"
    echo "  dags/       - Your DAG files (examples, production, testing)"
    echo "  utils/      - Custom utility modules"
    echo "  plugins/    - Custom Airflow plugins"
    echo "  logs/       - Execution logs"
    echo "  scripts/    - Management scripts"
    echo ""
    echo "=========================================================================="
}

# Main execution
main() {
    echo ""
    echo "=========================================================================="
    echo "     Apache Airflow with Custom Plugins & Utils - RHEL 8/9"
    echo "=========================================================================="
    echo ""
    
    check_rhel_version
    install_dependencies
    verify_installations
    create_directory_structure
    create_env_file
    create_compose_file
    create_custom_utils
    create_custom_plugins
    create_sample_dags
    create_start_script
    create_stop_script
    create_cleanup_script
    create_logs_script
    create_status_script
    create_restart_script
    configure_selinux
    set_permissions
    configure_firewall
    create_readme
    print_completion_message
}

# Run main function
main
