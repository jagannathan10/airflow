#!/bin/bash

# ══════════════════════════════════════════════════════════════
# file_archiver.sh — Compress & Archive Old Files
# ══════════════════════════════════════════════════════════════
# Finds files older than N days, compresses them into a dated
# archive, and removes originals. Safe for local VM testing.
# ══════════════════════════════════════════════════════════════

set -euo pipefail

# ── Configuration ──
BASE_DIR="/apps/test_env"
SOURCE_DIRS=("${BASE_DIR}/logs" "${BASE_DIR}/data" "${BASE_DIR}/reports")
ARCHIVE_DIR="${BASE_DIR}/archives"
ARCHIVE_AGE_DAYS=3           # Archive files older than 3 days
COMPRESS_FORMAT="tar.gz"     # tar.gz or zip
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [ARCHIVER] $1"
}

log "Starting file archiver..."
mkdir -p "$ARCHIVE_DIR"

TOTAL_ARCHIVED=0
TOTAL_SIZE_SAVED=0

for SRC_DIR in "${SOURCE_DIRS[@]}"; do

    DIR_NAME=$(basename "$SRC_DIR")
    log "Processing: ${SRC_DIR}"

    if [ ! -d "$SRC_DIR" ]; then
        log "  SKIP — directory does not exist"
        continue
    fi

    # Find files older than threshold
    FILELIST=$(mktemp)
    find "$SRC_DIR" -maxdepth 1 -type f -mtime +"$ARCHIVE_AGE_DAYS" > "$FILELIST" 2>/dev/null

    FILE_COUNT=$(wc -l < "$FILELIST")

    if [ "$FILE_COUNT" -eq 0 ]; then
        log "  No files older than ${ARCHIVE_AGE_DAYS} days"
        rm -f "$FILELIST"
        continue
    fi

    # Calculate total size before archiving
    SIZE_BEFORE=$(cat "$FILELIST" | xargs du -cb 2>/dev/null | tail -1 | awk '{print $1}' || echo 0)

    # Create archive
    ARCHIVE_NAME="${DIR_NAME}_archive_${TIMESTAMP}.${COMPRESS_FORMAT}"
    ARCHIVE_PATH="${ARCHIVE_DIR}/${ARCHIVE_NAME}"

    log "  Archiving ${FILE_COUNT} files → ${ARCHIVE_NAME}"

    if [ "$COMPRESS_FORMAT" = "tar.gz" ]; then
        tar -czf "$ARCHIVE_PATH" -T "$FILELIST" 2>/dev/null
    elif [ "$COMPRESS_FORMAT" = "zip" ]; then
        cat "$FILELIST" | xargs zip -j "$ARCHIVE_PATH" 2>/dev/null
    fi

    # Verify archive was created and is not empty
    if [ -s "$ARCHIVE_PATH" ]; then
        ARCHIVE_SIZE=$(du -sh "$ARCHIVE_PATH" | awk '{print $1}')
        log "  Archive created: ${ARCHIVE_PATH} (${ARCHIVE_SIZE})"

        # Remove original files
        cat "$FILELIST" | xargs rm -f 2>/dev/null
        log "  Removed ${FILE_COUNT} original files"

        TOTAL_ARCHIVED=$(( TOTAL_ARCHIVED + FILE_COUNT ))
        TOTAL_SIZE_SAVED=$(( TOTAL_SIZE_SAVED + SIZE_BEFORE ))
    else
        log "  ERROR: Archive creation failed. Originals preserved."
        rm -f "$ARCHIVE_PATH"
    fi

    rm -f "$FILELIST"
done

# ── Cleanup old archives ──
log "Cleaning archives older than 30 days..."
OLD_ARCHIVES=$(find "$ARCHIVE_DIR" -type f \( -name "*.tar.gz" -o -name "*.zip" \) -mtime +30 -print -delete 2>/dev/null | wc -l)
log "  Removed ${OLD_ARCHIVES} expired archive(s)"

# ══════════════════════════════════════════════════════════════
SAVED_MB=$(echo "scale=2; $TOTAL_SIZE_SAVED / 1048576" | bc 2>/dev/null || echo "0")

log "══════════════════════════════════════"
log " ARCHIVER COMPLETE"
log " Files archived  : ${TOTAL_ARCHIVED}"
log " Original size   : ${SAVED_MB} MB"
log " Archives stored : ${ARCHIVE_DIR}"
log "══════════════════════════════════════"

exit 0
