#!/bin/bash

# ══════════════════════════════════════════════════════════════
# housekeeping.sh — Local VM Housekeeping & Cleanup
# ══════════════════════════════════════════════════════════════
# Designed to run on a local VM with NO external dependencies.
# Safe to test — only cleans files under /apps/test_env
# ══════════════════════════════════════════════════════════════

set -euo pipefail

# ── Configuration (all paths under test sandbox) ──
BASE_DIR="/apps/test_env"
LOG_DIR="${BASE_DIR}/logs"
TMP_DIR="${BASE_DIR}/tmp"
CACHE_DIR="${BASE_DIR}/cache"
ARCHIVE_DIR="${BASE_DIR}/archives"

# Retention periods (in days)
LOG_RETENTION=7
TMP_RETENTION=2
CACHE_RETENTION=5
ARCHIVE_RETENTION=14

# Disk threshold
DISK_WARN_PERCENT=80

# ── Logging ──
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [HOUSEKEEPING] $1"
}

# ── Counters ──
TOTAL_FILES_DELETED=0
TOTAL_BYTES_FREED=0

cleanup_dir() {
    local DIR="$1"
    local PATTERN="$2"
    local DAYS="$3"
    local LABEL="$4"

    if [ ! -d "$DIR" ]; then
        log "  SKIP: ${DIR} does not exist"
        return 0
    fi

    SIZE_BEFORE=$(du -sb "$DIR" 2>/dev/null | awk '{print $1}' || echo 0)

    COUNT=$(find "$DIR" -type f -name "$PATTERN" -mtime +"$DAYS" -print -delete 2>/dev/null | wc -l)

    SIZE_AFTER=$(du -sb "$DIR" 2>/dev/null | awk '{print $1}' || echo 0)
    FREED=$(( SIZE_BEFORE - SIZE_AFTER ))
    FREED_KB=$(( FREED / 1024 ))

    TOTAL_FILES_DELETED=$(( TOTAL_FILES_DELETED + COUNT ))
    TOTAL_BYTES_FREED=$(( TOTAL_BYTES_FREED + FREED ))

    log "  ${LABEL}: deleted ${COUNT} files, freed ${FREED_KB} KB"
}

# ══════════════════════════════════════════════════════════════
log "Starting housekeeping..."
log "Base directory: ${BASE_DIR}"
log "══════════════════════════════════════"

# ── STEP 1: Clean old log files ──
log "STEP 1: Cleaning logs older than ${LOG_RETENTION} days..."
cleanup_dir "$LOG_DIR"         "*.log"     "$LOG_RETENTION"  "Text logs"
cleanup_dir "$LOG_DIR"         "*.log.gz"  "$LOG_RETENTION"  "Compressed logs"
cleanup_dir "$LOG_DIR"         "*.log.[0-9]*" "$LOG_RETENTION" "Rotated logs"

# Truncate oversized log files (>100MB) — keep last 5000 lines
if [ -d "$LOG_DIR" ]; then
    find "$LOG_DIR" -type f -name "*.log" -size +100M 2>/dev/null | while read -r BIG_FILE; do
        ORIG_SIZE=$(du -sh "$BIG_FILE" | awk '{print $1}')
        tail -n 5000 "$BIG_FILE" > "${BIG_FILE}.trimmed"
        mv "${BIG_FILE}.trimmed" "$BIG_FILE"
        log "  Truncated: ${BIG_FILE} (was ${ORIG_SIZE})"
    done
fi

# ── STEP 2: Clean temp files ──
log "STEP 2: Cleaning temp files older than ${TMP_RETENTION} days..."
cleanup_dir "$TMP_DIR" "*" "$TMP_RETENTION" "Temp files"

# ── STEP 3: Clean cache ──
log "STEP 3: Cleaning cache older than ${CACHE_RETENTION} days..."
cleanup_dir "$CACHE_DIR" "*" "$CACHE_RETENTION" "Cache files"

# Remove empty subdirectories in cache
if [ -d "$CACHE_DIR" ]; then
    EMPTY_DIRS=$(find "$CACHE_DIR" -mindepth 1 -type d -empty -print -delete 2>/dev/null | wc -l)
    log "  Removed ${EMPTY_DIRS} empty cache directories"
fi

# ── STEP 4: Clean old archives ──
log "STEP 4: Cleaning archives older than ${ARCHIVE_RETENTION} days..."
cleanup_dir "$ARCHIVE_DIR" "*.tar.gz"  "$ARCHIVE_RETENTION" "Tar archives"
cleanup_dir "$ARCHIVE_DIR" "*.zip"     "$ARCHIVE_RETENTION" "Zip archives"
cleanup_dir "$ARCHIVE_DIR" "*.bak"     "$ARCHIVE_RETENTION" "Backup files"

# ── STEP 5: Clean cron JSON logs ──
log "STEP 5: Cleaning cron metric logs older than 30 days..."
cleanup_dir "/apps/cron/logs" "cron_status_metrics_*.json" 30 "Cron logs"

# ── STEP 6: Disk usage check ──
log "STEP 6: Checking disk usage..."

# Get disk usage for the partition where BASE_DIR lives
DISK_PERCENT=$(df "$BASE_DIR" 2>/dev/null | awk 'NR==2 {gsub(/%/,""); print $5}' || echo 0)
DISK_AVAIL=$(df -h "$BASE_DIR" 2>/dev/null | awk 'NR==2 {print $4}' || echo "unknown")

if [ "$DISK_PERCENT" -ge "$DISK_WARN_PERCENT" ]; then
    log "  WARNING: Disk at ${DISK_PERCENT}% — only ${DISK_AVAIL} free!"
else
    log "  OK: Disk at ${DISK_PERCENT}% — ${DISK_AVAIL} free"
fi

# ══════════════════════════════════════════════════════════════
# Summary
# ══════════════════════════════════════════════════════════════
TOTAL_FREED_KB=$(( TOTAL_BYTES_FREED / 1024 ))

log "══════════════════════════════════════"
log " HOUSEKEEPING COMPLETE"
log " Files deleted : ${TOTAL_FILES_DELETED}"
log " Space freed   : ${TOTAL_FREED_KB} KB"
log " Disk usage    : ${DISK_PERCENT}%"
log "══════════════════════════════════════"

exit 0
