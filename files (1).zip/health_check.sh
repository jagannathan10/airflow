#!/bin/bash

# ══════════════════════════════════════════════════════════════
# health_check.sh — Local VM System Health Check
# ══════════════════════════════════════════════════════════════
# Checks CPU, memory, disk, services, and connectivity.
# No external dependencies — runs fully on a local VM.
# ══════════════════════════════════════════════════════════════

set -euo pipefail

HOSTNAME=$(hostname)
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
EXIT_CODE=0

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [HEALTH] $1"
}

warn() {
    log "WARNING: $1"
}

fail() {
    log "CRITICAL: $1"
    EXIT_CODE=1
}

log "Starting health check on ${HOSTNAME}..."
log "──────────────────────────────────────"

# ══════════════════════════════════════════════════════════════
# CHECK 1: CPU Load
# ══════════════════════════════════════════════════════════════
log "CHECK 1: CPU Load"

CPU_CORES=$(nproc 2>/dev/null || grep -c ^processor /proc/cpuinfo 2>/dev/null || echo 1)
LOAD_1=$(awk '{print $1}' /proc/loadavg 2>/dev/null || echo "0")
LOAD_5=$(awk '{print $2}' /proc/loadavg 2>/dev/null || echo "0")

# Alert if 1-min load exceeds 2x cores
LOAD_THRESHOLD=$(( CPU_CORES * 2 ))
LOAD_INT=${LOAD_1%.*}

if [ "${LOAD_INT:-0}" -ge "$LOAD_THRESHOLD" ]; then
    fail "CPU load ${LOAD_1} exceeds threshold (${LOAD_THRESHOLD}) for ${CPU_CORES} cores"
else
    log "  OK — Load: ${LOAD_1} / ${LOAD_5} (${CPU_CORES} cores)"
fi

# ══════════════════════════════════════════════════════════════
# CHECK 2: Memory
# ══════════════════════════════════════════════════════════════
log "CHECK 2: Memory"

MEM_TOTAL=$(free -m | awk '/^Mem:/ {print $2}')
MEM_AVAIL=$(free -m | awk '/^Mem:/ {print $7}')
MEM_USED=$(( MEM_TOTAL - MEM_AVAIL ))
MEM_PERCENT=$(( MEM_USED * 100 / MEM_TOTAL ))

if [ "$MEM_PERCENT" -ge 95 ]; then
    fail "Memory critically high: ${MEM_PERCENT}% (${MEM_AVAIL}MB free)"
elif [ "$MEM_PERCENT" -ge 85 ]; then
    warn "Memory usage high: ${MEM_PERCENT}% (${MEM_AVAIL}MB free)"
else
    log "  OK — ${MEM_USED}MB / ${MEM_TOTAL}MB (${MEM_PERCENT}%, ${MEM_AVAIL}MB free)"
fi

# ══════════════════════════════════════════════════════════════
# CHECK 3: Disk Usage (all mounted partitions)
# ══════════════════════════════════════════════════════════════
log "CHECK 3: Disk Usage"

df -hP | awk 'NR>1 && $1 !~ /^(tmpfs|devtmpfs|udev)/' | while read -r FS SIZE USED AVAIL PCT MOUNT; do
    USAGE=${PCT%%%}
    if [ "$USAGE" -ge 95 ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] [HEALTH] CRITICAL: ${MOUNT} at ${PCT} (${AVAIL} free)"
    elif [ "$USAGE" -ge 80 ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] [HEALTH] WARNING: ${MOUNT} at ${PCT} (${AVAIL} free)"
    else
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] [HEALTH]   OK — ${MOUNT}: ${PCT} used (${AVAIL} free)"
    fi
done

# ══════════════════════════════════════════════════════════════
# CHECK 4: Swap Usage
# ══════════════════════════════════════════════════════════════
log "CHECK 4: Swap Usage"

SWAP_TOTAL=$(free -m | awk '/^Swap:/ {print $2}')
SWAP_USED=$(free -m | awk '/^Swap:/ {print $3}')

if [ "$SWAP_TOTAL" -eq 0 ]; then
    warn "No swap configured"
elif [ "$SWAP_USED" -gt $(( SWAP_TOTAL / 2 )) ]; then
    warn "Swap usage high: ${SWAP_USED}MB / ${SWAP_TOTAL}MB"
else
    log "  OK — Swap: ${SWAP_USED}MB / ${SWAP_TOTAL}MB"
fi

# ══════════════════════════════════════════════════════════════
# CHECK 5: Key Services (systemd)
# ══════════════════════════════════════════════════════════════
log "CHECK 5: Key Services"

SERVICES_TO_CHECK=("cron" "sshd" "rsyslog" "systemd-journald")

for SVC in "${SERVICES_TO_CHECK[@]}"; do
    if systemctl is-active --quiet "$SVC" 2>/dev/null; then
        log "  OK — ${SVC} is running"
    elif systemctl list-unit-files "${SVC}.service" &>/dev/null; then
        fail "${SVC} is NOT running"
    else
        log "  SKIP — ${SVC} not installed"
    fi
done

# ══════════════════════════════════════════════════════════════
# CHECK 6: Network Connectivity
# ══════════════════════════════════════════════════════════════
log "CHECK 6: Network Connectivity"

# DNS resolution
if host google.com > /dev/null 2>&1 || nslookup google.com > /dev/null 2>&1; then
    log "  OK — DNS resolution working"
else
    warn "DNS resolution failed"
fi

# Internet reachability
if ping -c 1 -W 3 8.8.8.8 > /dev/null 2>&1; then
    log "  OK — Internet reachable (ping 8.8.8.8)"
else
    warn "Cannot reach internet (ping 8.8.8.8 failed)"
fi

# ══════════════════════════════════════════════════════════════
# CHECK 7: Zombie & High-CPU Processes
# ══════════════════════════════════════════════════════════════
log "CHECK 7: Process Health"

ZOMBIE_COUNT=$(ps aux | awk '$8 ~ /^Z/ {count++} END {print count+0}')
if [ "$ZOMBIE_COUNT" -gt 0 ]; then
    warn "${ZOMBIE_COUNT} zombie process(es) detected"
else
    log "  OK — No zombie processes"
fi

# Top 3 CPU consumers
log "  Top CPU consumers:"
ps aux --sort=-%cpu | awk 'NR>1 && NR<=4 {printf "    PID %-8s CPU %-6s MEM %-6s %s\n", $2, $3"%", $4"%", $11}'

# ══════════════════════════════════════════════════════════════
# CHECK 8: Uptime & Last Reboot
# ══════════════════════════════════════════════════════════════
log "CHECK 8: Uptime"

UPTIME_STR=$(uptime -p 2>/dev/null || uptime | sed 's/.*up /up /' | sed 's/,.*load.*//')
LAST_BOOT=$(who -b 2>/dev/null | awk '{print $3, $4}' || echo "unknown")

log "  ${UPTIME_STR} (last boot: ${LAST_BOOT})"

# ══════════════════════════════════════════════════════════════
# CHECK 9: Inode Usage
# ══════════════════════════════════════════════════════════════
log "CHECK 9: Inode Usage"

df -iP | awk 'NR>1 && $1 !~ /^(tmpfs|devtmpfs|udev)/' | while read -r FS ITOTAL IUSED IFREE IPCT MOUNT; do
    IUSAGE=${IPCT%%%}
    if [ "$IUSAGE" -ge 90 ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] [HEALTH] WARNING: Inodes on ${MOUNT} at ${IPCT}"
    else
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] [HEALTH]   OK — Inodes on ${MOUNT}: ${IPCT}"
    fi
done

# ══════════════════════════════════════════════════════════════
# Final Status
# ══════════════════════════════════════════════════════════════
log "──────────────────────────────────────"
if [ "$EXIT_CODE" -eq 0 ]; then
    log "RESULT: ALL CHECKS PASSED"
else
    log "RESULT: ONE OR MORE CHECKS FAILED"
fi

exit $EXIT_CODE
