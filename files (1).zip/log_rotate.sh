#!/bin/bash

# ══════════════════════════════════════════════════════════════
# log_rotate.sh — Rotate & Compress Active Log Files
# ══════════════════════════════════════════════════════════════
# Rotates current log files, compresses previous rotations,
# and enforces a max number of rotated copies.
# ══════════════════════════════════════════════════════════════

set -euo pipefail

# ── Configuration ──
LOG_DIR="/apps/test_env/logs"
MAX_ROTATIONS=5              # Keep at most 5 rotated copies
MAX_SIZE_MB=50               # Only rotate if file > 50MB (set to 0 to always rotate)

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [LOG_ROTATE] $1"
}

log "Starting log rotation..."

if [ ! -d "$LOG_DIR" ]; then
    log "Log directory does not exist: ${LOG_DIR}"
    exit 1
fi

ROTATED=0
COMPRESSED=0

# ══════════════════════════════════════════════════════════════
# STEP 1: Rotate current .log files
# ══════════════════════════════════════════════════════════════
log "STEP 1: Rotating active log files..."

find "$LOG_DIR" -maxdepth 1 -type f -name "*.log" | sort | while read -r LOGFILE; do

    FILENAME=$(basename "$LOGFILE")
    FILESIZE_KB=$(du -k "$LOGFILE" | awk '{print $1}')
    FILESIZE_MB=$(( FILESIZE_KB / 1024 ))

    # Skip small files if threshold is set
    if [ "$MAX_SIZE_MB" -gt 0 ] && [ "$FILESIZE_MB" -lt "$MAX_SIZE_MB" ]; then
        log "  SKIP — ${FILENAME} (${FILESIZE_MB}MB < ${MAX_SIZE_MB}MB threshold)"
        continue
    fi

    # Shift existing rotations: .log.4 → .log.5, .log.3 → .log.4, etc.
    for i in $(seq $((MAX_ROTATIONS - 1)) -1 1); do
        NEXT=$(( i + 1 ))
        [ -f "${LOGFILE}.${i}.gz" ] && mv "${LOGFILE}.${i}.gz" "${LOGFILE}.${NEXT}.gz"
        [ -f "${LOGFILE}.${i}" ]    && mv "${LOGFILE}.${i}" "${LOGFILE}.${NEXT}"
    done

    # Rotate current file → .log.1
    cp "$LOGFILE" "${LOGFILE}.1"
    truncate -s 0 "$LOGFILE"

    log "  Rotated: ${FILENAME} (${FILESIZE_MB}MB)"
    ROTATED=$(( ROTATED + 1 ))
done

# ══════════════════════════════════════════════════════════════
# STEP 2: Compress rotated files (skip .1 — still recent)
# ══════════════════════════════════════════════════════════════
log "STEP 2: Compressing old rotations..."

find "$LOG_DIR" -maxdepth 1 -type f -name "*.log.[2-9]" -o -name "*.log.[0-9][0-9]" | sort | while read -r ROTFILE; do
    if [ ! -f "${ROTFILE}.gz" ]; then
        gzip "$ROTFILE"
        log "  Compressed: $(basename "$ROTFILE") → $(basename "$ROTFILE").gz"
        COMPRESSED=$(( COMPRESSED + 1 ))
    fi
done

# ══════════════════════════════════════════════════════════════
# STEP 3: Remove excess rotations beyond MAX_ROTATIONS
# ══════════════════════════════════════════════════════════════
log "STEP 3: Enforcing max ${MAX_ROTATIONS} rotations..."

find "$LOG_DIR" -maxdepth 1 -type f -name "*.log" | sort -u | while read -r BASE_LOG; do
    FILENAME=$(basename "$BASE_LOG")
    EXCESS=$(find "$LOG_DIR" -maxdepth 1 -name "${FILENAME}.*" | sort -t. -k3 -n -r | tail -n +$((MAX_ROTATIONS + 1)))

    for OLD_FILE in $EXCESS; do
        rm -f "$OLD_FILE"
        log "  Purged excess: $(basename "$OLD_FILE")"
    done
done

# ══════════════════════════════════════════════════════════════
log "══════════════════════════════════════"
log " LOG ROTATION COMPLETE"
log " Listing: ${LOG_DIR}"
ls -lhS "$LOG_DIR" 2>/dev/null | head -20
log "══════════════════════════════════════"

exit 0
